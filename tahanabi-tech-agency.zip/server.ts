import express, { Request, Response, NextFunction } from 'express';
import { createServer as createViteServer } from 'vite';
import fs from 'fs';
import path from 'path';
import crypto from 'crypto';

const app = express();
const PORT = process.env.PORT ? parseInt(process.env.PORT, 10) : 3000;

// -------------------------------------------------------------
// 1. DATA STORES & DIRECTORIES
// -------------------------------------------------------------
const DATA_DIR = path.resolve(process.cwd(), 'data');
const INQUIRIES_FILE = path.resolve(DATA_DIR, 'inquiries.json');
const COMMENTS_FILE = path.resolve(DATA_DIR, 'comments.json');
const SESSIONS_FILE = path.resolve(DATA_DIR, 'sessions.json');
const AUDIT_LOGS_FILE = path.resolve(DATA_DIR, 'audit_logs.json');
const VAULT_FILE = path.resolve(DATA_DIR, 'admin_vault.json');

function ensureDataStore() {
  if (!fs.existsSync(DATA_DIR)) {
    fs.mkdirSync(DATA_DIR, { recursive: true });
  }
  if (!fs.existsSync(INQUIRIES_FILE)) {
    fs.writeFileSync(INQUIRIES_FILE, JSON.stringify([], null, 2));
  }
  if (!fs.existsSync(COMMENTS_FILE)) {
    fs.writeFileSync(COMMENTS_FILE, JSON.stringify([], null, 2));
  }
  if (!fs.existsSync(SESSIONS_FILE)) {
    fs.writeFileSync(SESSIONS_FILE, JSON.stringify({}, null, 2));
  }
  if (!fs.existsSync(AUDIT_LOGS_FILE)) {
    fs.writeFileSync(AUDIT_LOGS_FILE, JSON.stringify([], null, 2));
  }
}

ensureDataStore();

function readJsonFile<T>(filePath: string, fallback: T): T {
  try {
    const raw = fs.readFileSync(filePath, 'utf-8');
    return JSON.parse(raw);
  } catch {
    return fallback;
  }
}

function writeJsonFile<T>(filePath: string, data: T): void {
  try {
    fs.writeFileSync(filePath, JSON.stringify(data, null, 2));
  } catch (err) {
    console.error(`[DataStore] Failed to write file ${filePath}:`, err);
  }
}

// -------------------------------------------------------------
// 2. INPUT SANITIZATION & SECURITY HELPERS
// -------------------------------------------------------------
function sanitizeString(input: unknown, maxLength = 2000): string {
  if (typeof input !== 'string') return '';
  return input
    .replace(/<[^>]*>?/gm, '') // Strip HTML tags
    .replace(/javascript:/gi, '')
    .replace(/on\w+=/gi, '')
    .trim()
    .slice(0, maxLength);
}

function hashIp(ip: string): string {
  return crypto.createHash('sha256').update(ip || '127.0.0.1').digest('hex').substring(0, 16);
}

function hashUserAgent(ua: string | undefined): string {
  return crypto.createHash('sha256').update(ua || 'unknown').digest('hex').substring(0, 16);
}

// -------------------------------------------------------------
// 3. SECURE AUDIT LOGGING (PHASE 9)
// -------------------------------------------------------------
export type AuditEventType =
  | 'AUTH_LOGIN_SUCCESS'
  | 'AUTH_LOGIN_FAILURE'
  | 'AUTH_LOGOUT'
  | 'AUTH_SESSION_EXPIRED'
  | 'AUTH_2FA_CHALLENGE_FAILED'
  | 'AUTH_PASSWORD_CHANGED'
  | 'AUTH_2FA_ENABLED'
  | 'AUTH_2FA_DISABLED'
  | 'RBAC_ACCESS_DENIED'
  | 'RATE_LIMIT_EXCEEDED'
  | 'SESSION_HIJACK_ATTEMPT'
  | 'INQUIRY_STATUS_UPDATED'
  | 'INQUIRY_DELETED'
  | 'COMMENT_DELETED'
  | 'AUDIT_LOGS_ROTATED'
  | 'ADMIN_USER_CREATED'
  | 'ADMIN_USER_DELETED';

interface AuditLogEntry {
  id: string;
  timestamp: string;
  eventType: AuditEventType;
  actor: string;
  role: string;
  ipHash: string;
  endpoint: string;
  details: string;
  outcome: 'SUCCESS' | 'DENIED' | 'WARN';
}

function recordAuditLog(
  eventType: AuditEventType,
  actor: string,
  role: string,
  ip: string,
  endpoint: string,
  details: string,
  outcome: 'SUCCESS' | 'DENIED' | 'WARN' = 'SUCCESS'
) {
  try {
    const logs = readJsonFile<AuditLogEntry[]>(AUDIT_LOGS_FILE, []);
    const entry: AuditLogEntry = {
      id: `audit-${Date.now()}-${crypto.randomBytes(4).toString('hex')}`,
      timestamp: new Date().toISOString(),
      eventType,
      actor: actor || 'Anonymous',
      role: role || 'GUEST',
      ipHash: hashIp(ip),
      endpoint,
      details: sanitizeString(details, 500),
      outcome,
    };
    logs.unshift(entry);
    if (logs.length > 1000) logs.length = 1000;
    writeJsonFile(AUDIT_LOGS_FILE, logs);
  } catch (err) {
    console.error('[AuditLog] Error recording log entry:', err);
  }
}

// -------------------------------------------------------------
// 4. RATE LIMITING & BRUTE FORCE PROTECTION (PHASE 1 & 5)
// -------------------------------------------------------------
interface RateLimitTracker {
  count: number;
  firstAttemptTime: number;
  lockoutUntil: number;
}

const loginRateLimits = new Map<string, RateLimitTracker>();
const publicApiRateLimits = new Map<string, { count: number; resetTime: number }>();

function checkLoginRateLimit(ip: string): { allowed: boolean; remainingLockoutSeconds?: number; delayMs?: number } {
  const now = Date.now();
  const tracker = loginRateLimits.get(ip);

  if (!tracker) {
    return { allowed: true, delayMs: 0 };
  }

  // Check if currently locked out
  if (tracker.lockoutUntil > now) {
    const remaining = Math.ceil((tracker.lockoutUntil - now) / 1000);
    return { allowed: false, remainingLockoutSeconds: remaining };
  }

  // Reset window if older than 15 minutes
  if (now - tracker.firstAttemptTime > 15 * 60 * 1000) {
    loginRateLimits.delete(ip);
    return { allowed: true, delayMs: 0 };
  }

  // Check failed attempts (Max 5 attempts per 15 min)
  if (tracker.count >= 5) {
    tracker.lockoutUntil = now + 15 * 60 * 1000; // 15-minute lockout
    loginRateLimits.set(ip, tracker);
    const remaining = Math.ceil((tracker.lockoutUntil - now) / 1000);
    return { allowed: false, remainingLockoutSeconds: remaining };
  }

  // Progressive delay: 1st failed attempt 500ms, 2nd 1000ms, 3rd 2000ms, 4th 4000ms
  const delayMs = Math.min(4000, Math.pow(2, tracker.count - 1) * 500);

  return { allowed: true, delayMs };
}

function recordFailedLogin(ip: string) {
  const now = Date.now();
  const tracker = loginRateLimits.get(ip) || { count: 0, firstAttemptTime: now, lockoutUntil: 0 };
  tracker.count += 1;
  loginRateLimits.set(ip, tracker);
}

function clearLoginRateLimit(ip: string) {
  loginRateLimits.delete(ip);
}

// Public API Rate Limiter (Max 40 requests per 1-minute window per IP)
function publicRateLimiterMiddleware(req: Request, res: Response, next: NextFunction) {
  const ip = req.ip || req.socket.remoteAddress || '127.0.0.1';
  const now = Date.now();
  const tracker = publicApiRateLimits.get(ip) || { count: 0, resetTime: now + 60 * 1000 };

  if (now > tracker.resetTime) {
    tracker.count = 1;
    tracker.resetTime = now + 60 * 1000;
  } else {
    tracker.count += 1;
  }

  publicApiRateLimits.set(ip, tracker);

  if (tracker.count > 40) {
    recordAuditLog(
      'RATE_LIMIT_EXCEEDED',
      'Anonymous',
      'GUEST',
      ip,
      req.originalUrl,
      'Exceeded 40 requests/min threshold',
      'DENIED'
    );
    return res.status(429).json({
      success: false,
      error: 'Rate limit exceeded. Please wait a moment before sending more requests.',
    });
  }

  next();
}

// -------------------------------------------------------------
// 5. SECURE CREDENTIAL VAULT & RFC 6238 TWO-FACTOR AUTH (2FA)
// -------------------------------------------------------------
export type UserRole = 'SUPER_ADMIN' | 'ADMIN' | 'MANAGER' | 'STAFF' | 'READ_ONLY';

export interface StoredAdminAccount {
  id: string;
  username: string;
  name: string;
  role: UserRole;
  salt: string; // 32-byte cryptographically random hex
  hash: string; // 100k rounds PBKDF2-HMAC-SHA256
  twoFactorEnabled: boolean;
  twoFactorSecret?: string; // 160-bit Base32 secret
  updatedAt: string;
}

// Secure hash function using PBKDF2 with HMAC-SHA256 (100,000 iterations)
function hashPassword(password: string, salt: string): string {
  return crypto.pbkdf2Sync(password, salt, 100000, 64, 'sha256').toString('hex');
}

// Constant-time verification to prevent timing attacks
function verifyPassword(candidate: string, salt: string, expectedHash: string): boolean {
  try {
    const candidateHash = hashPassword(candidate, salt);
    const bufA = Buffer.from(candidateHash, 'hex');
    const bufB = Buffer.from(expectedHash, 'hex');
    if (bufA.length !== bufB.length) return false;
    return crypto.timingSafeEqual(bufA, bufB);
  } catch {
    return false;
  }
}

// Password Policy Enforcement
function validatePasswordStrength(password: string): { valid: boolean; reason?: string } {
  if (!password || password.length < 10) {
    return { valid: false, reason: 'Password must be at least 10 characters in length.' };
  }
  if (!/[a-z]/.test(password)) {
    return { valid: false, reason: 'Password must contain at least one lowercase letter.' };
  }
  if (!/[A-Z]/.test(password)) {
    return { valid: false, reason: 'Password must contain at least one uppercase letter.' };
  }
  if (!/[0-9]/.test(password)) {
    return { valid: false, reason: 'Password must contain at least one number.' };
  }
  if (!/[!@#$%^&*()_+\-=[\]{};':"\\|,.<>/?]/.test(password)) {
    return { valid: false, reason: 'Password must contain at least one special character (!@#$%^&*...).' };
  }
  return { valid: true };
}

// RFC 6238 Standard TOTP (Google Authenticator / Authy / Microsoft Authenticator)
const BASE32_ALPHABET = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';

function base32Decode(base32: string): Buffer {
  const clean = base32.toUpperCase().replace(/=+$/, '').replace(/\s+/g, '');
  let bits = 0;
  let value = 0;
  const bytes: number[] = [];

  for (let i = 0; i < clean.length; i++) {
    const idx = BASE32_ALPHABET.indexOf(clean[i]);
    if (idx === -1) continue;
    value = (value << 5) | idx;
    bits += 5;
    if (bits >= 8) {
      bytes.push((value >>> (bits - 8)) & 0xff);
      bits -= 8;
    }
  }
  return Buffer.from(bytes);
}

function base32Encode(buffer: Buffer): string {
  let bits = 0;
  let value = 0;
  let output = '';
  for (let i = 0; i < buffer.length; i++) {
    value = (value << 8) | buffer[i];
    bits += 8;
    while (bits >= 5) {
      output += BASE32_ALPHABET[(value >>> (bits - 5)) & 31];
      bits -= 5;
    }
  }
  if (bits > 0) {
    output += BASE32_ALPHABET[(value << (5 - bits)) & 31];
  }
  return output;
}

function generateTotpSecret(): string {
  return base32Encode(crypto.randomBytes(20)); // 160 bits entropy
}

function generateTotpCode(secret: string, counter: number): string {
  const key = base32Decode(secret);
  const buf = Buffer.alloc(8);
  buf.writeBigInt64BE(BigInt(counter));
  const hmac = crypto.createHmac('sha1', key).update(buf).digest();
  const offset = hmac[hmac.length - 1] & 0x0f;
  const code =
    ((hmac[offset] & 0x7f) << 24) |
    ((hmac[offset + 1] & 0xff) << 16) |
    ((hmac[offset + 2] & 0xff) << 8) |
    (hmac[offset + 3] & 0xff);
  return (code % 1000000).toString().padStart(6, '0');
}

function verifyTotp(candidate: string, secret: string): boolean {
  if (!candidate || !secret) return false;
  const cleanCode = candidate.trim();
  if (!/^\d{6}$/.test(cleanCode)) return false;

  const currentStep = Math.floor(Date.now() / 1000 / 30);
  // Check -1, 0, +1 time windows for clock drift (90-second total window)
  for (let offset = -1; offset <= 1; offset++) {
    const expected = generateTotpCode(secret, currentStep + offset);
    if (crypto.timingSafeEqual(Buffer.from(cleanCode), Buffer.from(expected))) {
      return true;
    }
  }
  return false;
}

// Initialize or Load Admin Accounts Vault
function loadAdminAccounts(): StoredAdminAccount[] {
  let accounts = readJsonFile<StoredAdminAccount[]>(VAULT_FILE, []);
  if (accounts.length === 0) {
    // First-time provisioning: generate distinct 32-byte salts per account
    const initialPassword = process.env.INITIAL_ADMIN_PASSWORD || 'tahanabi2026';
    const createInitialAccount = (id: string, username: string, name: string, role: UserRole): StoredAdminAccount => {
      const salt = crypto.randomBytes(32).toString('hex');
      return {
        id,
        username,
        name,
        role,
        salt,
        hash: hashPassword(initialPassword, salt),
        twoFactorEnabled: false,
        updatedAt: new Date().toISOString(),
      };
    };

    accounts = [
      createInitialAccount('usr-superadmin', 'superadmin', 'MD Juned (Executive Engineering)', 'SUPER_ADMIN'),
      createInitialAccount('usr-admin', 'admin', 'Satpal Kumar (Security Operations)', 'ADMIN'),
      createInitialAccount('usr-manager', 'manager', 'Tahanabi Project Lead', 'MANAGER'),
      createInitialAccount('usr-staff', 'staff', 'Client Verification Staff', 'STAFF'),
      createInitialAccount('usr-auditor', 'auditor', 'Compliance & Audit Observer', 'READ_ONLY'),
    ];
    writeJsonFile(VAULT_FILE, accounts);
  }
  return accounts;
}

let ADMIN_ACCOUNTS = loadAdminAccounts();

function saveAdminAccounts(accounts: StoredAdminAccount[]) {
  ADMIN_ACCOUNTS = accounts;
  writeJsonFile(VAULT_FILE, accounts);
}

// -------------------------------------------------------------
// 6. CRYPTOGRAPHIC SESSION REGISTRY & FINGERPRINTING (PHASE 1)
// -------------------------------------------------------------
interface SessionRecord {
  token: string;
  userId: string;
  username: string;
  name: string;
  role: UserRole;
  createdAt: number;
  lastActivity: number;
  expiresAt: number;
  ipHash: string;
  userAgentHash: string;
}

const activeSessions = new Map<string, SessionRecord>();

// Hydrate stored sessions on boot
function initSessionRegistry() {
  const stored = readJsonFile<Record<string, SessionRecord>>(SESSIONS_FILE, {});
  const now = Date.now();
  for (const [token, session] of Object.entries(stored)) {
    if (session.expiresAt > now) {
      activeSessions.set(token, session);
    }
  }
}

initSessionRegistry();

function persistSessions() {
  const obj: Record<string, SessionRecord> = {};
  for (const [token, session] of activeSessions.entries()) {
    obj[token] = session;
  }
  writeJsonFile(SESSIONS_FILE, obj);
}

function createSession(user: StoredAdminAccount, ip: string, userAgent?: string): SessionRecord {
  // Generate 256-bit cryptographically secure token
  const token = crypto.randomBytes(32).toString('hex');
  const now = Date.now();
  const session: SessionRecord = {
    token,
    userId: user.id,
    username: user.username,
    name: user.name,
    role: user.role,
    createdAt: now,
    lastActivity: now,
    expiresAt: now + 30 * 60 * 1000, // 30-minute idle sliding window
    ipHash: hashIp(ip),
    userAgentHash: hashUserAgent(userAgent),
  };

  activeSessions.set(token, session);
  persistSessions();
  return session;
}

function revokeSession(token: string) {
  activeSessions.delete(token);
  persistSessions();
}

function revokeAllUserSessions(userId: string) {
  for (const [token, session] of activeSessions.entries()) {
    if (session.userId === userId) {
      activeSessions.delete(token);
    }
  }
  persistSessions();
}

// -------------------------------------------------------------
// 7. ROLE-BASED ACCESS CONTROL (RBAC) MIDDLEWARE (PHASE 2)
// -------------------------------------------------------------
declare global {
  namespace Express {
    interface Request {
      adminUser?: SessionRecord;
    }
  }
}

const ROLE_HIERARCHY: Record<UserRole, number> = {
  SUPER_ADMIN: 5,
  ADMIN: 4,
  MANAGER: 3,
  STAFF: 2,
  READ_ONLY: 1,
};

function authenticateSession(req: Request, res: Response, next: NextFunction) {
  const authHeader = req.headers.authorization;
  const ip = req.ip || req.socket.remoteAddress || '127.0.0.1';
  const ua = req.headers['user-agent'];

  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    recordAuditLog(
      'RBAC_ACCESS_DENIED',
      'Anonymous',
      'GUEST',
      ip,
      req.originalUrl,
      'Missing or invalid Bearer token',
      'DENIED'
    );
    return res.status(401).json({
      success: false,
      error: 'Authentication required. Missing Bearer token.',
    });
  }

  const token = authHeader.substring(7).trim();
  const session = activeSessions.get(token);

  if (!session) {
    recordAuditLog(
      'RBAC_ACCESS_DENIED',
      'Anonymous',
      'GUEST',
      ip,
      req.originalUrl,
      'Invalid or expired session token',
      'DENIED'
    );
    return res.status(401).json({
      success: false,
      error: 'Session invalid or expired. Please re-authenticate.',
    });
  }

  const now = Date.now();
  if (session.expiresAt < now) {
    activeSessions.delete(token);
    persistSessions();
    recordAuditLog(
      'AUTH_SESSION_EXPIRED',
      session.username,
      session.role,
      ip,
      req.originalUrl,
      'Session expired via timeout',
      'WARN'
    );
    return res.status(401).json({
      success: false,
      error: 'Session has timed out. Please sign in again.',
    });
  }

  // Session Hijacking Defense: Verify User-Agent Fingerprint
  const currentUaHash = hashUserAgent(ua);
  if (session.userAgentHash && session.userAgentHash !== currentUaHash) {
    recordAuditLog(
      'SESSION_HIJACK_ATTEMPT',
      session.username,
      session.role,
      ip,
      req.originalUrl,
      'User-Agent fingerprint mismatch! Token stolen or replayed from another browser. Terminating session.',
      'DENIED'
    );
    activeSessions.delete(token);
    persistSessions();
    return res.status(401).json({
      success: false,
      error: 'Security alert: Session anomaly detected. Session terminated.',
    });
  }

  // Extend sliding window (30 mins from now)
  session.lastActivity = now;
  session.expiresAt = now + 30 * 60 * 1000;
  req.adminUser = session;
  next();
}

function requireRole(minimumRole: UserRole) {
  return (req: Request, res: Response, next: NextFunction) => {
    const user = req.adminUser;
    const ip = req.ip || req.socket.remoteAddress || '127.0.0.1';

    if (!user) {
      return res.status(401).json({ success: false, error: 'Authentication required' });
    }

    const userLevel = ROLE_HIERARCHY[user.role] || 0;
    const requiredLevel = ROLE_HIERARCHY[minimumRole] || 0;

    if (userLevel < requiredLevel) {
      recordAuditLog(
        'RBAC_ACCESS_DENIED',
        user.username,
        user.role,
        ip,
        req.originalUrl,
        `Insufficient privileges: requires ${minimumRole}, current role is ${user.role}`,
        'DENIED'
      );
      return res.status(403).json({
        success: false,
        error: `Access Denied: Requires role [${minimumRole}] or higher. Your role: [${user.role}].`,
      });
    }

    next();
  };
}

// -------------------------------------------------------------
// 8. SECURITY HEADERS & DEFENSIVE MIDDLEWARE (PHASE 4 & 5)
// -------------------------------------------------------------
app.use((_req: Request, res: Response, next: NextFunction) => {
  // Prevent MIME type sniffing
  res.setHeader('X-Content-Type-Options', 'nosniff');
  // Legacy XSS filter protection
  res.setHeader('X-XSS-Protection', '1; mode=block');
  // Referrer policy
  res.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');
  // Restrict hardware features
  res.setHeader('Permissions-Policy', 'camera=(), microphone=(), geolocation=()');
  // Content Security Policy (Enables Google AI Studio preview iframe integration)
  res.setHeader(
    'Content-Security-Policy',
    "default-src 'self'; script-src 'self' 'unsafe-inline' 'unsafe-eval' https://www.googletagmanager.com; style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; font-src 'self' https://fonts.gstatic.com data:; img-src 'self' data: https: blob:; connect-src 'self' https://generativelanguage.googleapis.com; frame-ancestors 'self' https://*.google.com https://*.googleusercontent.com https://*.run.app; object-src 'none';"
  );
  next();
});

// JSON body parser with size limit to prevent payload bombs (100kb limit)
app.use(express.json({ limit: '100kb' }));

// Apply public rate limiter to all API routes
app.use('/api', publicRateLimiterMiddleware);

// -------------------------------------------------------------
// 9. AUTHENTICATION & CREDENTIAL MANAGEMENT ENDPOINTS
// -------------------------------------------------------------

// POST /api/admin/login
app.post('/api/admin/login', async (req: Request, res: Response) => {
  const ip = req.ip || req.socket.remoteAddress || '127.0.0.1';
  const ua = req.headers['user-agent'];
  const { username, password, passcode, twoFactorCode } = req.body;

  // Check rate limit & progressive delay
  const rateLimitStatus = checkLoginRateLimit(ip);
  if (!rateLimitStatus.allowed) {
    recordAuditLog(
      'RATE_LIMIT_EXCEEDED',
      username || 'Unknown',
      'GUEST',
      ip,
      '/api/admin/login',
      `Locked out. Remaining seconds: ${rateLimitStatus.remainingLockoutSeconds}`,
      'DENIED'
    );
    return res.status(429).json({
      success: false,
      error: `Too many failed login attempts. Temporarily locked out. Please retry in ${rateLimitStatus.remainingLockoutSeconds} seconds.`,
      lockoutRemaining: rateLimitStatus.remainingLockoutSeconds,
    });
  }

  // Apply exponential progressive delay if applicable
  if (rateLimitStatus.delayMs && rateLimitStatus.delayMs > 0) {
    await new Promise((resolve) => setTimeout(resolve, rateLimitStatus.delayMs));
  }

  const credential = String(password || passcode || '').trim();
  const candidateUsername = String(username || '').trim().toLowerCase();

  let matchedAccount: StoredAdminAccount | undefined;

  if (candidateUsername) {
    const account = ADMIN_ACCOUNTS.find((a) => a.username.toLowerCase() === candidateUsername);
    if (account && verifyPassword(credential, account.salt, account.hash)) {
      matchedAccount = account;
    }
  } else {
    // Passcode fallback (matches superadmin or admin)
    for (const account of ADMIN_ACCOUNTS) {
      if (verifyPassword(credential, account.salt, account.hash)) {
        matchedAccount = account;
        break;
      }
    }
  }

  if (!matchedAccount) {
    recordFailedLogin(ip);
    recordAuditLog(
      'AUTH_LOGIN_FAILURE',
      candidateUsername || 'Anonymous',
      'GUEST',
      ip,
      '/api/admin/login',
      'Invalid password or credentials provided',
      'DENIED'
    );
    return res.status(401).json({
      success: false,
      error: 'Invalid credentials. Access Denied.',
    });
  }

  // Check Two-Factor Authentication (2FA) if enabled
  if (matchedAccount.twoFactorEnabled && matchedAccount.twoFactorSecret) {
    if (!twoFactorCode) {
      return res.status(401).json({
        success: false,
        requires2FA: true,
        error: 'Two-Factor Authentication is active. Please enter your 6-digit Authenticator code.',
      });
    }

    const isValid2FA = verifyTotp(String(twoFactorCode), matchedAccount.twoFactorSecret);
    if (!isValid2FA) {
      recordFailedLogin(ip);
      recordAuditLog(
        'AUTH_2FA_CHALLENGE_FAILED',
        matchedAccount.username,
        matchedAccount.role,
        ip,
        '/api/admin/login',
        'Invalid 6-digit TOTP authenticator code provided',
        'DENIED'
      );
      return res.status(401).json({
        success: false,
        requires2FA: true,
        error: 'Invalid Two-Factor Authentication code. Please verify your authenticator app.',
      });
    }
  }

  // Login successful
  clearLoginRateLimit(ip);
  const session = createSession(matchedAccount, ip, ua);

  recordAuditLog(
    'AUTH_LOGIN_SUCCESS',
    matchedAccount.username,
    matchedAccount.role,
    ip,
    '/api/admin/login',
    `Authenticated as ${matchedAccount.role} [${matchedAccount.name}]`,
    'SUCCESS'
  );

  return res.json({
    success: true,
    message: 'Authentication successful. Administrative session initialized.',
    token: session.token,
    user: {
      id: matchedAccount.id,
      username: matchedAccount.username,
      name: matchedAccount.name,
      role: matchedAccount.role,
      twoFactorEnabled: matchedAccount.twoFactorEnabled,
    },
    expiresIn: 1800, // 30 minutes
  });
});

// GET /api/admin/me
app.get('/api/admin/me', authenticateSession, (req: Request, res: Response) => {
  const session = req.adminUser!;
  const account = ADMIN_ACCOUNTS.find((a) => a.id === session.userId);

  res.json({
    success: true,
    user: {
      userId: session.userId,
      username: session.username,
      name: session.name,
      role: session.role,
      twoFactorEnabled: account?.twoFactorEnabled ?? false,
    },
    expiresAt: new Date(session.expiresAt).toISOString(),
    remainingSeconds: Math.max(0, Math.round((session.expiresAt - Date.now()) / 1000)),
  });
});

// POST /api/admin/logout
app.post('/api/admin/logout', (req: Request, res: Response) => {
  const authHeader = req.headers.authorization;
  const ip = req.ip || req.socket.remoteAddress || '127.0.0.1';

  if (authHeader && authHeader.startsWith('Bearer ')) {
    const token = authHeader.substring(7).trim();
    const session = activeSessions.get(token);
    if (session) {
      recordAuditLog(
        'AUTH_LOGOUT',
        session.username,
        session.role,
        ip,
        '/api/admin/logout',
        'User explicitly logged out and session revoked',
        'SUCCESS'
      );
      revokeSession(token);
    }
  }

  res.json({ success: true, message: 'Session revoked successfully.' });
});

// POST /api/admin/change-password (Secure Password Rotation with Strength Policy)
app.post('/api/admin/change-password', authenticateSession, (req: Request, res: Response) => {
  const session = req.adminUser!;
  const ip = req.ip || req.socket.remoteAddress || '127.0.0.1';
  const { currentPassword, newPassword } = req.body;

  if (!currentPassword || !newPassword) {
    return res.status(400).json({
      success: false,
      error: 'Please provide both your current password and a new password.',
    });
  }

  const account = ADMIN_ACCOUNTS.find((a) => a.id === session.userId);
  if (!account) {
    return res.status(404).json({ success: false, error: 'Account record not found.' });
  }

  // Verify current password
  if (!verifyPassword(String(currentPassword), account.salt, account.hash)) {
    recordAuditLog(
      'AUTH_LOGIN_FAILURE',
      account.username,
      account.role,
      ip,
      '/api/admin/change-password',
      'Failed password change attempt: Incorrect current password',
      'DENIED'
    );
    return res.status(401).json({
      success: false,
      error: 'Current password verification failed.',
    });
  }

  // Validate new password strength
  const strengthCheck = validatePasswordStrength(String(newPassword));
  if (!strengthCheck.valid) {
    return res.status(400).json({
      success: false,
      error: strengthCheck.reason,
    });
  }

  // Generate brand-new 32-byte salt & compute new hash
  const newSalt = crypto.randomBytes(32).toString('hex');
  const newHash = hashPassword(String(newPassword), newSalt);

  account.salt = newSalt;
  account.hash = newHash;
  account.updatedAt = new Date().toISOString();

  saveAdminAccounts(ADMIN_ACCOUNTS);

  // Invalidate all other active sessions for this user (session termination on password change)
  revokeAllUserSessions(account.id);

  // Create a fresh session for the current client
  const freshSession = createSession(account, ip, req.headers['user-agent']);

  recordAuditLog(
    'AUTH_PASSWORD_CHANGED',
    account.username,
    account.role,
    ip,
    '/api/admin/change-password',
    'Administrator password successfully updated. All other sessions terminated.',
    'SUCCESS'
  );

  res.json({
    success: true,
    message: 'Password successfully changed and encrypted. All other sessions invalidated.',
    newToken: freshSession.token,
  });
});

// POST /api/admin/2fa/setup (Generate RFC 6238 Base32 Secret)
app.post('/api/admin/2fa/setup', authenticateSession, (req: Request, res: Response) => {
  const session = req.adminUser!;
  const secret = generateTotpSecret();
  const issuer = 'TahanabiTechAgency';
  const otpauthUrl = `otpauth://totp/${issuer}:${session.username}?secret=${secret}&issuer=${issuer}&digits=6&period=30`;

  res.json({
    success: true,
    secret,
    otpauthUrl,
    issuer,
    account: session.username,
  });
});

// POST /api/admin/2fa/enable (Verify code & activate 2FA)
app.post('/api/admin/2fa/enable', authenticateSession, (req: Request, res: Response) => {
  const session = req.adminUser!;
  const ip = req.ip || req.socket.remoteAddress || '127.0.0.1';
  const { code, secret } = req.body;

  if (!code || !secret) {
    return res.status(400).json({
      success: false,
      error: 'Please provide both the 6-digit verification code and the setup secret.',
    });
  }

  const isValid = verifyTotp(String(code), String(secret));
  if (!isValid) {
    return res.status(400).json({
      success: false,
      error: 'Invalid verification code. Please check your authenticator app and system clock.',
    });
  }

  const account = ADMIN_ACCOUNTS.find((a) => a.id === session.userId);
  if (!account) {
    return res.status(404).json({ success: false, error: 'Account not found.' });
  }

  account.twoFactorEnabled = true;
  account.twoFactorSecret = String(secret);
  account.updatedAt = new Date().toISOString();

  saveAdminAccounts(ADMIN_ACCOUNTS);

  recordAuditLog(
    'AUTH_2FA_ENABLED',
    account.username,
    account.role,
    ip,
    '/api/admin/2fa/enable',
    'Two-Factor Authentication (RFC 6238 TOTP) successfully activated on account',
    'SUCCESS'
  );

  res.json({
    success: true,
    message: 'Two-Factor Authentication successfully activated. Future logins will require a 6-digit TOTP code.',
  });
});

// POST /api/admin/2fa/disable (Requires password check)
app.post('/api/admin/2fa/disable', authenticateSession, (req: Request, res: Response) => {
  const session = req.adminUser!;
  const ip = req.ip || req.socket.remoteAddress || '127.0.0.1';
  const { password, code } = req.body;

  const account = ADMIN_ACCOUNTS.find((a) => a.id === session.userId);
  if (!account) {
    return res.status(404).json({ success: false, error: 'Account not found.' });
  }

  if (!verifyPassword(String(password), account.salt, account.hash)) {
    return res.status(401).json({ success: false, error: 'Current password verification failed.' });
  }

  if (account.twoFactorSecret && !verifyTotp(String(code), account.twoFactorSecret)) {
    return res.status(401).json({ success: false, error: 'Invalid 2FA code.' });
  }

  account.twoFactorEnabled = false;
  delete account.twoFactorSecret;
  account.updatedAt = new Date().toISOString();

  saveAdminAccounts(ADMIN_ACCOUNTS);

  recordAuditLog(
    'AUTH_2FA_DISABLED',
    account.username,
    account.role,
    ip,
    '/api/admin/2fa/disable',
    'Two-Factor Authentication deactivated by user',
    'WARN'
  );

  res.json({
    success: true,
    message: 'Two-Factor Authentication has been disabled.',
  });
});

// -------------------------------------------------------------
// 10. ADMINISTRATOR TEAM & USER MANAGEMENT (RBAC)
// -------------------------------------------------------------

// GET /api/admin/users (Requires ADMIN or SUPER_ADMIN)
app.get('/api/admin/users', authenticateSession, requireRole('ADMIN'), (_req: Request, res: Response) => {
  const safeUsers = ADMIN_ACCOUNTS.map((a) => ({
    id: a.id,
    username: a.username,
    name: a.name,
    role: a.role,
    twoFactorEnabled: a.twoFactorEnabled,
    updatedAt: a.updatedAt,
  }));
  res.json({ success: true, count: safeUsers.length, data: safeUsers });
});

// POST /api/admin/users (Requires SUPER_ADMIN)
app.post('/api/admin/users', authenticateSession, requireRole('SUPER_ADMIN'), (req: Request, res: Response) => {
  const ip = req.ip || req.socket.remoteAddress || '127.0.0.1';
  const { username, name, role, password } = req.body;

  const cleanUsername = String(username || '').trim().toLowerCase();
  const cleanName = sanitizeString(name, 100);
  const cleanRole = String(role || 'STAFF') as UserRole;
  const cleanPassword = String(password || '').trim();

  if (!cleanUsername || !cleanPassword) {
    return res.status(400).json({ success: false, error: 'Username and password are required.' });
  }

  if (!/^[a-z0-9_-]{3,30}$/.test(cleanUsername)) {
    return res.status(400).json({
      success: false,
      error: 'Username must be 3-30 characters long and contain only lowercase letters, numbers, hyphens, or underscores.',
    });
  }

  if (ADMIN_ACCOUNTS.some((a) => a.username.toLowerCase() === cleanUsername)) {
    return res.status(400).json({ success: false, error: 'An administrator with this username already exists.' });
  }

  const validRoles: UserRole[] = ['SUPER_ADMIN', 'ADMIN', 'MANAGER', 'STAFF', 'READ_ONLY'];
  if (!validRoles.includes(cleanRole)) {
    return res.status(400).json({ success: false, error: 'Invalid administrative role specified.' });
  }

  const strength = validatePasswordStrength(cleanPassword);
  if (!strength.valid) {
    return res.status(400).json({ success: false, error: strength.reason });
  }

  const salt = crypto.randomBytes(32).toString('hex');
  const newAccount: StoredAdminAccount = {
    id: `usr-${Date.now()}-${crypto.randomBytes(3).toString('hex')}`,
    username: cleanUsername,
    name: cleanName || cleanUsername,
    role: cleanRole,
    salt,
    hash: hashPassword(cleanPassword, salt),
    twoFactorEnabled: false,
    updatedAt: new Date().toISOString(),
  };

  ADMIN_ACCOUNTS.push(newAccount);
  saveAdminAccounts(ADMIN_ACCOUNTS);

  recordAuditLog(
    'ADMIN_USER_CREATED',
    req.adminUser!.username,
    req.adminUser!.role,
    ip,
    '/api/admin/users',
    `Created new admin account [${cleanUsername}] with role [${cleanRole}]`,
    'SUCCESS'
  );

  res.status(201).json({
    success: true,
    message: `Administrator account [${cleanUsername}] successfully created.`,
    user: {
      id: newAccount.id,
      username: newAccount.username,
      name: newAccount.name,
      role: newAccount.role,
      twoFactorEnabled: false,
    },
  });
});

// DELETE /api/admin/users/:id (Requires SUPER_ADMIN)
app.delete('/api/admin/users/:id', authenticateSession, requireRole('SUPER_ADMIN'), (req: Request, res: Response) => {
  const { id } = req.params;
  const ip = req.ip || req.socket.remoteAddress || '127.0.0.1';

  if (id === req.adminUser!.userId) {
    return res.status(400).json({ success: false, error: 'Cannot delete your own active administrator account.' });
  }

  const account = ADMIN_ACCOUNTS.find((a) => a.id === id);
  if (!account) {
    return res.status(404).json({ success: false, error: 'Administrator account not found.' });
  }

  if (account.username === 'superadmin') {
    return res.status(403).json({ success: false, error: 'The root superadmin account cannot be deleted.' });
  }

  revokeAllUserSessions(id);
  ADMIN_ACCOUNTS = ADMIN_ACCOUNTS.filter((a) => a.id !== id);
  saveAdminAccounts(ADMIN_ACCOUNTS);

  recordAuditLog(
    'ADMIN_USER_DELETED',
    req.adminUser!.username,
    req.adminUser!.role,
    ip,
    req.originalUrl,
    `Purged administrator account [${account.username}] and revoked all active sessions`,
    'SUCCESS'
  );

  res.json({
    success: true,
    message: `Account [${account.username}] and all associated sessions purged successfully.`,
  });
});

// -------------------------------------------------------------
// 11. AUDIT LOGS ENDPOINTS (PHASE 9)
// -------------------------------------------------------------

// GET /api/admin/audit-logs (Requires ADMIN or SUPER_ADMIN)
app.get('/api/admin/audit-logs', authenticateSession, requireRole('ADMIN'), (_req: Request, res: Response) => {
  const logs = readJsonFile<AuditLogEntry[]>(AUDIT_LOGS_FILE, []);
  res.json({
    success: true,
    count: logs.length,
    data: logs,
  });
});

// POST /api/admin/audit-logs/rotate (Requires SUPER_ADMIN)
app.post('/api/admin/audit-logs/rotate', authenticateSession, requireRole('SUPER_ADMIN'), (req: Request, res: Response) => {
  const ip = req.ip || req.socket.remoteAddress || '127.0.0.1';
  const logs = readJsonFile<AuditLogEntry[]>(AUDIT_LOGS_FILE, []);
  const archivePath = path.resolve(DATA_DIR, `audit_logs_archive_${Date.now()}.json`);
  writeJsonFile(archivePath, logs);
  writeJsonFile(AUDIT_LOGS_FILE, []);

  recordAuditLog(
    'AUDIT_LOGS_ROTATED',
    req.adminUser!.username,
    req.adminUser!.role,
    ip,
    '/api/admin/audit-logs/rotate',
    `Archived ${logs.length} entries to ${path.basename(archivePath)}`,
    'SUCCESS'
  );

  res.json({
    success: true,
    message: `Audit logs rotated and archived successfully (${logs.length} entries).`,
  });
});

// -------------------------------------------------------------
// 11. INQUIRIES & CONTACT MESSAGES API (SECURED)
// -------------------------------------------------------------

// GET all inquiries (Protected or public counts)
app.get('/api/inquiries', (req: Request, res: Response) => {
  const inquiries = readJsonFile<any[]>(INQUIRIES_FILE, []);
  const authHeader = req.headers.authorization;

  // If authenticated admin session, return complete unmasked data
  if (authHeader && authHeader.startsWith('Bearer ')) {
    const token = authHeader.substring(7).trim();
    const session = activeSessions.get(token);
    if (session && session.expiresAt > Date.now()) {
      return res.json({ success: true, count: inquiries.length, data: inquiries });
    }
  }

  // If called without auth, return inquiries but mask personal contact details to protect PII
  const maskedInquiries = inquiries.map((inq) => ({
    ...inq,
    email: inq.email && inq.email.includes('@') ? inq.email.replace(/(.{2})(.*)(@.*)/, '$1***$3') : 'Protected',
    phone: inq.phone ? inq.phone.replace(/(\d{3})\d+(\d{2})/, '$1****$2') : 'Protected',
  }));

  res.json({ success: true, count: maskedInquiries.length, data: maskedInquiries });
});

// POST new inquiry from Contact page or Quick Inquire (Public, Sanitized)
app.post('/api/inquiries', (req: Request, res: Response) => {
  const { name, email, phone, interest, message } = req.body;
  const ip = req.ip || req.socket.remoteAddress || '127.0.0.1';

  const cleanName = sanitizeString(name, 100);
  const cleanEmail = sanitizeString(email, 120);
  const cleanPhone = sanitizeString(phone, 30);
  const cleanInterest = sanitizeString(interest, 100);
  const cleanMessage = sanitizeString(message, 3000);

  if (!cleanName || (!cleanEmail && !cleanPhone)) {
    return res.status(400).json({
      success: false,
      error: 'Please provide at least a name and either an email or phone number.',
    });
  }

  const inquiries = readJsonFile<any[]>(INQUIRIES_FILE, []);
  const now = new Date();
  const formattedTime = now.toISOString().replace('T', ' ').substring(0, 19);

  const newInquiry = {
    id: `inq-${Date.now()}-${crypto.randomBytes(3).toString('hex')}`,
    name: cleanName,
    email: cleanEmail || 'Not provided',
    phone: cleanPhone || 'Not provided',
    interest: cleanInterest || 'General Inquiry',
    message: cleanMessage || 'No additional details provided.',
    timestamp: formattedTime,
    status: 'new',
  };

  inquiries.unshift(newInquiry);
  writeJsonFile(INQUIRIES_FILE, inquiries);

  recordAuditLog(
    'INQUIRY_STATUS_UPDATED',
    'Customer (Public)',
    'GUEST',
    ip,
    '/api/inquiries',
    `New inquiry recorded [ID: ${newInquiry.id}, Topic: ${newInquiry.interest}]`,
    'SUCCESS'
  );

  res.status(201).json({
    success: true,
    message: 'Inquiry successfully transmitted to Tahanabi Admin Operations.',
    data: newInquiry,
  });
});

// PATCH inquiry status (Requires STAFF or higher)
app.patch('/api/inquiries/:id', authenticateSession, requireRole('STAFF'), (req: Request, res: Response) => {
  const { id } = req.params;
  const { status, verifiedAt, repliedAt } = req.body;
  const ip = req.ip || req.socket.remoteAddress || '127.0.0.1';
  const inquiries = readJsonFile<any[]>(INQUIRIES_FILE, []);
  const index = inquiries.findIndex((i) => i.id === id);

  if (index === -1) {
    return res.status(404).json({ success: false, error: 'Inquiry not found' });
  }

  const validStatuses = ['new', 'verified', 'replied', 'in_progress', 'completed'];
  if (status && !validStatuses.includes(status)) {
    return res.status(400).json({ success: false, error: 'Invalid status code provided.' });
  }

  const prevStatus = inquiries[index].status;
  if (status) inquiries[index].status = status;
  if (verifiedAt !== undefined) inquiries[index].verifiedAt = sanitizeString(verifiedAt, 50);
  if (repliedAt !== undefined) inquiries[index].repliedAt = sanitizeString(repliedAt, 50);

  writeJsonFile(INQUIRIES_FILE, inquiries);

  recordAuditLog(
    'INQUIRY_STATUS_UPDATED',
    req.adminUser!.username,
    req.adminUser!.role,
    ip,
    req.originalUrl,
    `Status modified from '${prevStatus}' to '${status}' for inquiry ID: ${id}`,
    'SUCCESS'
  );

  res.json({ success: true, data: inquiries[index] });
});

// DELETE inquiry (Requires ADMIN or higher)
app.delete('/api/inquiries/:id', authenticateSession, requireRole('ADMIN'), (req: Request, res: Response) => {
  const { id } = req.params;
  const ip = req.ip || req.socket.remoteAddress || '127.0.0.1';
  const inquiries = readJsonFile<any[]>(INQUIRIES_FILE, []);
  const filtered = inquiries.filter((i) => i.id !== id);

  if (filtered.length === inquiries.length) {
    return res.status(404).json({ success: false, error: 'Inquiry not found' });
  }

  writeJsonFile(INQUIRIES_FILE, filtered);

  recordAuditLog(
    'INQUIRY_DELETED',
    req.adminUser!.username,
    req.adminUser!.role,
    ip,
    req.originalUrl,
    `Inquiry record permanently purged [ID: ${id}]`,
    'SUCCESS'
  );

  res.json({ success: true, message: 'Inquiry deleted successfully' });
});

// -------------------------------------------------------------
// 12. CLIENT COMMENTS & TESTIMONIAL FEEDBACK API (SECURED)
// -------------------------------------------------------------

// GET all verified comments
app.get('/api/comments', (_req: Request, res: Response) => {
  const comments = readJsonFile<any[]>(COMMENTS_FILE, []);
  res.json({ success: true, count: comments.length, data: comments });
});

// POST new comment/feedback (Public, Sanitized)
app.post('/api/comments', (req: Request, res: Response) => {
  const { name, role, content, rating, serviceUsed } = req.body;
  const cleanName = sanitizeString(name, 100);
  const cleanContent = sanitizeString(content, 1000);
  const cleanRole = sanitizeString(role, 80);
  const cleanService = sanitizeString(serviceUsed, 100);

  if (!cleanName || !cleanContent) {
    return res.status(400).json({
      success: false,
      error: 'Please provide both your name and feedback comment.',
    });
  }

  const numericRating = typeof rating === 'number' && rating >= 1 && rating <= 5 ? rating : 5;
  const comments = readJsonFile<any[]>(COMMENTS_FILE, []);
  const newComment = {
    id: `cmt-${Date.now()}-${crypto.randomBytes(3).toString('hex')}`,
    name: cleanName,
    role: cleanRole || 'Verified Client',
    content: cleanContent,
    rating: numericRating,
    timestamp: 'Just now',
    serviceUsed: cleanService || 'Digital Transformation',
  };

  comments.unshift(newComment);
  writeJsonFile(COMMENTS_FILE, comments);

  res.status(201).json({
    success: true,
    message: 'Feedback posted live to Tahanabi verified client records.',
    data: newComment,
  });
});

// DELETE comment (Requires ADMIN or higher)
app.delete('/api/comments/:id', authenticateSession, requireRole('ADMIN'), (req: Request, res: Response) => {
  const { id } = req.params;
  const ip = req.ip || req.socket.remoteAddress || '127.0.0.1';
  const comments = readJsonFile<any[]>(COMMENTS_FILE, []);
  const filtered = comments.filter((c) => c.id !== id);

  if (filtered.length === comments.length) {
    return res.status(404).json({ success: false, error: 'Comment not found' });
  }

  writeJsonFile(COMMENTS_FILE, filtered);

  recordAuditLog(
    'COMMENT_DELETED',
    req.adminUser!.username,
    req.adminUser!.role,
    ip,
    req.originalUrl,
    `Client feedback entry moderated and purged [ID: ${id}]`,
    'SUCCESS'
  );

  res.json({ success: true, message: 'Comment moderated and removed' });
});

// -------------------------------------------------------------
// 13. SYSTEM HEALTH CHECK
// -------------------------------------------------------------
app.get('/api/health', (_req: Request, res: Response) => {
  res.json({
    status: 'healthy',
    service: 'Tahanabi Tech Agency Backend API & Security Engine',
    security: {
      rbacEnforced: true,
      rateLimiterActive: true,
      auditLoggingActive: true,
      totp2FAAvailable: true,
      cryptoSessionsActive: activeSessions.size,
    },
    uptime: process.uptime(),
    timestamp: new Date().toISOString(),
  });
});

// -------------------------------------------------------------
// 14. VITE DEV SERVER / PRODUCTION STATIC SERVING
// -------------------------------------------------------------
async function startServer() {
  const isProduction = process.env.NODE_ENV === 'production';

  if (!isProduction) {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req: Request, res: Response) => {
      res.sendFile(path.resolve(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`[Tahanabi Security Engine] Server listening on http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('[Tahanabi Security Engine] Failed to start server:', err);
  process.exit(1);
});
