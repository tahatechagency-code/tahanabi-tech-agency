/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { NavigationProvider, useNavigation } from './context/NavigationContext';
import { InquiryProvider } from './context/InquiryContext';
import { Header } from './components/Header';
import { Footer } from './components/Footer';
import { SEO } from './components/SEO';
import { HomePage } from './pages/HomePage';
import { WorkPage } from './pages/WorkPage';
import { ServicesPage } from './pages/ServicesPage';
import { AIAutomationPage } from './pages/AIAutomationPage';
import { AboutPage } from './pages/AboutPage';
import { ContactPage } from './pages/ContactPage';
import { AdminPage } from './pages/AdminPage';

const ROUTE_SEO: Record<string, { title: string; description: string }> = {
  '/': {
    title: 'Digital Products & AI Automation for Global Businesses',
    description:
      'We build premium websites, e-commerce solutions and AI automation systems for businesses worldwide. 100% Verified Technical Pedigree from NIT Trichy & R.K. College.',
  },
  '/work': {
    title: 'Our Work & Industry Portfolio',
    description:
      'Explore high-conversion digital solutions built across Jewellery E-commerce, Fleet Management, Retail & Fashion, Real Estate, and Healthcare with 100% Verified Technical Pedigree.',
  },
  '/services': {
    title: 'Digital & AI Automation Services',
    description:
      'End-to-end digital engineering and AI automation solutions. Sub-second performance, dual cybersecurity audits, and 100% intellectual property ownership.',
  },
  '/ai-automation': {
    title: 'AI Automation & Conversational Concierge',
    description:
      'Autonomous AI agents, 24/7 WhatsApp concierge, and instant CRM synchronization engineered with NIT Trichy systems architecture standards.',
  },
  '/about': {
    title: 'About Us — 100% Verified Technical Pedigree',
    description:
      'Founded by MD Juned (B.Tech, NIT Trichy 2025) and Satpal Kumar (BCA, R.K. College, Madhubani) with 2 in-house security engineers and verified physical operations studio.',
  },
  '/contact': {
    title: 'Contact Our Leadership & Studio',
    description:
      'Initiate your project consultation directly with MD Juned (CEO) and Satpal Kumar (Founder). Direct founder access, NDA confidentiality, and rapid turnaround.',
  },
  '/admin': {
    title: 'Admin Operations Console',
    description:
      'Tahanabi Tech Agency private management console for live client inquiries, verified feedback moderation, and operational settings.',
  },
};

const AppContent: React.FC = () => {
  const { currentPath } = useNavigation();
  const pageSEO = ROUTE_SEO[currentPath] || ROUTE_SEO['/'];

  // Route 7: Admin Panel has its own specialized self-contained console layout
  if (currentPath === '/admin') {
    return (
      <>
        <SEO title={pageSEO.title} description={pageSEO.description} path={currentPath} />
        <AdminPage />
      </>
    );
  }

  // The 6 public routes share the consistent header, compact footer, and dynamic SEO
  return (
    <div className="min-h-screen flex flex-col bg-[#FFF8F0] text-[#29180F] selection:bg-[#F4E7DA] selection:text-[#29180F]">
      <SEO title={pageSEO.title} description={pageSEO.description} path={currentPath} />
      <Header />
      <main className="flex-1">
        {currentPath === '/' && <HomePage />}
        {currentPath === '/work' && <WorkPage />}
        {currentPath === '/services' && <ServicesPage />}
        {currentPath === '/ai-automation' && <AIAutomationPage />}
        {currentPath === '/about' && <AboutPage />}
        {currentPath === '/contact' && <ContactPage />}
      </main>
      <Footer />
    </div>
  );
};

export default function App() {
  return (
    <NavigationProvider>
      <InquiryProvider>
        <AppContent />
      </InquiryProvider>
    </NavigationProvider>
  );
}
