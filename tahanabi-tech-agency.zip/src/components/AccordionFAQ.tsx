import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  ChevronDown,
  HelpCircle,
  ShieldCheck,
  ArrowRight,
  MessageCircle,
  CornerDownRight,
  CheckCircle2,
  Sparkles,
  Link2,
  Check,
  Layers,
} from 'lucide-react';
import { useNavigation } from '../context/NavigationContext';

import {
  generateAndValidateFaqSchema,
  AccordionFaqItem,
  SubQuestionItem,
} from '../utils/faqSchema';

export type { AccordionFaqItem, SubQuestionItem };

interface AccordionFAQProps {
  title?: string;
  subtitle?: string;
  badge?: string;
  items: AccordionFaqItem[];
  defaultOpenId?: string;
}

export const AccordionFAQ: React.FC<AccordionFAQProps> = ({
  title = 'Frequently Asked Questions',
  subtitle = 'Institutional clarity on technical pedigree, security protocols, code ownership, and project milestones.',
  badge = 'Transparency & Trust',
  items,
  defaultOpenId,
}) => {
  const { navigate } = useNavigation();
  const [openId, setOpenId] = useState<string | null>(defaultOpenId || items[0]?.id || null);
  // Store open state per sub-question id for independent smooth toggle
  const [openSubKeys, setOpenSubKeys] = useState<Record<string, boolean>>({});
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const toggleTopLevel = (id: string) => {
    setOpenId((prev) => (prev === id ? null : id));
  };

  const toggleSubItem = (subId: string) => {
    setOpenSubKeys((prev) => ({
      ...prev,
      [subId]: !prev[subId],
    }));
  };

  const expandAll = () => {
    if (items.length === 0) return;
    setOpenId(items[0].id);
    const allSubs: Record<string, boolean> = {};
    items.forEach((item) => {
      item.nestedQuestions?.forEach((sub) => {
        allSubs[sub.id] = true;
      });
    });
    setOpenSubKeys(allSubs);
  };

  const collapseAll = () => {
    setOpenId(null);
    setOpenSubKeys({});
  };

  // URL hash navigation support: auto-open FAQ if navigated with #faq-id
  React.useEffect(() => {
    if (typeof window === 'undefined') return;
    const hash = window.location.hash.replace('#', '');
    if (!hash) return;

    const matchedItem = items.find((i) => i.id === hash || `faq-${i.id}` === hash);
    if (matchedItem) {
      setOpenId(matchedItem.id);
      const el = document.getElementById(matchedItem.id) || document.getElementById(`faq-${matchedItem.id}`);
      if (el) {
        setTimeout(() => el.scrollIntoView({ behavior: 'smooth', block: 'center' }), 150);
      }
    }
  }, [items]);

  // Copy direct anchor link for shareability
  const handleCopyLink = (e: React.MouseEvent, id: string) => {
    e.stopPropagation();
    if (typeof window === 'undefined') return;
    const url = `${window.location.origin}${window.location.pathname}#faq-${id}`;
    navigator.clipboard?.writeText(url).then(() => {
      setCopiedId(id);
      setTimeout(() => setCopiedId(null), 2000);
    }).catch(() => {});
  };

  // Automatically generate & validate Schema.org FAQPage structured data (JSON-LD) using utility
  const { schema: faqStructuredData, validation } = React.useMemo(() => {
    const origin = typeof window !== 'undefined' ? window.location.origin : 'https://tahanabi.agency';
    const path = typeof window !== 'undefined' ? window.location.pathname : '';
    const pageUrl = `${origin}${path}`;

    return generateAndValidateFaqSchema({
      items,
      title,
      description: subtitle,
      pageUrl,
      origin,
      language: 'en',
      includeNested: true,
    });
  }, [items, title, subtitle]);

  // Synchronize JSON-LD into document.head for strict crawler validation
  React.useEffect(() => {
    if (typeof document === 'undefined') return;
    const scriptId = `faq-jsonld-${title.toLowerCase().replace(/[^a-z0-9]/g, '-')}`;
    let scriptTag = document.getElementById(scriptId) as HTMLScriptElement | null;
    if (!scriptTag) {
      scriptTag = document.createElement('script');
      scriptTag.id = scriptId;
      scriptTag.type = 'application/ld+json';
      document.head.appendChild(scriptTag);
    }
    scriptTag.textContent = JSON.stringify(faqStructuredData);

    return () => {
      const el = document.getElementById(scriptId);
      if (el) {
        el.remove();
      }
    };
  }, [faqStructuredData, title]);

  return (
    <section className="w-full my-12 sm:my-16" id={`section-faq-${title.toLowerCase().replace(/[^a-z0-9]/g, '-')}`}>
      {/* Schema.org FAQPage Structured Data (JSON-LD in-body fallback) */}
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(faqStructuredData) }}
      />

      <div className="bg-[#FFFDF9] rounded-3xl p-6 sm:p-10 lg:p-12 border border-[#EAD8C7] shadow-lg">
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto mb-10 space-y-3">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-[#F4E7DA] text-[#29180F] text-xs font-bold border border-[#EAD8C7] shadow-2xs">
            <HelpCircle className="w-3.5 h-3.5 text-[#C58A3D]" />
            <span>{badge}</span>
          </div>

          <h2 className="font-serif text-2xl sm:text-3xl lg:text-4xl font-semibold text-[#29180F]">
            {title}
          </h2>

          {subtitle && (
            <p className="text-xs sm:text-sm text-[#29180F]/75 max-w-2xl mx-auto leading-relaxed">
              {subtitle}
            </p>
          )}

          {/* Controls Bar: Total Questions + Expand/Collapse All */}
          <div className="pt-2 flex flex-wrap items-center justify-between gap-3 max-w-4xl mx-auto text-xs text-[#29180F]/70 border-t border-[#EAD8C7]/60">
            <div className="flex items-center gap-2">
              <span className="font-semibold text-[#29180F]">
                {items.length} Primary Inquiries
              </span>
              <span>&middot;</span>
              <span>
                {items.reduce((acc, curr) => acc + (curr.nestedQuestions?.length || 0), 0)} Nested Drill-Downs
              </span>
              <span>&middot;</span>
              <span className="text-[#C58A3D] font-medium inline-flex items-center gap-1">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                <span>Google Schema Validated ({validation.questionCount} Entities)</span>
              </span>
            </div>

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={expandAll}
                className="px-2.5 py-1 rounded-lg bg-[#F4E7DA] hover:bg-[#EAD8C7] text-[#29180F] text-[11px] font-semibold transition-colors cursor-pointer"
              >
                Expand All
              </button>
              <button
                type="button"
                onClick={collapseAll}
                className="px-2.5 py-1 rounded-lg bg-[#FFFDF9] border border-[#EAD8C7] hover:bg-[#F4E7DA] text-[#29180F] text-[11px] font-semibold transition-colors cursor-pointer"
              >
                Collapse All
              </button>
            </div>
          </div>
        </div>

        {/* Primary Accordion List */}
        <div className="max-w-4xl mx-auto space-y-4">
          {items.map((item, index) => {
            const isOpen = openId === item.id;
            const isCopied = copiedId === item.id;

            return (
              <div
                key={item.id}
                id={`faq-${item.id}`}
                className={`rounded-2xl border transition-colors duration-200 overflow-hidden scroll-mt-24 ${
                  isOpen
                    ? 'bg-[#FFF8F0] border-[#C58A3D] shadow-sm'
                    : 'bg-[#FFFDF9] border-[#EAD8C7] hover:border-[#C58A3D]/60'
                }`}
              >
                {/* Top-Level Question Header */}
                <button
                  type="button"
                  onClick={() => toggleTopLevel(item.id)}
                  aria-expanded={isOpen}
                  className="w-full py-4 sm:py-5 px-5 sm:px-6 flex items-center justify-between gap-4 text-left cursor-pointer focus:outline-hidden"
                >
                  <div className="flex items-center gap-3 sm:gap-4 flex-1">
                    <span
                      className={`w-7 h-7 rounded-full flex items-center justify-center text-xs font-mono font-bold shrink-0 transition-colors ${
                        isOpen
                          ? 'bg-[#29180F] text-[#C58A3D]'
                          : 'bg-[#F4E7DA] text-[#29180F]/70'
                      }`}
                    >
                      {String(index + 1).padStart(2, '0')}
                    </span>
                    <span className="font-serif text-base sm:text-lg font-semibold text-[#29180F] leading-snug">
                      {item.question}
                    </span>
                  </div>

                  <div className="flex items-center gap-2 sm:gap-3 shrink-0">
                    {/* Share / Copy Deep Link Button */}
                    <button
                      type="button"
                      title="Copy link to this FAQ"
                      onClick={(e) => handleCopyLink(e, item.id)}
                      className="p-1.5 rounded-md hover:bg-[#F4E7DA] text-[#29180F]/50 hover:text-[#29180F] transition-colors cursor-pointer"
                    >
                      {isCopied ? (
                        <Check className="w-3.5 h-3.5 text-emerald-600" />
                      ) : (
                        <Link2 className="w-3.5 h-3.5" />
                      )}
                    </button>

                    {item.tag && (
                      <span className="hidden sm:inline-block px-2.5 py-0.5 rounded-md bg-[#F4E7DA] text-[#C58A3D] text-[10px] font-bold uppercase tracking-wider">
                        {item.tag}
                      </span>
                    )}

                    <motion.div
                      animate={{ rotate: isOpen ? 180 : 0 }}
                      transition={{ duration: 0.22, ease: 'easeInOut' }}
                      className={`w-7 h-7 rounded-lg flex items-center justify-center ${
                        isOpen
                          ? 'bg-[#C58A3D] text-[#FFF8F0]'
                          : 'bg-[#F4E7DA] text-[#29180F]'
                      }`}
                    >
                      <ChevronDown className="w-4 h-4" />
                    </motion.div>
                  </div>
                </button>

                {/* Smooth Animated Top-Level Content */}
                <AnimatePresence initial={false}>
                  {isOpen && (
                    <motion.div
                      key={`content-${item.id}`}
                      initial={{ opacity: 0, height: 0 }}
                      animate={{ opacity: 1, height: 'auto' }}
                      exit={{ opacity: 0, height: 0 }}
                      transition={{ duration: 0.28, ease: [0.04, 0.62, 0.23, 0.98] }}
                      className="overflow-hidden"
                    >
                      <div className="px-5 sm:px-6 pb-6 pt-1 text-xs sm:text-sm text-[#29180F]/85 leading-relaxed border-t border-[#EAD8C7]/60">
                        {/* Primary Answer */}
                        {item.answer && (
                          <p className="whitespace-pre-line text-[#29180F]/85 mb-4">
                            {item.answer}
                          </p>
                        )}

                        {/* Nested Sub-Questions & Answers */}
                        {item.nestedQuestions && item.nestedQuestions.length > 0 && (
                          <div className="mt-4 pt-3.5 border-t border-[#EAD8C7]/70 space-y-2.5">
                            <div className="text-[11px] uppercase tracking-wider font-bold text-[#C58A3D] flex items-center justify-between gap-2 mb-2">
                              <div className="flex items-center gap-1.5">
                                <CornerDownRight className="w-3.5 h-3.5 text-[#C58A3D]" />
                                <span>Detailed Drill-Down Questions ({item.nestedQuestions.length}):</span>
                              </div>
                              <span className="text-[10px] font-normal text-[#29180F]/60">
                                Click any sub-question to reveal exact technical breakdown
                              </span>
                            </div>

                            <div className="space-y-2 pl-1 sm:pl-3">
                              {item.nestedQuestions.map((sub) => {
                                const isSubOpen = Boolean(openSubKeys[sub.id]);

                                return (
                                  <div
                                    key={sub.id}
                                    id={`faq-sub-${sub.id}`}
                                    className={`rounded-xl border transition-colors duration-150 overflow-hidden ${
                                      isSubOpen
                                        ? 'bg-[#FFFDF9] border-[#C58A3D]/80 shadow-2xs'
                                        : 'bg-[#FFFDF9]/80 border-[#EAD8C7] hover:border-[#C58A3D]/50'
                                    }`}
                                  >
                                    <button
                                      type="button"
                                      onClick={() => toggleSubItem(sub.id)}
                                      aria-expanded={isSubOpen}
                                      className="w-full py-2.5 sm:py-3 px-3.5 sm:px-4 flex items-center justify-between gap-3 text-left cursor-pointer focus:outline-hidden"
                                    >
                                      <div className="flex items-center gap-2">
                                        <CheckCircle2 className="w-3.5 h-3.5 text-[#C58A3D] shrink-0" />
                                        <span className="font-serif text-xs sm:text-sm font-semibold text-[#29180F]">
                                          {sub.question}
                                        </span>
                                      </div>

                                      <div className="flex items-center gap-2 shrink-0">
                                        {sub.badge && (
                                          <span className="hidden md:inline-block px-2 py-0.5 rounded text-[9px] font-bold bg-[#F4E7DA] text-[#29180F]/80">
                                            {sub.badge}
                                          </span>
                                        )}
                                        <motion.div
                                          animate={{ rotate: isSubOpen ? 180 : 0 }}
                                          transition={{ duration: 0.18 }}
                                          className="text-[#C58A3D]"
                                        >
                                          <ChevronDown className="w-3.5 h-3.5" />
                                        </motion.div>
                                      </div>
                                    </button>

                                    <AnimatePresence initial={false}>
                                      {isSubOpen && (
                                        <motion.div
                                          key={`sub-content-${sub.id}`}
                                          initial={{ opacity: 0, height: 0 }}
                                          animate={{ opacity: 1, height: 'auto' }}
                                          exit={{ opacity: 0, height: 0 }}
                                          transition={{ duration: 0.22, ease: 'easeOut' }}
                                          className="overflow-hidden"
                                        >
                                          <div className="px-3.5 sm:px-4 pb-3.5 pt-1 text-[11px] sm:text-xs text-[#29180F]/80 leading-relaxed border-t border-[#EAD8C7]/50 bg-[#F4E7DA]/20">
                                            {sub.answer}
                                          </div>
                                        </motion.div>
                                      )}
                                    </AnimatePresence>
                                  </div>
                                );
                              })}
                            </div>
                          </div>
                        )}
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            );
          })}
        </div>

        {/* Bottom Founder Assistance Callout */}
        <div className="mt-10 pt-8 border-t border-[#EAD8C7] flex flex-col sm:flex-row items-center justify-between gap-4 max-w-4xl mx-auto bg-[#F4E7DA]/50 rounded-2xl p-5 border border-[#EAD8C7]/80">
          <div className="flex items-center gap-3 text-left">
            <div className="w-10 h-10 rounded-xl bg-[#29180F] text-[#C58A3D] flex items-center justify-center shrink-0">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <div className="font-serif text-sm font-bold text-[#29180F]">
                Have a specialized technical question or enterprise RFP?
              </div>
              <div className="text-[11px] text-[#29180F]/70">
                Direct founder consultation with MD Juned (NIT Trichy 2025) and Satpal Kumar (R.K. College).
              </div>
            </div>
          </div>

          <div className="flex items-center gap-3 shrink-0 w-full sm:w-auto">
            <a
              href="https://wa.me/919128596443"
              target="_blank"
              rel="noreferrer"
              className="flex-1 sm:flex-none inline-flex items-center justify-center gap-1.5 px-4 py-2.5 rounded-xl bg-[#25D366] text-white hover:bg-[#20ba59] text-xs font-semibold shadow-xs transition-colors"
            >
              <MessageCircle className="w-3.5 h-3.5" />
              <span>WhatsApp</span>
            </a>
            <button
              type="button"
              onClick={() => navigate('/contact')}
              className="flex-1 sm:flex-none inline-flex items-center justify-center gap-1.5 px-4 py-2.5 rounded-xl bg-[#29180F] text-[#FFF8F0] hover:bg-[#1F120B] text-xs font-semibold shadow-xs transition-colors cursor-pointer"
            >
              <span>Ask Founders</span>
              <ArrowRight className="w-3.5 h-3.5 text-[#C58A3D]" />
            </button>
          </div>
        </div>
      </div>
    </section>
  );
};
