import React from 'react';

interface BrandLogoProps {
  className?: string;
  isLightMode?: boolean;
}

export const BrandLogo: React.FC<BrandLogoProps> = ({ className = '', isLightMode = true }) => {
  return (
    <div className={`flex items-center gap-3 select-none ${className}`}>
      {/* Golden star-style luxury symbol */}
      <div className="relative flex items-center justify-center w-8 h-8 rounded-lg bg-gradient-to-br from-[#E6BC7E] via-[#C58A3D] to-[#99651F] shadow-sm shadow-[#C58A3D]/25 shrink-0">
        <svg
          viewBox="0 0 24 24"
          className="w-5 h-5 text-white"
          fill="currentColor"
          xmlns="http://www.w3.org/2000/svg"
        >
          {/* Four-pointed refined luxury faceted star */}
          <path d="M12 1L14.2 9.8L23 12L14.2 14.2L12 23L9.8 14.2L1 12L9.8 9.8L12 1Z" />
        </svg>
      </div>

      <div className="flex flex-col text-left">
        <span
          className={`font-serif text-lg tracking-[0.14em] font-semibold leading-tight ${
            isLightMode ? 'text-[#29180F]' : 'text-[#FFF8F0]'
          }`}
        >
          TAHANABI
        </span>
        <span
          className={`text-[9.5px] uppercase tracking-[0.24em] font-medium leading-none ${
            isLightMode ? 'text-[#C58A3D]' : 'text-[#E6BC7E]'
          }`}
        >
          Tech Agency
        </span>
      </div>
    </div>
  );
};
