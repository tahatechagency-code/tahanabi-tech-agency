import React, { useState, useEffect } from 'react';
import { ClientComment } from '../types';
import { Star, MessageSquare, CheckCircle2, Send, Sparkles, Building, User } from 'lucide-react';

interface ClientFeedbackSectionProps {
  title?: string;
  subtitle?: string;
}

export const ClientFeedbackSection: React.FC<ClientFeedbackSectionProps> = ({
  title = 'Verified Client Reviews & Public Commentary',
  subtitle = 'Transparent feedback from global business leaders who engineered their digital products with Tahanabi.',
}) => {
  const [comments, setComments] = useState<ClientComment[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);

  // Form fields
  const [name, setName] = useState('');
  const [role, setRole] = useState('');
  const [serviceUsed, setServiceUsed] = useState('Jewellery E-commerce + AI Concierge');
  const [content, setContent] = useState('');
  const [rating, setRating] = useState(5);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitSuccess, setSubmitSuccess] = useState(false);
  const [submitError, setSubmitError] = useState('');

  const fetchComments = async () => {
    try {
      const res = await fetch('/api/comments');
      const data = await res.json();
      if (data.success && Array.isArray(data.data)) {
        setComments(data.data);
      }
    } catch (err) {
      console.warn('Using local fallback for comments', err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchComments();
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !content.trim()) {
      setSubmitError('Please fill in your name and review message.');
      return;
    }

    setIsSubmitting(true);
    setSubmitError('');

    try {
      const res = await fetch('/api/comments', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: name.trim(),
          role: role.trim() || 'Verified Client',
          serviceUsed,
          content: content.trim(),
          rating,
        }),
      });

      const result = await res.json();
      if (result.success && result.data) {
        setComments((prev) => [result.data, ...prev]);
        setSubmitSuccess(true);
        setName('');
        setRole('');
        setContent('');
        setTimeout(() => {
          setSubmitSuccess(false);
          setShowForm(false);
        }, 2500);
      } else {
        setSubmitError(result.error || 'Failed to submit feedback.');
      }
    } catch {
      setSubmitError('Network connection issue. Please retry.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="w-full bg-[#FFFDF9] rounded-3xl p-6 sm:p-8 lg:p-10 border border-[#EAD8C7] shadow-lg">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-end justify-between pb-6 mb-8 border-b border-[#EAD8C7] gap-4">
        <div>
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#F4E7DA] text-[#29180F] text-xs font-semibold mb-2 border border-[#EAD8C7]">
            <Sparkles className="w-3.5 h-3.5 text-[#C58A3D]" />
            <span>Real-Time Public Feedback Conduits</span>
          </div>
          <h3 className="font-serif text-2xl sm:text-3xl font-semibold text-[#29180F]">
            {title}
          </h3>
          <p className="text-xs sm:text-sm text-[#29180F]/70 mt-1 max-w-xl">
            {subtitle}
          </p>
        </div>

        <button
          onClick={() => setShowForm(!showForm)}
          className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-[#29180F] text-[#FFF8F0] hover:bg-[#1F120B] text-xs font-semibold shadow-xs hover:shadow transition-colors shrink-0 cursor-pointer"
        >
          <MessageSquare className="w-3.5 h-3.5 text-[#C58A3D]" />
          <span>{showForm ? 'Close Form' : 'Write a Client Review'}</span>
        </button>
      </div>

      {/* Interactive Form for Posting Live Comments */}
      {showForm && (
        <form
          onSubmit={handleSubmit}
          className="mb-8 p-5 sm:p-6 rounded-2xl bg-[#FFF8F0] border border-[#C58A3D]/40 shadow-xs space-y-4 animate-in fade-in duration-200"
        >
          <div className="flex items-center justify-between pb-3 border-b border-[#EAD8C7]">
            <span className="font-serif text-sm font-semibold text-[#29180F]">
              Submit Authentic Client Commentary
            </span>
            <span className="text-[11px] text-[#C58A3D] font-medium">Live Server Sync</span>
          </div>

          {submitSuccess ? (
            <div className="py-4 text-center space-y-1">
              <CheckCircle2 className="w-6 h-6 text-[#25D366] mx-auto" />
              <p className="text-xs font-semibold text-[#29180F]">
                Thank you! Your feedback has been published to Tahanabi verified records.
              </p>
            </div>
          ) : (
            <>
              {submitError && (
                <div className="p-2.5 rounded-lg bg-rose-50 border border-rose-200 text-xs text-rose-700">
                  {submitError}
                </div>
              )}

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-[11px] font-semibold text-[#29180F]/80 uppercase tracking-wider mb-1">
                    Your Full Name *
                  </label>
                  <input
                    type="text"
                    required
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="e.g. Tariq Al-Mansoor"
                    className="w-full text-xs px-3 py-2 rounded-lg bg-[#FFFDF9] border border-[#EAD8C7] focus:border-[#C58A3D] focus:outline-none text-[#29180F]"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-semibold text-[#29180F]/80 uppercase tracking-wider mb-1">
                    Role / Company &amp; City
                  </label>
                  <input
                    type="text"
                    value={role}
                    onChange={(e) => setRole(e.target.value)}
                    placeholder="e.g. Managing Director, Mansoor Group (Dubai)"
                    className="w-full text-xs px-3 py-2 rounded-lg bg-[#FFFDF9] border border-[#EAD8C7] focus:border-[#C58A3D] focus:outline-none text-[#29180F]"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-[11px] font-semibold text-[#29180F]/80 uppercase tracking-wider mb-1">
                    Service Deployed
                  </label>
                  <select
                    value={serviceUsed}
                    onChange={(e) => setServiceUsed(e.target.value)}
                    className="w-full text-xs px-3 py-2 rounded-lg bg-[#FFFDF9] border border-[#EAD8C7] focus:border-[#C58A3D] focus:outline-none text-[#29180F]"
                  >
                    <option value="Jewellery E-commerce + AI Concierge">Jewellery E-commerce + AI Concierge</option>
                    <option value="Car Service & Fleet Automation">Car Service &amp; Fleet Automation</option>
                    <option value="Retail & Fashion E-commerce">Retail &amp; Fashion E-commerce</option>
                    <option value="Custom Web & App Development">Custom Web &amp; App Development</option>
                    <option value="AI Automation & Conversational Bot">AI Automation &amp; Conversational Bot</option>
                    <option value="Enterprise Architecture & Security Audit">Enterprise Architecture &amp; Security Audit</option>
                  </select>
                </div>

                <div>
                  <label className="block text-[11px] font-semibold text-[#29180F]/80 uppercase tracking-wider mb-1">
                    Quality Rating
                  </label>
                  <div className="flex items-center gap-1.5 pt-1">
                    {[1, 2, 3, 4, 5].map((star) => (
                      <button
                        type="button"
                        key={star}
                        onClick={() => setRating(star)}
                        className="p-1 focus:outline-none cursor-pointer"
                      >
                        <Star
                          className={`w-5 h-5 ${
                            star <= rating
                              ? 'text-[#C58A3D] fill-[#C58A3D]'
                              : 'text-[#EAD8C7]'
                          }`}
                        />
                      </button>
                    ))}
                    <span className="text-xs font-semibold text-[#29180F] ml-2">
                      {rating} of 5 Stars
                    </span>
                  </div>
                </div>
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-[#29180F]/80 uppercase tracking-wider mb-1">
                  Your Review / Commentary *
                </label>
                <textarea
                  required
                  rows={3}
                  value={content}
                  onChange={(e) => setContent(e.target.value)}
                  placeholder="Share details regarding the engineering quality, NIT Trichy technical leadership, or security audit experience..."
                  className="w-full text-xs px-3 py-2 rounded-lg bg-[#FFFDF9] border border-[#EAD8C7] focus:border-[#C58A3D] focus:outline-none text-[#29180F]"
                />
              </div>

              <div className="flex justify-end gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => setShowForm(false)}
                  className="px-4 py-2 rounded-lg border border-[#EAD8C7] text-xs font-medium text-[#29180F] hover:bg-[#F4E7DA] cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="inline-flex items-center gap-2 px-5 py-2 rounded-lg bg-[#29180F] text-[#FFF8F0] hover:bg-[#1F120B] text-xs font-semibold cursor-pointer disabled:opacity-50"
                >
                  <Send className="w-3.5 h-3.5 text-[#C58A3D]" />
                  <span>{isSubmitting ? 'Posting...' : 'Publish Feedback Live'}</span>
                </button>
              </div>
            </>
          )}
        </form>
      )}

      {/* Live List of Comments */}
      {isLoading ? (
        <div className="py-12 text-center text-xs text-[#29180F]/60">
          Loading live client commentary...
        </div>
      ) : comments.length === 0 ? (
        <div className="py-8 text-center text-xs text-[#29180F]/60">
          No commentary posted yet. Be the first to leave verified feedback!
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {comments.map((comment) => (
            <div
              key={comment.id}
              className="bg-[#FFF8F0] rounded-2xl p-5 border border-[#EAD8C7] hover:border-[#C58A3D] transition-all flex flex-col justify-between"
            >
              <div>
                {/* Header: Stars & Date */}
                <div className="flex items-center justify-between gap-2 mb-3">
                  <div className="flex items-center gap-0.5">
                    {Array.from({ length: 5 }).map((_, i) => (
                      <Star
                        key={i}
                        className={`w-3.5 h-3.5 ${
                          i < comment.rating
                            ? 'text-[#C58A3D] fill-[#C58A3D]'
                            : 'text-[#EAD8C7]'
                        }`}
                      />
                    ))}
                  </div>
                  <span className="text-[10px] text-[#29180F]/50 font-mono">
                    {comment.timestamp}
                  </span>
                </div>

                {/* Content */}
                <p className="text-xs text-[#29180F]/85 leading-relaxed italic mb-4">
                  &ldquo;{comment.content}&rdquo;
                </p>
              </div>

              {/* Author & Service Badge */}
              <div className="pt-3 border-t border-[#EAD8C7]/60">
                <div className="flex items-start justify-between gap-2">
                  <div>
                    <h4 className="font-serif text-xs font-semibold text-[#29180F]">
                      {comment.name}
                    </h4>
                    <p className="text-[11px] text-[#29180F]/65 mt-0.5">
                      {comment.role}
                    </p>
                  </div>
                  <CheckCircle2 className="w-3.5 h-3.5 text-[#25D366] shrink-0 mt-0.5" />
                </div>
                <div className="mt-2">
                  <span className="inline-block text-[10px] px-2 py-0.5 rounded-md bg-[#F4E7DA] text-[#29180F]/80 font-medium">
                    {comment.serviceUsed}
                  </span>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
