import React from 'react';
import { useNavigation } from '../context/NavigationContext';
import { BrandLogo } from './BrandLogo';
import { MessageCircle, Phone, Mail, ArrowUpRight, Lock } from 'lucide-react';
import { AppRoute } from '../types';

export const Footer: React.FC = () => {
  const { navigate } = useNavigation();

  const links: { label: string; route: AppRoute }[] = [
    { label: 'Home', route: '/' },
    { label: 'Work', route: '/work' },
    { label: 'Services', route: '/services' },
    { label: 'AI Automation', route: '/ai-automation' },
    { label: 'About', route: '/about' },
    { label: 'Contact', route: '/contact' },
  ];

  return (
    <footer className="w-full bg-[#29180F] text-[#FFF8F0] border-t border-[#1F120B]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
        <div className="grid grid-cols-1 md:grid-cols-12 gap-8 items-start">
          {/* Brand & Description */}
          <div className="md:col-span-5 space-y-3">
            <button
              onClick={() => navigate('/')}
              className="text-left focus:outline-none transition-transform active:scale-98"
            >
              <BrandLogo isLightMode={false} />
            </button>
            <p className="text-xs text-[#FFF8F0]/70 max-w-sm leading-relaxed">
              A global digital and AI automation agency helping businesses grow with technology,
              design and intelligent automation.
            </p>

            {/* Quick Contact Chips */}
            <div className="flex flex-wrap items-center gap-2 pt-1 text-xs">
              <a
                href="https://wa.me/919128596443"
                target="_blank"
                rel="noreferrer"
                className="inline-flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-[#25D366]/15 text-[#25D366] hover:bg-[#25D366]/25 border border-[#25D366]/30 transition-colors"
                title="Chat on WhatsApp"
              >
                <MessageCircle className="w-3.5 h-3.5" />
                <span className="font-medium">+91 91285 96443</span>
              </a>
              <a
                href="mailto:tahanabitechagency@gmail.com"
                className="inline-flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-[#FFF8F0]/10 text-[#FFF8F0]/80 hover:text-white hover:bg-[#FFF8F0]/15 transition-colors"
                title="Send Email"
              >
                <Mail className="w-3.5 h-3.5 text-[#C58A3D]" />
                <span>tahanabitechagency@gmail.com</span>
              </a>
            </div>
          </div>

          {/* Navigation Links */}
          <div className="md:col-span-4">
            <span className="text-[11px] font-semibold uppercase tracking-wider text-[#C58A3D] block mb-3">
              Agency Navigation
            </span>
            <div className="grid grid-cols-2 gap-y-2 gap-x-4 text-xs">
              {links.map((link) => (
                <button
                  key={link.route}
                  onClick={() => navigate(link.route)}
                  className="text-left text-[#FFF8F0]/75 hover:text-[#C58A3D] transition-colors py-1 cursor-pointer flex items-center justify-between group"
                >
                  <span>{link.label}</span>
                  <ArrowUpRight className="w-3 h-3 opacity-0 group-hover:opacity-100 transition-opacity text-[#C58A3D]" />
                </button>
              ))}
            </div>
          </div>

          {/* Working Links & Admin */}
          <div className="md:col-span-3 space-y-3">
            <span className="text-[11px] font-semibold uppercase tracking-wider text-[#C58A3D] block mb-3">
              Direct Contact
            </span>
            <div className="space-y-2 text-xs text-[#FFF8F0]/75">
              <a
                href="tel:+919128596443"
                className="flex items-center gap-2 hover:text-[#C58A3D] transition-colors"
              >
                <Phone className="w-3.5 h-3.5 text-[#C58A3D]" />
                <span>Call: +91 91285 96443</span>
              </a>
              <a
                href="https://wa.me/919128596443"
                target="_blank"
                rel="noreferrer"
                className="flex items-center gap-2 hover:text-[#25D366] transition-colors"
              >
                <MessageCircle className="w-3.5 h-3.5 text-[#25D366]" />
                <span>WhatsApp: Instant Connect</span>
              </a>
              <a
                href="https://www.google.com/maps/@26.44282,85.9019995,15z?entry=ttu&g_ep=EgoyMDI2MTEwNC4wIKXMDSoASAFQAw%3D%3D"
                target="_blank"
                rel="noreferrer"
                className="flex items-center gap-2 hover:text-[#C58A3D] transition-colors"
              >
                <span className="w-3.5 h-3.5 text-[#C58A3D] flex items-center justify-center">
                  <svg className="w-3.5 h-3.5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                    <path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z" />
                    <circle cx="12" cy="10" r="3" />
                  </svg>
                </span>
                <span>Studio: 26.44282&deg; N, 85.90200&deg; E</span>
              </a>
            </div>

            <div className="pt-2 flex items-center justify-between">
              <button
                onClick={() => navigate('/admin')}
                className="inline-flex items-center gap-1.5 text-[11px] text-[#FFF8F0]/50 hover:text-[#C58A3D] transition-colors cursor-pointer"
              >
                <Lock className="w-3 h-3" />
                <span>Admin Console</span>
              </button>
              <span className="text-[10px] text-[#C58A3D] font-mono">NIT Trichy &middot; 2 Security Specialists</span>
            </div>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="mt-8 pt-6 border-t border-[#FFF8F0]/10 flex flex-col sm:flex-row items-center justify-between text-[11px] text-[#FFF8F0]/50 gap-3">
          <p>© {new Date().getFullYear()} Tahanabi Tech Agency. All rights reserved.</p>
          <div className="flex items-center gap-4">
            <span className="text-[#C58A3D]">International Digital & AI Agency</span>
          </div>
        </div>
      </div>
    </footer>
  );
};
