import React, { useState } from 'react';
import { useNavigation } from '../context/NavigationContext';
import { BrandLogo } from './BrandLogo';
import { Globe, ArrowRight, Menu, X, ChevronDown, Check } from 'lucide-react';
import { AppRoute } from '../types';

interface NavItem {
  label: string;
  route: AppRoute;
}

const NAV_ITEMS: NavItem[] = [
  { label: 'Home', route: '/' },
  { label: 'Work', route: '/work' },
  { label: 'Services', route: '/services' },
  { label: 'About', route: '/about' },
  { label: 'Contact', route: '/contact' },
];

export const Header: React.FC = () => {
  const { currentPath, navigate } = useNavigation();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [globalServiceOpen, setGlobalServiceOpen] = useState(false);

  const handleNavClick = (route: AppRoute) => {
    navigate(route);
    setMobileMenuOpen(false);
    setGlobalServiceOpen(false);
  };

  return (
    <header className="sticky top-0 z-50 w-full bg-[#FFF8F0]/95 backdrop-blur-md border-b border-[#EAD8C7]/60 transition-colors">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-18">
          {/* Left: Brand Logo & Star */}
          <button
            onClick={() => handleNavClick('/')}
            className="flex items-center focus:outline-none transition-transform active:scale-98"
            aria-label="Tahanabi Tech Agency Home"
          >
            <BrandLogo isLightMode={true} />
          </button>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center gap-7 lg:gap-8">
            {NAV_ITEMS.map((item) => {
              const isActive = currentPath === item.route;
              return (
                <button
                  key={item.route}
                  onClick={() => handleNavClick(item.route)}
                  className={`relative text-sm font-medium transition-colors py-1 cursor-pointer whitespace-nowrap ${
                    isActive
                      ? 'text-[#29180F] font-semibold'
                      : 'text-[#29180F]/70 hover:text-[#29180F]'
                  }`}
                >
                  {item.label}
                  {isActive && (
                    <span className="absolute bottom-0 left-0 right-0 h-0.5 bg-[#C58A3D] rounded-full" />
                  )}
                </button>
              );
            })}
          </nav>

          {/* Right: Global Service & Contact Us button */}
          <div className="hidden sm:flex items-center gap-3">
            {/* Global Service button with dropdown */}
            <div className="relative">
              <button
                onClick={() => setGlobalServiceOpen(!globalServiceOpen)}
                className="inline-flex items-center gap-1.5 px-3 py-2 rounded-lg text-xs font-medium text-[#29180F]/80 hover:text-[#29180F] hover:bg-[#F4E7DA]/70 border border-[#EAD8C7] transition-all cursor-pointer whitespace-nowrap"
                aria-expanded={globalServiceOpen}
              >
                <Globe className="w-3.5 h-3.5 text-[#C58A3D]" />
                <span>Global Service</span>
                <ChevronDown
                  className={`w-3 h-3 text-[#29180F]/50 transition-transform ${
                    globalServiceOpen ? 'rotate-180' : ''
                  }`}
                />
              </button>

              {globalServiceOpen && (
                <div className="absolute right-0 mt-2 w-64 bg-[#FFFDF9] border border-[#EAD8C7] rounded-xl shadow-lg p-3 z-50 animate-in fade-in zoom-in-95 duration-150">
                  <div className="text-[11px] font-semibold tracking-wider uppercase text-[#C58A3D] mb-2 px-1">
                    Worldwide Client Coverage
                  </div>
                  <div className="space-y-1.5 text-xs text-[#29180F]">
                    <div className="flex items-center justify-between p-1.5 rounded-lg bg-[#F4E7DA]/40">
                      <div className="flex items-center gap-2">
                        <Check className="w-3 h-3 text-[#C58A3D]" />
                        <span className="font-medium">Middle East & GCC</span>
                      </div>
                      <span className="text-[10px] text-[#29180F]/60">GMT+4</span>
                    </div>
                    <div className="flex items-center justify-between p-1.5 rounded-lg bg-[#F4E7DA]/40">
                      <div className="flex items-center gap-2">
                        <Check className="w-3 h-3 text-[#C58A3D]" />
                        <span className="font-medium">UK & Europe</span>
                      </div>
                      <span className="text-[10px] text-[#29180F]/60">GMT+0/+1</span>
                    </div>
                    <div className="flex items-center justify-between p-1.5 rounded-lg bg-[#F4E7DA]/40">
                      <div className="flex items-center gap-2">
                        <Check className="w-3 h-3 text-[#C58A3D]" />
                        <span className="font-medium">North America & Asia</span>
                      </div>
                      <span className="text-[10px] text-[#29180F]/60">24/7 Ops</span>
                    </div>
                  </div>
                  <div className="mt-2 pt-2 border-t border-[#EAD8C7]/60">
                    <button
                      onClick={() => handleNavClick('/contact')}
                      className="w-full text-center text-[11px] font-medium text-[#C58A3D] hover:underline"
                    >
                      Book International Consultation &rarr;
                    </button>
                  </div>
                </div>
              )}
            </div>

            {/* Contact Us primary button */}
            <button
              onClick={() => handleNavClick('/contact')}
              className="inline-flex items-center gap-2 px-4 py-2.5 rounded-lg bg-[#29180F] text-[#FFF8F0] hover:bg-[#1F120B] transition-all text-xs font-medium shadow-sm hover:shadow active:scale-98 cursor-pointer whitespace-nowrap group"
            >
              <span>Contact Us</span>
              <ArrowRight className="w-3.5 h-3.5 text-[#C58A3D] group-hover:translate-x-0.5 transition-transform" />
            </button>
          </div>

          {/* Mobile Hamburger button */}
          <div className="flex items-center gap-2 md:hidden">
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2 rounded-lg text-[#29180F] hover:bg-[#F4E7DA] transition-colors focus:outline-none"
              aria-label="Toggle navigation menu"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Drawer */}
      {mobileMenuOpen && (
        <div className="md:hidden border-t border-[#EAD8C7] bg-[#FFF8F0] px-4 pt-3 pb-6 space-y-3 shadow-xl">
          <div className="flex flex-col space-y-1">
            {NAV_ITEMS.map((item) => {
              const isActive = currentPath === item.route;
              return (
                <button
                  key={item.route}
                  onClick={() => handleNavClick(item.route)}
                  className={`flex items-center justify-between px-3 py-2.5 rounded-lg text-sm font-medium transition-colors text-left ${
                    isActive
                      ? 'bg-[#F4E7DA] text-[#29180F] font-semibold'
                      : 'text-[#29180F]/80 hover:bg-[#F4E7DA]/50'
                  }`}
                >
                  <span>{item.label}</span>
                  {isActive && <span className="w-1.5 h-1.5 rounded-full bg-[#C58A3D]" />}
                </button>
              );
            })}
          </div>

          <div className="pt-3 border-t border-[#EAD8C7] flex flex-col gap-2">
            <button
              onClick={() => handleNavClick('/contact')}
              className="flex items-center justify-center gap-2 w-full py-3 rounded-lg bg-[#29180F] text-[#FFF8F0] text-sm font-medium"
            >
              <span>Contact Us</span>
              <ArrowRight className="w-4 h-4 text-[#C58A3D]" />
            </button>
          </div>
        </div>
      )}
    </header>
  );
};
