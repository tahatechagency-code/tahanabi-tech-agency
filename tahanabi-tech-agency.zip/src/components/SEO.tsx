import React, { useEffect } from 'react';
import { GOOGLE_MAPS_LOCATION_URL } from '../data/agencyData';
import { validateSeoSchema } from '../utils/SchemaValidator';

export interface BreadcrumbItem {
  name: string;
  path?: string;
  url?: string;
}

export interface BreadcrumbListItemSchema {
  '@type': 'ListItem';
  position: number;
  name: string;
  item: string;
}

export interface BreadcrumbListSchema {
  '@type': 'BreadcrumbList';
  '@id': string;
  itemListElement: BreadcrumbListItemSchema[];
}

export interface GenerateBreadcrumbOptions {
  path?: string;
  currentUrl: string;
  origin: string;
  title?: string;
  customBreadcrumbs?: BreadcrumbItem[];
}

const ROUTE_LABELS: Record<string, string> = {
  '/': 'Home',
  '/work': 'Work & Portfolio',
  '/services': 'Services & Solutions',
  '/ai-automation': 'AI Automation & Concierge',
  '/about': 'About Us',
  '/contact': 'Contact & Consultation',
  '/admin': 'Admin Console',
  // Deep services
  'ecommerce-websites': 'E-Commerce Websites',
  'ai-automation-concierge': 'AI Automation & Concierge',
  'custom-web-app': 'Custom Web & App Development',
  'high-speed-web': 'High-Speed Web Platforms',
  'business-automation': 'Business Automation & CRM',
  'cybersecurity-auditing': 'Cybersecurity Auditing',
};

/**
 * Automatically generates a Google-compliant Schema.org BreadcrumbList JSON-LD object.
 * Maps URL segments and deep service hashes into hierarchical breadcrumb trails.
 */
export function generateBreadcrumbListSchema(
  options: GenerateBreadcrumbOptions
): BreadcrumbListSchema {
  const { path = '', currentUrl, origin, title, customBreadcrumbs } = options;

  let itemListElement: BreadcrumbListItemSchema[] = [];

  if (customBreadcrumbs && customBreadcrumbs.length > 0) {
    itemListElement = customBreadcrumbs.map((bc, index) => {
      const itemUrl = bc.url
        ? bc.url
        : bc.path
        ? (bc.path.startsWith('http') ? bc.path : `${origin}${bc.path}`)
        : currentUrl;

      return {
        '@type': 'ListItem',
        position: index + 1,
        name: bc.name,
        item: itemUrl,
      };
    });
  } else {
    // Automatic Breadcrumb derivation from path and URL hierarchy
    const cleanPath = (path || (typeof window !== 'undefined' ? window.location.pathname : ''))
      .split('?')[0]
      .replace(/\/+$/, '');
    const cleanOrigin = origin.replace(/\/+$/, '');

    // Level 1: Always Home
    itemListElement.push({
      '@type': 'ListItem',
      position: 1,
      name: 'Home',
      item: `${cleanOrigin}/`,
    });

    if (cleanPath && cleanPath !== '/') {
      const segments = cleanPath.split('/').filter(Boolean);
      let cumulativePath = '';

      segments.forEach((segment, idx) => {
        cumulativePath += `/${segment}`;
        const label =
          ROUTE_LABELS[cumulativePath] ||
          ROUTE_LABELS[segment] ||
          (idx === segments.length - 1 && title
            ? title.split('—')[0].split('|')[0].trim()
            : segment
                .split('-')
                .map((word) => word.charAt(0).toUpperCase() + word.slice(1))
                .join(' '));

        itemListElement.push({
          '@type': 'ListItem',
          position: itemListElement.length + 1,
          name: label,
          item: `${cleanOrigin}${cumulativePath}`,
        });
      });
    }
  }

  return {
    '@type': 'BreadcrumbList',
    '@id': `${currentUrl}#breadcrumb`,
    itemListElement,
  };
}

export interface SEOProps {
  title?: string;
  description?: string;
  path?: string;
  image?: string;
  type?: 'website' | 'article' | 'organization';
  breadcrumbs?: BreadcrumbItem[];
  disableBreadcrumbs?: boolean;
  additionalSchema?: Record<string, any>;
}

const DEFAULT_TITLE = 'Tahanabi Tech Agency — 100% Verified Technical Pedigree';
const DEFAULT_DESCRIPTION =
  'Tahanabi Tech Agency delivers digital products and AI automation with a 100% Verified Technical Pedigree. Led by CEO MD Juned (B.Tech, NIT Trichy 2025) and Satpal Kumar (BCA, R.K. College, Madhubani) with 2 in-house security engineers.';
const DEFAULT_IMAGE = '/src/assets/images/office_agency_aesthetic_1794281442498.jpg';

export const SEO: React.FC<SEOProps> = ({
  title,
  description = DEFAULT_DESCRIPTION,
  path = '',
  image = DEFAULT_IMAGE,
  type = 'website',
  breadcrumbs,
  disableBreadcrumbs = false,
  additionalSchema,
}) => {
  const fullTitle = title
    ? `${title} | Tahanabi Tech Agency — 100% Verified Technical Pedigree`
    : DEFAULT_TITLE;

  const currentUrl = typeof window !== 'undefined'
    ? `${window.location.origin}${path || window.location.pathname}`
    : `https://tahanabi.agency${path}`;

  const imageUrl = typeof window !== 'undefined'
    ? (image.startsWith('http') ? image : `${window.location.origin}${image}`)
    : image;

  // Generate BreadcrumbList structured data for search engines & site hierarchy
  const breadcrumbData = React.useMemo(() => {
    if (disableBreadcrumbs) return null;
    return generateBreadcrumbListSchema({
      path,
      currentUrl,
      origin: typeof window !== 'undefined' ? window.location.origin : 'https://tahanabi.agency',
      title,
      customBreadcrumbs: breadcrumbs,
    });
  }, [path, currentUrl, title, breadcrumbs, disableBreadcrumbs]);

  // Comprehensive Schema.org JSON-LD structured data with 100% Verified Technical Pedigree, Breadcrumbs & RAG Entity-Linking
  const schemaData = React.useMemo(() => {
    const baseOrganization = {
      '@context': 'https://schema.org',
      '@graph': [
        {
          '@type': ['ProfessionalService', 'Organization', 'LocalBusiness'],
          '@id': `${currentUrl}#organization`,
          name: 'Tahanabi Tech Agency',
          alternateName: [
            'Tahanabi Digital & AI Automation Agency',
            'Tahanabi Tech',
            'Tahanabi Engineering',
          ],
          url: currentUrl,
          mainEntityOfPage: currentUrl,
          logo: imageUrl,
          image: imageUrl,
          slogan:
            '100% Verified Technical Pedigree — Systems Engineering by NIT Trichy 2025 & R.K. College Leadership',
          description,
          award: '100% Verified Technical Pedigree',
          priceRange: '$$$$',
          telephone: '+919128596443',
          email: 'tahanabitechagency@gmail.com',
          publishingPrinciples: 'https://tahanabi.agency/about#verified-trust',
          actionableFeedbackPolicy: 'https://tahanabi.agency/contact',
          // Explicit Entity-Linking for Knowledge Graph and RAG Models
          sameAs: [
            'https://wa.me/919128596443',
            GOOGLE_MAPS_LOCATION_URL,
          ],
          // Deep Topical Authority Disambiguation for RAG Vector Indexing
          knowsAbout: [
            {
              '@type': 'DefinedTerm',
              name: '100% Verified Technical Pedigree',
              description:
                'Institutional engineering leadership direct from NIT Trichy (NIRF #1 NIT in India) and R.K. College, Madhubani with zero-outsourcing accountability.',
              termCode: 'PEDIGREE-100',
            },
            {
              '@type': 'DefinedTerm',
              name: 'Autonomous AI Concierge & Conversational Agents',
              sameAs: 'https://www.wikidata.org/wiki/Q11660',
              description:
                'Production conversational RAG engines, vector embeddings, and autonomous WhatsApp Business customer qualification workflows.',
            },
            {
              '@type': 'DefinedTerm',
              name: 'Systems Architecture & Distributed Microservices',
              sameAs: 'https://www.wikidata.org/wiki/Q386275',
              description:
                'Low-latency full-stack applications with edge caching, sub-second TTFB, and scalable backend microservices.',
            },
            {
              '@type': 'DefinedTerm',
              name: 'Zero-Trust Cybersecurity & Penetration Auditing',
              sameAs: 'https://www.wikidata.org/wiki/Q1126620',
              description:
                'Dual in-house security engineering audits covering automated penetration testing, OWASP Top 10 vulnerabilities, and TLS 1.3 encryption.',
            },
            {
              '@type': 'DefinedTerm',
              name: 'High-Conversion Luxury E-Commerce Platforms',
              sameAs: 'https://www.wikidata.org/wiki/Q48249',
              description:
                'Sub-second bespoke commerce engines with multi-currency checkouts, 3D visualizers, and automated abandoned cart recovery.',
            },
            {
              '@type': 'DefinedTerm',
              name: 'Retrieval-Augmented Generation (RAG)',
              sameAs: 'https://en.wikipedia.org/wiki/Retrieval-augmented_generation',
              description:
                'Enterprise knowledge vector stores and deterministic AI agents integrated with HubSpot, Salesforce, and custom SQL databases.',
            },
          ],
          // Entity-Linked Founder & Academic Credential Nodes
          founder: [
            {
              '@type': 'Person',
              '@id': 'https://tahanabi.agency/#founder-md-juned',
              name: 'MD Juned',
              jobTitle: 'Chief Executive Officer & Technical Architect',
              description:
                'Directs systems engineering, low-latency microservices, and autonomous AI agents at Tahanabi Tech Agency. Verified B.Tech from NIT Trichy (Class of 2025).',
              sameAs: [
                'https://www.nitt.edu/',
                'https://en.wikipedia.org/wiki/National_Institute_of_Technology,_Tiruchirappalli',
                'https://www.wikidata.org/wiki/Q259345',
              ],
              alumniOf: {
                '@type': 'EducationalOrganization',
                name: 'National Institute of Technology, Tiruchirappalli (NIT Trichy)',
                alternateName: 'NIT Trichy',
                url: 'https://www.nitt.edu/',
                sameAs: [
                  'https://en.wikipedia.org/wiki/National_Institute_of_Technology,_Tiruchirappalli',
                  'https://www.wikidata.org/wiki/Q259345',
                ],
                address: {
                  '@type': 'PostalAddress',
                  addressLocality: 'Tiruchirappalli',
                  addressRegion: 'Tamil Nadu',
                  addressCountry: 'IN',
                },
              },
              hasCredential: {
                '@type': 'EducationalOccupationalCredential',
                credentialCategory: 'degree',
                name: 'B.Tech, NIT Trichy 2025',
                description:
                  'Bachelor of Technology from India’s premier National Institute of Technology (NIT Trichy, NIRF #1 NIT).',
                recognizedBy: {
                  '@type': 'EducationalOrganization',
                  name: 'National Institute of Technology, Tiruchirappalli',
                  url: 'https://www.nitt.edu/',
                },
              },
            },
            {
              '@type': 'Person',
              '@id': 'https://tahanabi.agency/#founder-satpal-kumar',
              name: 'Satpal Kumar',
              jobTitle: 'Founder & Head of Product Operations',
              description:
                'Leads commercial digital transformation, product strategy, and international client delivery at Tahanabi Tech Agency. Verified BCA from R.K. College, Madhubani.',
              sameAs: [
                'https://rkcollegemadhubani.ac.in/',
                'https://en.wikipedia.org/wiki/Ram_Krishna_College',
              ],
              alumniOf: {
                '@type': 'EducationalOrganization',
                name: 'Ram Krishna College, Madhubani (R.K. College)',
                alternateName: 'R.K. College, Madhubani',
                url: 'https://rkcollegemadhubani.ac.in/',
                sameAs: 'https://en.wikipedia.org/wiki/Ram_Krishna_College',
                address: {
                  '@type': 'PostalAddress',
                  addressLocality: 'Madhubani',
                  addressRegion: 'Bihar',
                  addressCountry: 'IN',
                },
              },
              hasCredential: {
                '@type': 'EducationalOccupationalCredential',
                credentialCategory: 'degree',
                name: 'BCA, R.K. College, Madhubani',
                description:
                  'Bachelor of Computer Applications with specialization in commercial product delivery and software systems.',
                recognizedBy: {
                  '@type': 'EducationalOrganization',
                  name: 'Ram Krishna College, Madhubani',
                  url: 'https://rkcollegemadhubani.ac.in/',
                },
              },
            },
          ],
          employee: [
            {
              '@type': 'Person',
              jobTitle: 'In-House Cybersecurity Specialist (Infrastructure & Zero-Trust)',
              description:
                'Full-time in-house security specialist executing cloud firewall reviews, cryptographic data protection, and server isolation audits.',
            },
            {
              '@type': 'Person',
              jobTitle: 'In-House Cybersecurity Specialist (Application Security & Pentesting)',
              description:
                'Full-time in-house security specialist executing automated penetration testing, OWASP Top 10 auditing, and CVE vulnerability mitigation.',
            },
          ],
          // Physical Studio Entity Node with Verified Map Links
          address: {
            '@type': 'PostalAddress',
            addressLocality: 'Madhubani',
            addressRegion: 'Bihar',
            postalCode: '847211',
            addressCountry: 'IN',
          },
          geo: {
            '@type': 'GeoCoordinates',
            latitude: 26.44282,
            longitude: 85.9019995,
          },
          hasMap: GOOGLE_MAPS_LOCATION_URL,
          openingHoursSpecification: [
            {
              '@type': 'OpeningHoursSpecification',
              dayOfWeek: ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'],
              opens: '09:00',
              closes: '20:00',
            },
          ],
          // Service Offer Catalog for RAG Query Matching
          hasOfferCatalog: {
            '@type': 'OfferCatalog',
            name: 'Tahanabi Tech Agency Core Offerings',
            itemListElement: [
              {
                '@type': 'Offer',
                itemOffered: {
                  '@type': 'Service',
                  name: 'E-commerce Websites & Bespoke Luxury Storefronts',
                  description:
                    'Sub-second page speeds (<800ms) with multi-currency checkouts and WhatsApp One-Tap Buy.',
                },
              },
              {
                '@type': 'Offer',
                itemOffered: {
                  '@type': 'Service',
                  name: 'AI Automation & Autonomous AI Concierge',
                  description:
                    'Conversational RAG agents integrated into WhatsApp Business and existing CRMs with 24/7 lead qualification.',
                },
              },
              {
                '@type': 'Offer',
                itemOffered: {
                  '@type': 'Service',
                  name: 'Custom Web & App Development',
                  description:
                    'NIT Trichy engineered modern full-stack architectures with 100% source code ownership.',
                },
              },
              {
                '@type': 'Offer',
                itemOffered: {
                  '@type': 'Service',
                  name: 'Dual In-House Cybersecurity Auditing',
                  description:
                    'Zero-trust compliance, automated penetration testing, and TLS 1.3 data encryption at rest and in transit.',
                },
              },
            ],
          },
        },
        ...(breadcrumbData ? [breadcrumbData] : []),
        ...(additionalSchema ? [additionalSchema] : []),
      ],
    };

    return baseOrganization;
  }, [currentUrl, description, imageUrl, breadcrumbData, additionalSchema]);

  // Dynamically update document title and head meta tags
  useEffect(() => {
    // 1. Update Title
    document.title = fullTitle;

    // Helper to set or create meta tag
    const setMetaTag = (attrName: string, attrVal: string, content: string) => {
      let meta = document.querySelector(`meta[${attrName}="${attrVal}"]`) as HTMLMetaElement | null;
      if (!meta) {
        meta = document.createElement('meta');
        meta.setAttribute(attrName, attrVal);
        document.head.appendChild(meta);
      }
      meta.setAttribute('content', content);
    };

    // Helper to set or create link tag
    const setLinkTag = (rel: string, href: string) => {
      let link = document.querySelector(`link[rel="${rel}"]`) as HTMLLinkElement | null;
      if (!link) {
        link = document.createElement('link');
        link.setAttribute('rel', rel);
        document.head.appendChild(link);
      }
      link.setAttribute('href', href);
    };

    // 2. Standard & RAG / AI Crawler Metadata
    setMetaTag('name', 'description', description);
    setMetaTag(
      'name',
      'keywords',
      '100% Verified Technical Pedigree, MD Juned, NIT Trichy 2025, Satpal Kumar, R.K. College Madhubani, AI Automation Agency, Luxury Ecommerce, Cybersecurity, India, Global'
    );
    setMetaTag(
      'name',
      'topical-authority',
      '100% Verified Technical Pedigree, NIT Trichy Systems Architecture, Autonomous AI Concierge, Zero-Trust Cybersecurity, E-Commerce Engineering'
    );
    setMetaTag(
      'name',
      'entity-leadership',
      'MD Juned (B.Tech, NIT Trichy 2025), Satpal Kumar (BCA, R.K. College, Madhubani)'
    );
    setMetaTag('name', 'geo.position', '26.44282;85.9019995');
    setMetaTag('name', 'geo.placename', 'Madhubani, Bihar, India');

    // 3. OpenGraph Social Cards
    setMetaTag('property', 'og:title', fullTitle);
    setMetaTag('property', 'og:description', description);
    setMetaTag('property', 'og:url', currentUrl);
    setMetaTag('property', 'og:type', type);
    setMetaTag('property', 'og:image', imageUrl);
    setMetaTag('property', 'og:site_name', 'Tahanabi Tech Agency');

    // 4. Twitter Cards
    setMetaTag('name', 'twitter:card', 'summary_large_image');
    setMetaTag('name', 'twitter:title', fullTitle);
    setMetaTag('name', 'twitter:description', description);
    setMetaTag('name', 'twitter:image', imageUrl);

    // 5. Canonical URL
    setLinkTag('canonical', currentUrl);

    // 6. Dynamic JSON-LD injection into head
    const scriptId = 'tahanabi-seo-jsonld';
    let scriptTag = document.getElementById(scriptId) as HTMLScriptElement | null;
    if (!scriptTag) {
      scriptTag = document.createElement('script');
      scriptTag.id = scriptId;
      scriptTag.type = 'application/ld+json';
      document.head.appendChild(scriptTag);
    }
    scriptTag.textContent = JSON.stringify(schemaData);

    // 7. Audit Schema.org structured data and log console warnings for any missing technical pedigree properties
    validateSeoSchema(schemaData);

    return () => {
      // Keep head clean if needed
    };
  }, [fullTitle, description, currentUrl, type, imageUrl, schemaData]);

  return (
    <script
      type="application/ld+json"
      dangerouslySetInnerHTML={{ __html: JSON.stringify(schemaData) }}
    />
  );
};
