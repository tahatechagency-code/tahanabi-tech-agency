import React from 'react';
import { useNavigation } from '../context/NavigationContext';
import { ServiceItem } from '../types';
import {
  ShoppingBag,
  Sparkles,
  Code2,
  Workflow,
  Layers,
  LifeBuoy,
  ArrowRight,
  Check,
  Clock,
  ShieldCheck,
  LucideIcon,
} from 'lucide-react';

interface ServiceCardProps {
  service: ServiceItem;
  isCompact?: boolean;
}

const ICON_MAP: Record<string, LucideIcon> = {
  ShoppingBag,
  Sparkles,
  Code2,
  Workflow,
  Layers,
  LifeBuoy,
};

export const ServiceCard: React.FC<ServiceCardProps> = ({ service, isCompact = false }) => {
  const { navigate } = useNavigation();
  const IconComponent = ICON_MAP[service.iconName] || Sparkles;

  const handleClick = () => {
    if (service.isAiConcierge) {
      navigate('/ai-automation');
    } else {
      navigate(`/contact?service=${service.slug}`);
    }
  };

  return (
    <div
      onClick={handleClick}
      className="group relative bg-[#FFFDF9] rounded-2xl p-6 sm:p-7 border border-[#EAD8C7] hover:border-[#C58A3D] transition-all duration-300 hover:shadow-xl hover:shadow-[#C58A3D]/12 cursor-pointer flex flex-col justify-between"
    >
      <div>
        {/* Top Header: Golden Icon + Premium Badge */}
        <div className="flex items-start justify-between gap-3 mb-5">
          <div className="w-13 h-13 rounded-2xl bg-gradient-to-br from-[#FBF4EA] via-[#F4E7DA] to-[#EAD8C7] border border-[#EAD8C7] flex items-center justify-center text-[#C58A3D] group-hover:bg-[#C58A3D] group-hover:text-white transition-all shadow-xs shrink-0">
            <IconComponent className="w-6 h-6 transition-colors" />
          </div>

          {service.badge && (
            <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#F4E7DA] text-[#29180F] text-[11px] font-semibold tracking-wide border border-[#EAD8C7]/80">
              <span className="w-1.5 h-1.5 rounded-full bg-[#C58A3D]" />
              <span>{service.badge}</span>
            </span>
          )}
        </div>

        {/* Title */}
        <h3 className="font-serif text-xl font-semibold text-[#29180F] group-hover:text-[#C58A3D] transition-colors leading-snug">
          {service.title}
        </h3>

        {/* Description */}
        <p className="mt-2 text-xs sm:text-sm text-[#29180F]/75 leading-relaxed">
          {service.description}
        </p>

        {/* Deliverables / Key Specifications (shown when full or premium) */}
        {service.deliverables && service.deliverables.length > 0 && (
          <div className="mt-5 pt-4 border-t border-[#EAD8C7]/60 space-y-2">
            <div className="text-[11px] font-semibold uppercase tracking-wider text-[#C58A3D]">
              Included Deliverables
            </div>
            <ul className="space-y-1.5 text-xs text-[#29180F]/85">
              {service.deliverables.map((item, idx) => (
                <li key={idx} className="flex items-start gap-2">
                  <Check className="w-3.5 h-3.5 text-[#C58A3D] shrink-0 mt-0.5" />
                  <span className="leading-tight">{item}</span>
                </li>
              ))}
            </ul>
          </div>
        )}

        {/* Tech Stack and SLA metadata */}
        <div className="mt-5 pt-3 border-t border-[#EAD8C7]/40 flex flex-wrap items-center justify-between gap-2 text-[11px] text-[#29180F]/70">
          {service.timeline && (
            <span className="inline-flex items-center gap-1 font-medium text-[#29180F]">
              <Clock className="w-3.5 h-3.5 text-[#C58A3D]" />
              <span>{service.timeline}</span>
            </span>
          )}
          <span className="inline-flex items-center gap-1 text-[10px] text-[#29180F]/60">
            <ShieldCheck className="w-3 h-3 text-[#25D366]" />
            <span>Dual Security Audited</span>
          </span>
        </div>
      </div>

      {/* Action Footer Button */}
      <div className="mt-6 pt-4 border-t border-[#EAD8C7]/60 flex items-center justify-between text-xs font-semibold text-[#29180F] group-hover:text-[#C58A3D] transition-colors">
        <span>{service.isAiConcierge ? 'Deploy AI Automation' : 'Inquire For Service'}</span>
        <div className="p-1.5 rounded-lg bg-[#F4E7DA] group-hover:bg-[#C58A3D] group-hover:text-white transition-colors">
          <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-0.5 transition-transform" />
        </div>
      </div>
    </div>
  );
};
