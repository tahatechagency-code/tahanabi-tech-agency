import React from 'react';
import { useNavigation } from '../context/NavigationContext';
import { IndustryWork } from '../types';
import { ArrowUpRight } from 'lucide-react';

interface WorkCardProps {
  work: IndustryWork;
}

export const WorkCard: React.FC<WorkCardProps> = ({ work }) => {
  const { navigate } = useNavigation();

  const handleClick = () => {
    navigate(`/contact?interest=${work.slug}`);
  };

  return (
    <div
      onClick={handleClick}
      className="group relative bg-[#FFFDF9] rounded-2xl border border-[#EAD8C7] overflow-hidden hover:border-[#C58A3D]/70 transition-all duration-300 hover:shadow-lg hover:shadow-[#C58A3D]/10 cursor-pointer flex flex-col"
    >
      {/* Visual media */}
      <div className="relative aspect-[4/3] w-full overflow-hidden bg-[#F4E7DA]">
        <img
          src={work.image}
          alt={work.title}
          referrerPolicy="no-referrer"
          className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-[#29180F]/50 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
        
        {/* Category tag */}
        <div className="absolute top-3 left-3 bg-[#FFFDF9]/90 backdrop-blur-sm px-2.5 py-1 rounded-md text-[11px] font-semibold text-[#29180F] border border-[#EAD8C7]">
          {work.tag}
        </div>
      </div>

      {/* Content */}
      <div className="p-4 sm:p-5 flex flex-col flex-1 justify-between gap-3">
        <div>
          <div className="flex items-start justify-between gap-2">
            <h3 className="font-serif text-base sm:text-lg font-semibold text-[#29180F] group-hover:text-[#C58A3D] transition-colors leading-snug">
              {work.title}
            </h3>
            <span className="p-1.5 rounded-full bg-[#F4E7DA] text-[#29180F] group-hover:bg-[#C58A3D] group-hover:text-white transition-colors shrink-0">
              <ArrowUpRight className="w-3.5 h-3.5" />
            </span>
          </div>
          <p className="mt-1.5 text-xs text-[#29180F]/70 leading-relaxed line-clamp-2">
            {work.subtitle}
          </p>
        </div>

        <div className="pt-2 border-t border-[#EAD8C7]/50 flex items-center justify-between text-[11px] font-medium text-[#C58A3D]">
          <span>Inquire for this industry</span>
          <span className="group-hover:translate-x-1 transition-transform">&rarr;</span>
        </div>
      </div>
    </div>
  );
};
