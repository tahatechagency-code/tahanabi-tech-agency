import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import { ContactInquiry } from '../types';
import { INITIAL_INQUIRIES } from '../data/agencyData';

interface InquiryContextType {
  inquiries: ContactInquiry[];
  isLoading: boolean;
  error: string | null;
  fetchInquiries: () => Promise<void>;
  markAsVerified: (id: string) => Promise<void>;
  markAsReplied: (id: string) => Promise<void>;
  updateStatus: (id: string, status: ContactInquiry['status']) => Promise<void>;
  deleteInquiry: (id: string) => Promise<void>;
  addInquiry: (newInq: Omit<ContactInquiry, 'id' | 'timestamp'>) => Promise<boolean>;
  metrics: {
    total: number;
    verified: number;
    replied: number;
    pending: number;
  };
}

const InquiryContext = createContext<InquiryContextType | undefined>(undefined);

export const InquiryProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [inquiries, setInquiries] = useState<ContactInquiry[]>(() => {
    try {
      const stored = localStorage.getItem('tahanabi_inquiries_cache');
      return stored ? JSON.parse(stored) : INITIAL_INQUIRIES;
    } catch {
      return INITIAL_INQUIRIES;
    }
  });
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const getAuthHeader = (): Record<string, string> => {
    const token = sessionStorage.getItem('tahanabi_admin_token');
    return token ? { Authorization: `Bearer ${token}` } : {};
  };

  const fetchInquiries = useCallback(async () => {
    setIsLoading(true);
    setError(null);
    try {
      const res = await fetch('/api/inquiries', {
        headers: {
          ...getAuthHeader(),
        },
      });
      if (res.ok) {
        const json = await res.json();
        if (json.success && Array.isArray(json.data)) {
          setInquiries(json.data);
          localStorage.setItem('tahanabi_inquiries_cache', JSON.stringify(json.data));
          return;
        }
      }
      throw new Error('Failed to parse inquiries');
    } catch (err: any) {
      console.warn('API sync warning (using cached data):', err.message);
      // Fallback to local storage or initial data
    } finally {
      setIsLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchInquiries();
  }, [fetchInquiries]);

  const updateStatus = useCallback(async (id: string, status: ContactInquiry['status']) => {
    const timestamp = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    const patchPayload: Partial<ContactInquiry> = { status };
    if (status === 'verified') {
      patchPayload.verifiedAt = timestamp;
    } else if (status === 'replied') {
      patchPayload.repliedAt = timestamp;
    }

    // Optimistic UI update
    setInquiries((prev) => {
      const updated = prev.map((inq) => (inq.id === id ? { ...inq, ...patchPayload } : inq));
      localStorage.setItem('tahanabi_inquiries_cache', JSON.stringify(updated));
      return updated;
    });

    try {
      await fetch(`/api/inquiries/${id}`, {
        method: 'PATCH',
        headers: {
          'Content-Type': 'application/json',
          ...getAuthHeader(),
        },
        body: JSON.stringify(patchPayload),
      });
    } catch (err) {
      console.warn('Backend patch failed, kept local state', err);
    }
  }, []);

  const markAsVerified = useCallback(
    async (id: string) => {
      await updateStatus(id, 'verified');
    },
    [updateStatus]
  );

  const markAsReplied = useCallback(
    async (id: string) => {
      await updateStatus(id, 'replied');
    },
    [updateStatus]
  );

  const deleteInquiry = useCallback(async (id: string) => {
    setInquiries((prev) => {
      const updated = prev.filter((inq) => inq.id !== id);
      localStorage.setItem('tahanabi_inquiries_cache', JSON.stringify(updated));
      return updated;
    });

    try {
      await fetch(`/api/inquiries/${id}`, {
        method: 'DELETE',
        headers: {
          ...getAuthHeader(),
        },
      });
    } catch (err) {
      console.warn('Backend delete failed, kept local state', err);
    }
  }, []);

  const addInquiry = useCallback(
    async (newInq: Omit<ContactInquiry, 'id' | 'timestamp'>) => {
      try {
        const res = await fetch('/api/inquiries', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(newInq),
        });
        if (res.ok) {
          const json = await res.json();
          if (json.success && json.data) {
            setInquiries((prev) => {
              const updated = [json.data, ...prev];
              localStorage.setItem('tahanabi_inquiries_cache', JSON.stringify(updated));
              return updated;
            });
            return true;
          }
        }
      } catch (err) {
        console.warn('Backend inquiry submission fallback', err);
      }

      // Local fallback
      const localInq: ContactInquiry = {
        ...newInq,
        id: `inq-${Date.now()}`,
        timestamp: 'Just now',
        status: 'new',
      };
      setInquiries((prev) => {
        const updated = [localInq, ...prev];
        localStorage.setItem('tahanabi_inquiries_cache', JSON.stringify(updated));
        return updated;
      });
      return true;
    },
    []
  );

  const metrics = {
    total: inquiries.length,
    verified: inquiries.filter((i) => i.status === 'verified').length,
    replied: inquiries.filter((i) => i.status === 'replied').length,
    pending: inquiries.filter((i) => i.status === 'new' || i.status === 'in_progress').length,
  };

  return (
    <InquiryContext.Provider
      value={{
        inquiries,
        isLoading,
        error,
        fetchInquiries,
        markAsVerified,
        markAsReplied,
        updateStatus,
        deleteInquiry,
        addInquiry,
        metrics,
      }}
    >
      {children}
    </InquiryContext.Provider>
  );
};

export const useInquiries = () => {
  const context = useContext(InquiryContext);
  if (!context) {
    throw new Error('useInquiries must be used within an InquiryProvider');
  }
  return context;
};
