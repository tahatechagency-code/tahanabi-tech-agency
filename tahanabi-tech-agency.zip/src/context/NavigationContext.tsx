import React, { createContext, useContext, useState, useEffect } from 'react';
import { AppRoute } from '../types';

interface NavigationContextType {
  currentPath: AppRoute;
  searchParams: Record<string, string>;
  navigate: (url: string) => void;
}

const NavigationContext = createContext<NavigationContextType | undefined>(undefined);

const VALID_ROUTES: AppRoute[] = [
  '/',
  '/work',
  '/services',
  '/ai-automation',
  '/about',
  '/contact',
  '/admin',
];

function parseUrl(rawUrl: string): { path: AppRoute; params: Record<string, string> } {
  try {
    const parsed = new URL(rawUrl, window.location.origin);
    const pathname = parsed.pathname as AppRoute;
    const path: AppRoute = VALID_ROUTES.includes(pathname) ? pathname : '/';

    const params: Record<string, string> = {};
    parsed.searchParams.forEach((val, key) => {
      params[key] = val;
    });

    return { path, params };
  } catch {
    return { path: '/', params: {} };
  }
}

export const NavigationProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [currentPath, setCurrentPath] = useState<AppRoute>('/');
  const [searchParams, setSearchParams] = useState<Record<string, string>>({});

  useEffect(() => {
    // Initial sync
    const initial = parseUrl(window.location.pathname + window.location.search);
    setCurrentPath(initial.path);
    setSearchParams(initial.params);

    const handlePopState = () => {
      const updated = parseUrl(window.location.pathname + window.location.search);
      setCurrentPath(updated.path);
      setSearchParams(updated.params);
      window.scrollTo({ top: 0, behavior: 'smooth' });
    };

    window.addEventListener('popstate', handlePopState);
    return () => window.removeEventListener('popstate', handlePopState);
  }, []);

  const navigate = (url: string) => {
    const { path, params } = parseUrl(url);
    setCurrentPath(path);
    setSearchParams(params);

    if (window.location.pathname + window.location.search !== url) {
      window.history.pushState({}, '', url);
    }
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <NavigationContext.Provider value={{ currentPath, searchParams, navigate }}>
      {children}
    </NavigationContext.Provider>
  );
};

export const useNavigation = (): NavigationContextType => {
  const context = useContext(NavigationContext);
  if (!context) {
    throw new Error('useNavigation must be used within a NavigationProvider');
  }
  return context;
};
