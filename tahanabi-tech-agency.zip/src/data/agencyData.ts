import { IndustryWork, ServiceItem, AgencyConfig, ContactInquiry, TeamMember } from '../types';

export const GOOGLE_MAPS_LOCATION_URL =
  'https://www.google.com/maps/@26.44282,85.9019995,15z?entry=ttu&g_ep=EgoyMDI2MTEwNC4wIKXMDSoASAFQAw%3D%3D';

export const INITIAL_AGENCY_CONFIG: AgencyConfig = {
  phone: '+91 91285 96443',
  email: 'tahanabitechagency@gmail.com',
  whatsappNumber: '919128596443',
  headline: 'Digital Products & AI Automation for Global Businesses',
  tagline: 'We build premium websites, e-commerce solutions and AI automation systems for businesses worldwide.',
  aboutText: 'A global digital and AI automation agency helping businesses grow with technology, design and intelligent automation.',
  mapsUrl: GOOGLE_MAPS_LOCATION_URL,
};

export const LEADERSHIP_TEAM: TeamMember[] = [
  {
    name: 'MD Juned',
    role: 'Chief Executive Officer & Technical Architect',
    qualification: 'B.Tech, NIT Trichy 2025',
    institution: 'NIT Trichy (National Institute of Technology, Tiruchirappalli)',
    bio: 'Oversees engineering architecture, large-scale systems design, and AI automation. Bringing top-tier technical rigor from NIT Trichy—ranked among India’s premier institutes of national importance.',
    image: '/src/assets/images/ceo_md_juned_1794282408935.jpg',
    specialization: 'Distributed Systems & Enterprise AI Engineering',
  },
  {
    name: 'Satpal Kumar',
    role: 'Founder & Head of Product Operations',
    qualification: 'BCA, R.K. College, Madhubani',
    institution: 'R.K. College, Madhubani',
    bio: 'Drives strategic product execution, international client relationships, and business digital transformation. Focused on turning complex business workflows into seamless, high-converting digital assets.',
    image: '/src/assets/images/founder_satpal_kumar_1794282409914.jpg',
    specialization: 'Product Strategy & Commercial Delivery',
  },
];

export const SECURITY_SPECIALISTS = {
  count: 2,
  title: 'Dedicated In-House Cybersecurity & Infrastructure Specialists',
  image: '/src/assets/images/security_engineering_hub_1794282409587.jpg',
  description:
    'Every line of code and cloud deployment at Tahanabi Tech Agency is reviewed and stress-tested by our two dedicated in-house security engineers before hitting production.',
  checks: [
    'Zero-Trust Architecture & OWASP Top 10 Security Hardening',
    'End-to-End 256-bit AES & TLS 1.3 Data Encryption at Rest & Transit',
    'Automated Penetration Testing & API Vulnerability Audits',
    'Full GDPR, HIPAA, & SOC2 Compliance Readiness for Global Clients',
  ],
};


export const INDUSTRY_WORKS: IndustryWork[] = [
  {
    id: '1',
    slug: 'jewellery-ecommerce',
    title: 'Jewellery E-commerce',
    subtitle: 'High-end luxury storefronts with 3D product previews, WhatsApp concierge, and automated VIP ordering.',
    tag: 'E-commerce',
    image: '/src/assets/images/industry_jewellery_1794281441984.jpg',
  },
  {
    id: '2',
    slug: 'car-service',
    title: 'Car Service & Fleet',
    subtitle: 'Digital booking engines, fleet management dashboards, live driver dispatching, and WhatsApp tracking.',
    tag: 'Automotive',
    image: '/src/assets/images/industry_car_fleet_1794281443328.jpg',
  },
  {
    id: '3',
    slug: 'retail-fashion',
    title: 'Retail & Fashion',
    subtitle: 'Curated apparel collections, omnichannel inventory sync, lookbook purchasing, and rapid checkout.',
    tag: 'Fashion & Retail',
    image: '/src/assets/images/industry_retail_fashion_1794281443639.jpg',
  },
  {
    id: '4',
    slug: 'real-estate',
    title: 'Real Estate & Property',
    subtitle: 'Architectural portfolio portals, interactive floor plans, automated buyer lead capture, and CRM syncing.',
    tag: 'Real Estate',
    image: '/src/assets/images/industry_real_estate_1794281465970.jpg',
  },
  {
    id: '5',
    slug: 'healthcare',
    title: 'Healthcare & Wellness',
    subtitle: 'HIPAA-conscious appointment scheduling, doctor concierge bots, patient records, and intake workflows.',
    tag: 'Healthcare',
    image: '/src/assets/images/industry_healthcare_1794281466136.jpg',
  },
  {
    id: '6',
    slug: 'other',
    title: 'More Industries',
    subtitle: 'Bespoke web platforms, custom ERP connectors, multi-tenant SaaS, and automation pipelines for all sectors.',
    tag: 'Custom Solutions',
    image: '/src/assets/images/office_agency_aesthetic_1794281442498.jpg',
  },
];

export const SERVICES_LIST: ServiceItem[] = [
  {
    id: 's1',
    slug: 'ecommerce-websites',
    title: 'E-commerce Websites',
    description: 'Bespoke high-converting luxury storefronts with 3D catalog previews, instant WhatsApp checkout, and payment gateways.',
    iconName: 'ShoppingBag',
    isAiConcierge: false,
    badge: '100x Conversion Focus',
    timeline: '2–3 Weeks Delivery',
    deliverables: [
      'Sub-second page speeds (<800ms) with Next.js edge caching',
      'Seamless multi-currency Stripe, PayPal & Razorpay checkouts',
      'WhatsApp One-Tap Buy & Automated Abandoned Cart recovery',
      'Inventory sync across Shopify, WooCommerce & custom ERP',
    ],
    techStack: ['Next.js', 'Tailwind CSS', 'Stripe', 'Node.js', 'PostgreSQL'],
  },
  {
    id: 's2',
    slug: 'ai-automation-concierge',
    title: 'AI Automation & AI Concierge',
    description: 'Autonomous conversational agents that engage web visitors, capture leads, book calendars, and answer FAQs 24/7.',
    iconName: 'Sparkles',
    isAiConcierge: true,
    badge: 'Flagship Autonomous AI',
    timeline: 'Instant Deploy + 7-Day Customization',
    deliverables: [
      'Omnichannel deployment: Web Widget + WhatsApp Business + Instagram',
      'Trained on your private business documents & catalog data',
      'Autonomous qualification, CRM lead push & calendar booking',
      'Multilingual fluency in English, Arabic, Hindi & 40+ languages',
    ],
    techStack: ['Gemini 2.5/3', 'WhatsApp Cloud API', 'FastAPI', 'Vector DB', 'Webhooks'],
  },
  {
    id: 's3',
    slug: 'custom-web-app',
    title: 'Custom Web & App Development',
    description: 'Tailored enterprise software and client portals engineered with NIT Trichy-grade architectural rigor and zero lag.',
    iconName: 'Code2',
    isAiConcierge: false,
    badge: 'Enterprise Architecture',
    timeline: '3–5 Weeks Delivery',
    deliverables: [
      'Role-based access control (RBAC) with secure multi-tenant data',
      'Real-time reactive user interfaces with reactive websockets',
      'Fully documented REST and GraphQL endpoints with Swagger/OpenAPI',
      'Scalable cloud infrastructure on Google Cloud or AWS with auto-scaling',
    ],
    techStack: ['React 19', 'TypeScript', 'Node.js', 'Cloud Run', 'Docker'],
  },
  {
    id: 's4',
    slug: 'crm-business-automation',
    title: 'CRM & Business Automation',
    description: 'Eliminate manual repetitive paperwork with autonomous sales routing, automated invoicing, and customer sync.',
    iconName: 'Workflow',
    isAiConcierge: false,
    badge: 'Operational Efficiency',
    timeline: '1–2 Weeks Delivery',
    deliverables: [
      'Automated pipeline triggers from inbound inquiries to sales reps',
      'Automated PDF invoice generation and payment reminder notifications',
      'Two-way sync between Google Sheets, HubSpot, Salesforce & Airtable',
      'Executive analytics dashboards with real-time KPI telemetry',
    ],
    techStack: ['Zapier / Make', 'REST Webhooks', 'PostgreSQL', 'Google Workspace API'],
  },
  {
    id: 's5',
    slug: 'integration-workflow',
    title: 'Integration & Workflow',
    description: 'Bridge disparate cloud systems with bulletproof custom middleware, zero data loss, and bidirectional webhooks.',
    iconName: 'Layers',
    isAiConcierge: false,
    badge: 'Zero-Downtime Middleware',
    timeline: '1–2 Weeks Delivery',
    deliverables: [
      'Custom webhook listener engines with automatic retry queues',
      'Legacy database migrations with zero downtime guarantees',
      'Secure token encryption and OAuth2 enterprise proxy gateways',
      'Comprehensive error reporting and Slack/WhatsApp incident alerts',
    ],
    techStack: ['Express', 'Redis Queue', 'Docker', 'JWT / OAuth2', 'Cloud PubSub'],
  },
  {
    id: 's6',
    slug: 'support-maintenance',
    title: 'Support & Maintenance',
    description: 'Continuous proactive maintenance and SLA-backed monitoring by our dedicated in-house cybersecurity engineers.',
    iconName: 'LifeBuoy',
    isAiConcierge: false,
    badge: 'Security Specialist Audited',
    timeline: 'Ongoing SLA Retainer',
    deliverables: [
      '24/7 server uptime monitoring with 15-minute emergency response SLA',
      'Weekly automated vulnerability scanning & dependency updates',
      'Continuous daily cloud database backups with 1-click restoration',
      'Dedicated engineering sprint hours for feature upgrades every month',
    ],
    techStack: ['Uptime Kuma', 'CloudWatch', 'Sentry', 'GitHub CI/CD', 'Automated Penetration'],
  },
];

export const HOME_SERVICES_STRIP = [
  {
    title: 'E-commerce Solutions',
    desc: 'High-performance stores & payments',
    iconName: 'ShoppingBag',
  },
  {
    title: 'AI Automation & Conversational AI',
    desc: '24/7 intelligent customer concierge',
    iconName: 'Sparkles',
  },
  {
    title: 'Custom Web & App Development',
    desc: 'Tailored engineering & performance',
    iconName: 'Code2',
  },
  {
    title: 'CRM & Business Automation',
    desc: 'Streamlined operational pipelines',
    iconName: 'Workflow',
  },
  {
    title: 'Global Delivery & Support',
    desc: 'Worldwide deployment & care',
    iconName: 'Globe2',
  },
];

export const AI_SOLUTIONS = [
  {
    number: '01',
    title: 'AI Concierge (Website + WhatsApp)',
    description: 'Engage visitors immediately, qualify leads, answer product queries, and hand off warm prospects to your sales team.',
    iconName: 'Bot',
  },
  {
    number: '02',
    title: 'Booking & Scheduling Automation',
    description: 'Frictionless calendar booking linked to Google/Outlook, preventing double-bookings and sending automated reminders.',
    iconName: 'CalendarCheck',
  },
  {
    number: '03',
    title: 'Lead Capture & CRM Integration',
    description: 'Instantly push contact details, user intent, and transcripts into HubSpot, Salesforce, Notion, or custom databases.',
    iconName: 'UserCheck',
  },
  {
    number: '04',
    title: 'Auto Email / WhatsApp / SMS',
    description: 'Trigger immediate multilingual confirmations, follow-up drip sequences, and order notifications with 99.9% delivery.',
    iconName: 'MessageSquareShare',
  },
  {
    number: '05',
    title: 'Multi-Language Support (English + Arabic + More)',
    description: 'Native conversational fluency across languages tailored to international clients in the Gulf, Europe, and Asia.',
    iconName: 'Languages',
  },
];

export const INITIAL_INQUIRIES: ContactInquiry[] = [
  {
    id: 'inq-101',
    name: 'Sheikh Al-Maktoum Trading',
    email: 'contact@almaktoumtrading.ae',
    phone: '+971 50 123 4567',
    interest: 'Jewellery E-commerce',
    message: 'We are launching a private diamond boutique online with WhatsApp VIP checkout.',
    timestamp: '2 hours ago',
    status: 'new',
  },
  {
    id: 'inq-102',
    name: 'Marcus Vance Fleet Group',
    email: 'm.vance@vancefleet.co.uk',
    phone: '+44 20 7946 0912',
    interest: 'Car Service & Fleet',
    message: 'Require an automated dispatching engine and mobile portal for 85 executive vehicles in London.',
    timestamp: '5 hours ago',
    status: 'in_progress',
  },
  {
    id: 'inq-103',
    name: 'Atelier Aurelia Paris',
    email: 'info@aureliaparis.fr',
    phone: '+33 1 42 68 55 00',
    interest: 'Retail & Fashion',
    message: 'Inquiring for seasonal e-commerce re-platforming and AI concierge implementation.',
    timestamp: 'Yesterday',
    status: 'completed',
  },
];

export const SERVICES_FAQS = [
  {
    id: 's-faq-1',
    question: 'How long does a typical project take from kick-off to production deployment?',
    answer: 'Most bespoke web and e-commerce platforms are delivered within 2 to 4 weeks. Specialized AI concierge setups and CRM automations can be deployed within 7 to 10 days. We operate in rapid milestone-based sprints with daily transparent progress updates.',
    tag: 'Timeline',
    nestedQuestions: [
      {
        id: 's-sub-1a',
        question: 'Can you expedite a rush project for a critical launch date?',
        answer: 'Yes. We offer fast-track sprint schedules with dedicated engineer allocation for critical deadlines under 10 days, while retaining full security verification.',
        badge: 'Expedited Delivery',
      },
      {
        id: 's-sub-1b',
        question: 'How frequently do we receive progress demonstrations?',
        answer: 'We provide scheduled weekly sprint video reviews and host a private live staging URL updated continuously with every git commit.',
        badge: 'Live Staging',
      },
    ],
  },
  {
    id: 's-faq-2',
    question: 'Do we retain 100% intellectual property and full source code ownership?',
    answer: 'Yes, completely. Upon final milestone delivery, you receive full ownership of all source code repositories (GitHub/GitLab), database schemas, Figma design tokens, and cloud infrastructure rights. There are zero licensing lock-ins or proprietary traps.',
    tag: 'Ownership',
    nestedQuestions: [
      {
        id: 's-sub-2a',
        question: 'Do you provide full commit history and setup documentation?',
        answer: 'Yes. Your repository includes clean git commit logs, Docker configurations, README deployment guides, and complete API specifications.',
        badge: 'Clean Repo',
      },
      {
        id: 's-sub-2b',
        question: 'Are there any recurring licensing fees for using Tahanabi code?',
        answer: 'Zero licensing fees. Everything created belongs entirely to your business from day one with full commercial exploitation rights.',
        badge: 'Zero Royalty',
      },
    ],
  },
  {
    id: 's-faq-3',
    question: 'How does your in-house security division protect our web application and user data?',
    answer: 'Tahanabi Tech Agency employs two dedicated in-house cybersecurity specialists. Every line of code undergoes automated OWASP Top 10 scans, end-to-end 256-bit encryption checks, SQL injection prevention, and penetration testing before deployment.',
    tag: 'Security',
    nestedQuestions: [
      {
        id: 's-sub-3a',
        question: 'What specific penetration tests are performed?',
        answer: 'Our two dedicated security engineers execute SQL injection, cross-site scripting (XSS), CSRF simulation, DDoS stress testing, and third-party dependency CVE audits.',
        badge: 'Pen Testing',
      },
      {
        id: 's-sub-3b',
        question: 'Do you assist with international data compliance (GDPR, HIPAA, SOC 2)?',
        answer: 'Yes. We build data isolation layers, cookie consent mechanics, encrypted database at-rest storage, and immutable audit logs aligned with international regulatory frameworks.',
        badge: 'Compliance',
      },
    ],
  },
  {
    id: 's-faq-4',
    question: 'Can your AI concierge and WhatsApp automation integrate into our existing CRM?',
    answer: 'Yes. Our conversational AI engines connect seamlessly with HubSpot, Salesforce, Notion, Shopify, Zoho, Google Sheets, or custom SQL databases via secure webhooks and RESTful APIs, operating 24/7 without human latency.',
    tag: 'Integration',
    nestedQuestions: [
      {
        id: 's-sub-4a',
        question: 'Can the AI bot answer complex customer questions about our inventory?',
        answer: 'Yes. We vector-embed your complete product catalog, return policies, and pricing tiers so the AI answers accurately in English, Arabic, or other regional languages.',
        badge: 'RAG Knowledge',
      },
      {
        id: 's-sub-4b',
        question: 'What happens when a human customer representative needs to intervene?',
        answer: 'The AI detects sentiment shifts or high-value purchase requests and instantly triggers a warm handover to your team on WhatsApp with full conversation history.',
        badge: 'Human Handover',
      },
    ],
  },
  {
    id: 's-faq-5',
    question: 'What does post-launch support and SLA warranty include?',
    answer: 'Every build includes a 30-day post-launch warranty covering bug fixes, server performance monitoring, and minor tweaks. We also offer ongoing monthly maintenance agreements with sub-2-hour emergency response SLAs.',
    tag: 'Support & SLA',
    nestedQuestions: [
      {
        id: 's-sub-5a',
        question: 'How fast do you respond to urgent critical issues?',
        answer: 'Our SLA guarantees sub-2-hour response times and 24/7 emergency server recovery monitoring with automated uptime heartbeat pings.',
        badge: '<2h SLA',
      },
      {
        id: 's-sub-5b',
        question: 'Are routine dependency and security patches included?',
        answer: 'Yes. During your support window, our team reviews and updates all runtime dependencies and applies zero-day security patches weekly.',
        badge: 'Weekly Patches',
      },
    ],
  },
  {
    id: 's-faq-6',
    question: 'How does the milestone-based payment structure work?',
    answer: 'We use a transparent milestone escrow model: an initial kickoff deposit, milestone stage releases (wireframes/design approval, beta staging review), and final balance upon production sign-off. We accept international bank transfers, Stripe, PayPal, and wire.',
    tag: 'Billing',
    nestedQuestions: [
      {
        id: 's-sub-6a',
        question: 'What happens if a milestone requires adjustments?',
        answer: 'Milestones are not approved until you are 100% satisfied with the demo according to the agreed project scope. Revisions within scope are executed promptly.',
        badge: 'Milestone Escrow',
      },
    ],
  },
];

export const ABOUT_FAQS = [
  {
    id: 'a-faq-1',
    question: "What is Tahanabi Tech Agency's 100% Verified Technical Pedigree?",
    answer: "Our agency is architected by founders with institutional academic integrity: CEO MD Juned holds a B.Tech from NIT Trichy (Class of 2025, consistently ranked as India's premier National Institute of Technology), and Founder Satpal Kumar holds a BCA from R.K. College, Madhubani. We combine elite systems engineering with commercial execution.",
    tag: 'Pedigree',
    nestedQuestions: [
      {
        id: 'a-sub-1a',
        question: "How does MD Juned's NIT Trichy 2025 background directly benefit our project?",
        answer: "NIT Trichy is ranked India's #1 National Institute of Technology. MD Juned brings top-tier algorithms, distributed systems architecture, and mathematical systems engineering to prevent scaling bottlenecks.",
        badge: 'NIT Trichy Core',
      },
      {
        id: 'a-sub-1b',
        question: "What is Satpal Kumar's focus as Founder from R.K. College, Madhubani?",
        answer: "Satpal Kumar combines computer applications (BCA) with deep business strategy, overseeing high-converting sales funnels, rapid sprint velocity, and international delivery.",
        badge: 'Product Strategy',
      },
    ],
  },
  {
    id: 'a-faq-2',
    question: 'Where is your official registered office located, and can we verify it?',
    answer: 'Our verified physical studio is located at latitude 26.44282° N, longitude 85.90200° E in Madhubani. We openly publish our direct Google Maps pin link (https://www.google.com/maps/@26.44282,85.9019995,15z) and welcome clients for scheduled in-person consultations or virtual video briefings.',
    tag: 'Location',
    nestedQuestions: [
      {
        id: 'a-sub-2a',
        question: 'What are your exact geographic coordinates?',
        answer: 'Registered studio coordinates are Latitude: 26.44282° N, Longitude: 85.90200° E in Madhubani, verified with high-resolution 15z pin data on Google Maps.',
        badge: 'Geo Verified',
      },
      {
        id: 'a-sub-2b',
        question: 'Can international clients schedule an in-person or virtual video briefing?',
        answer: 'Yes. We host both physical studio meetings and high-bandwidth Google Meet / Zoom discovery sessions across US, European, and Gulf time zones.',
        badge: 'Open Hub',
      },
    ],
  },
  {
    id: 'a-faq-3',
    question: 'Do you outsource engineering work to third-party freelancers?',
    answer: 'Never. We enforce a strict Zero-Outsourcing Policy. All software architecture, UI/UX designs, autonomous AI agents, and security audits are performed by our founders and dedicated in-house engineering team.',
    tag: 'Accountability',
    nestedQuestions: [
      {
        id: 'a-sub-3a',
        question: 'Why do you maintain a strict Zero-Outsourcing Policy?',
        answer: 'Outsourcing creates hidden bugs, leaking credentials, and broken deadlines. By keeping all engineering strictly in-house, we guarantee 100% code quality and direct founder accountability.',
        badge: 'Zero Outsourcing',
      },
      {
        id: 'a-sub-3b',
        question: 'Who reviews each pull request before it enters production?',
        answer: 'All PRs are reviewed by MD Juned and audited by our two in-house security specialist engineers.',
        badge: 'Dual Review',
      },
    ],
  },
  {
    id: 'a-faq-4',
    question: 'How do you handle engagements with international clients across time zones?',
    answer: 'We service clients across 14+ countries including the US, UK, UAE, France, and Singapore. We structure overlapping communication windows, provide bi-lingual English contracts, operate in USD/EUR/AED, and assign dedicated WhatsApp and Slack channels for instant collaboration.',
    tag: 'Global Clients',
    nestedQuestions: [
      {
        id: 'a-sub-4a',
        question: 'What currencies and contract jurisdictions do you support?',
        answer: 'We invoice in USD, EUR, GBP, AED, and INR. Agreements include international NDAs and clear milestone escrow terms.',
        badge: 'Global Contracts',
      },
      {
        id: 'a-sub-4b',
        question: 'What communication tools are used during an active project?',
        answer: 'We set up a private dedicated WhatsApp Group, Slack channel, and real-time Figma / Staging links for seamless daily collaboration.',
        badge: 'Daily Comms',
      },
    ],
  },
  {
    id: 'a-faq-5',
    question: 'How do two dedicated cybersecurity specialists fit into the leadership team?',
    answer: 'Security is built into our agency’s foundational DNA rather than treated as an afterthought. Our two dedicated in-house engineers continuously audit cloud firewalls, verify SSL/TLS handshakes, and conduct penetration testing before any client application is made live to the public.',
    tag: 'Cybersecurity',
    nestedQuestions: [
      {
        id: 'a-sub-5a',
        question: 'Are they external contractors or full-time in-house team members?',
        answer: 'They are full-time in-house security engineers dedicated exclusively to Tahanabi Tech Agency client projects.',
        badge: 'In-House Team',
      },
    ],
  },
];


