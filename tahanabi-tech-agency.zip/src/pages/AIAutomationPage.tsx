import React from 'react';
import { useNavigation } from '../context/NavigationContext';
import {
  Bot,
  CalendarCheck,
  UserCheck,
  MessageSquareShare,
  Languages,
  ArrowRight,
  Sparkles,
  CheckCircle2,
} from 'lucide-react';
import { AI_SOLUTIONS } from '../data/agencyData';

const SOLUTION_ICONS = [Bot, CalendarCheck, UserCheck, MessageSquareShare, Languages];

export const AIAutomationPage: React.FC = () => {
  const { navigate } = useNavigation();

  const handleInquire = () => {
    navigate('/contact?interest=ai-automation');
  };

  return (
    <div className="w-full py-12 sm:py-16 bg-[#FFF8F0] min-h-[75vh]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center max-w-2xl mx-auto mb-12 space-y-2">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#F4E7DA] text-[#29180F] text-xs font-semibold border border-[#EAD8C7]">
            <Sparkles className="w-3.5 h-3.5 text-[#C58A3D]" />
            <span>Autonomous Intelligence</span>
          </div>
          <h1 className="font-serif text-3xl sm:text-4xl font-semibold text-[#29180F]">
            AI Automation
          </h1>
          <p className="text-sm text-[#29180F]/70">
            Intelligent automation solutions to manage customers, bookings and business operations.
          </p>
        </div>

        {/* Two-Column Layout */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 sm:gap-12 items-center">
          {/* Left Column: AI Assistant Robot Illustration & Laptop Mockup on Soft Beige */}
          <div className="lg:col-span-5 flex flex-col items-center">
            <div className="w-full relative bg-[#F4E7DA] rounded-3xl p-6 sm:p-8 border border-[#EAD8C7] shadow-xl overflow-hidden flex flex-col items-center text-center">
              {/* Soft decorative background orb */}
              <div className="absolute top-0 right-0 w-64 h-64 bg-radial from-[#C58A3D]/15 to-transparent rounded-full blur-2xl pointer-events-none" />

              {/* Robot Assistant Artwork */}
              <div className="relative w-full max-w-sm aspect-[4/3] rounded-2xl overflow-hidden border border-[#EAD8C7] bg-[#FFFDF9] shadow-md mb-6">
                <img
                  src="/src/assets/images/ai_concierge_robot_1794281443822.jpg"
                  alt="Tahanabi AI Concierge and Automation System"
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover"
                />
                <div className="absolute top-3 left-3 bg-[#29180F]/90 backdrop-blur-sm text-[#FFF8F0] text-[10px] font-semibold px-2.5 py-1 rounded-full flex items-center gap-1.5 border border-[#C58A3D]/40">
                  <span className="w-1.5 h-1.5 rounded-full bg-[#25D366] animate-pulse" />
                  <span>24/7 AI Concierge Online</span>
                </div>
              </div>

              {/* Laptop and Workflow Highlights */}
              <div className="w-full bg-[#FFFDF9] rounded-xl p-4 border border-[#EAD8C7] shadow-xs text-left">
                <div className="flex items-center justify-between pb-2 mb-2 border-b border-[#EAD8C7]/50">
                  <span className="text-xs font-semibold text-[#29180F]">Tahanabi Autonomous Pipeline</span>
                  <span className="text-[10px] font-medium text-[#C58A3D]">Multi-Platform</span>
                </div>
                <div className="space-y-1.5 text-xs text-[#29180F]/80">
                  <div className="flex items-center gap-2">
                    <CheckCircle2 className="w-3.5 h-3.5 text-[#C58A3D] shrink-0" />
                    <span>Website Live Concierge Widget</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <CheckCircle2 className="w-3.5 h-3.5 text-[#C58A3D] shrink-0" />
                    <span>WhatsApp Business Automated Flows</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <CheckCircle2 className="w-3.5 h-3.5 text-[#C58A3D] shrink-0" />
                    <span>Instant CRM &amp; Calendar Booking</span>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Right Column: Exactly Five Solution Items */}
          <div className="lg:col-span-7 space-y-4">
            {AI_SOLUTIONS.map((solution, idx) => {
              const IconComp = SOLUTION_ICONS[idx] || Sparkles;
              return (
                <div
                  key={solution.title}
                  className="group bg-[#FFFDF9] rounded-2xl p-4 sm:p-5 border border-[#EAD8C7] hover:border-[#C58A3D] transition-all duration-300 hover:shadow-md flex items-start gap-4"
                >
                  {/* Number Badge and Icon */}
                  <div className="flex flex-col items-center shrink-0">
                    <div className="w-10 h-10 rounded-xl bg-[#F4E7DA] text-[#C58A3D] flex items-center justify-center group-hover:bg-[#C58A3D] group-hover:text-white transition-colors">
                      <IconComp className="w-5 h-5" />
                    </div>
                    <span className="text-[10px] font-mono text-[#29180F]/40 mt-1 font-semibold">
                      {solution.number}
                    </span>
                  </div>

                  {/* Text details */}
                  <div className="flex-1">
                    <h3 className="font-serif text-base font-semibold text-[#29180F] group-hover:text-[#C58A3D] transition-colors leading-snug">
                      {solution.title}
                    </h3>
                    <p className="mt-1 text-xs sm:text-sm text-[#29180F]/70 leading-relaxed">
                      {solution.description}
                    </p>
                  </div>
                </div>
              );
            })}

            {/* Compact Contact Us Button */}
            <div className="pt-4 flex flex-col sm:flex-row items-center justify-between gap-4 bg-[#F4E7DA]/50 p-4 rounded-2xl border border-[#EAD8C7]">
              <div>
                <h4 className="font-serif text-sm font-semibold text-[#29180F]">
                  Ready to deploy AI in your business?
                </h4>
                <p className="text-xs text-[#29180F]/70">
                  Connect with our team to configure your custom agent.
                </p>
              </div>

              <button
                onClick={handleInquire}
                className="inline-flex items-center gap-2 px-6 py-2.5 rounded-xl bg-[#29180F] text-[#FFF8F0] hover:bg-[#1F120B] transition-all text-xs font-semibold shadow-sm hover:shadow active:scale-98 shrink-0 cursor-pointer"
              >
                <span>Contact Us for AI Automation</span>
                <ArrowRight className="w-3.5 h-3.5 text-[#C58A3D]" />
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
