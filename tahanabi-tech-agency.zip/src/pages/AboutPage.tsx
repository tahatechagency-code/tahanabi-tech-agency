import React from 'react';
import { useNavigation } from '../context/NavigationContext';
import {
  Globe,
  Cpu,
  TrendingUp,
  Clock,
  ArrowRight,
  ShieldCheck,
  GraduationCap,
  MapPin,
  ExternalLink,
  Lock,
  CheckCircle2,
  FileCheck,
  HeartHandshake,
} from 'lucide-react';
import {
  LEADERSHIP_TEAM,
  SECURITY_SPECIALISTS,
  GOOGLE_MAPS_LOCATION_URL,
  ABOUT_FAQS,
} from '../data/agencyData';
import { ClientFeedbackSection } from '../components/ClientFeedbackSection';
import { AccordionFAQ } from '../components/AccordionFAQ';

export const AboutPage: React.FC = () => {
  const { navigate } = useNavigation();

  return (
    <div className="w-full py-12 sm:py-16 bg-[#FFF8F0] min-h-[75vh]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Top Split: Left Content, Right Office Image */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-14 items-center mb-16">
          {/* Left Column */}
          <div className="lg:col-span-6 space-y-5 text-left">
            <div className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-[#F4E7DA] text-[#29180F] text-xs font-bold border border-[#EAD8C7] shadow-xs">
              <ShieldCheck className="w-4 h-4 text-[#25D366]" />
              <span>100% Verified Technical Pedigree</span>
            </div>

            <h1 className="font-serif text-3xl sm:text-4xl lg:text-5xl font-semibold text-[#29180F] leading-[1.2]">
              About Tahanabi Tech Agency
            </h1>

            <p className="text-base sm:text-lg text-[#29180F]/85 leading-relaxed font-serif italic text-balance">
              &ldquo;A global digital and AI automation agency helping businesses grow with technology,
              design and intelligent automation.&rdquo;
            </p>

            <p className="text-sm text-[#29180F]/75 leading-relaxed">
              Tahanabi Tech Agency is built on a <strong>100% Verified Technical Pedigree</strong>. Our leadership combines top-tier systems engineering from <strong>MD Juned (B.Tech, NIT Trichy 2025)</strong> and commercial digital transformation from <strong>Satpal Kumar (BCA, R.K. College, Madhubani)</strong>, supported by two dedicated in-house cybersecurity engineers and a verified physical operations studio.
            </p>

            {/* Quick Academic Trust Highlights */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2 text-xs text-[#29180F]">
              <div className="flex items-center gap-2.5 p-2.5 rounded-xl bg-[#FFFDF9] border border-[#EAD8C7] shadow-2xs">
                <GraduationCap className="w-4 h-4 text-[#C58A3D] shrink-0" />
                <div>
                  <div className="font-bold text-[#29180F]">MD Juned &middot; CEO</div>
                  <div className="text-[11px] text-[#29180F]/70">B.Tech, NIT Trichy 2025</div>
                </div>
              </div>
              <div className="flex items-center gap-2.5 p-2.5 rounded-xl bg-[#FFFDF9] border border-[#EAD8C7] shadow-2xs">
                <GraduationCap className="w-4 h-4 text-[#C58A3D] shrink-0" />
                <div>
                  <div className="font-bold text-[#29180F]">Satpal Kumar &middot; Founder</div>
                  <div className="text-[11px] text-[#29180F]/70">BCA, R.K. College, Madhubani</div>
                </div>
              </div>
            </div>

            <div className="pt-2 flex items-center gap-4">
              <button
                onClick={() => navigate('/contact')}
                className="inline-flex items-center gap-2 px-6 py-3 rounded-xl bg-[#29180F] text-[#FFF8F0] hover:bg-[#1F120B] transition-all text-xs font-semibold shadow-sm hover:shadow cursor-pointer"
              >
                <span>Work With Us</span>
                <ArrowRight className="w-3.5 h-3.5 text-[#C58A3D]" />
              </button>
              <button
                onClick={() => navigate('/work')}
                className="inline-flex items-center gap-2 px-5 py-3 rounded-xl border border-[#EAD8C7] hover:bg-[#F4E7DA] text-[#29180F] transition-all text-xs font-semibold cursor-pointer"
              >
                <span>Explore Portfolio</span>
              </button>
            </div>
          </div>

          {/* Right Column: Premium Agency Office Image */}
          <div className="lg:col-span-6">
            <div className="relative rounded-3xl overflow-hidden border border-[#EAD8C7] shadow-xl bg-[#FFFDF9]">
              <img
                src="/src/assets/images/office_agency_aesthetic_1794281442498.jpg"
                alt="Tahanabi Tech Agency Global Office"
                referrerPolicy="no-referrer"
                className="w-full h-80 sm:h-96 object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#29180F]/70 via-transparent to-transparent" />
              <div className="absolute bottom-5 left-5 right-5 text-white">
                <span className="font-serif font-semibold text-lg block">Institutional Engineering Quality</span>
                <span className="text-white/80 text-xs">
                  Delivering audited technology &amp; AI excellence across 14+ international jurisdictions.
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* SECTION: LEADERSHIP PROFILES (CEO & FOUNDER) */}
        <div className="mb-16">
          <div className="text-center max-w-3xl mx-auto mb-10 space-y-2">
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#F4E7DA] text-[#29180F] text-xs font-bold border border-[#EAD8C7] mb-1">
              <ShieldCheck className="w-3.5 h-3.5 text-[#25D366]" />
              <span>100% Verified Technical Pedigree</span>
            </div>
            <h2 className="font-serif text-2xl sm:text-3xl font-semibold text-[#29180F]">
              Led by MD Juned (NIT Trichy 2025) &amp; Satpal Kumar (R.K. College)
            </h2>
            <p className="text-xs sm:text-sm text-[#29180F]/70">
              Direct founder accountability, elite institutional technical education, and hands-on execution on every engagement.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-4xl mx-auto">
            {/* CEO: MD Juned */}
            <div className="bg-[#FFFDF9] rounded-3xl p-6 sm:p-7 border border-[#EAD8C7] shadow-md hover:border-[#C58A3D] transition-all duration-300 flex flex-col justify-between">
              <div>
                <div className="flex flex-col sm:flex-row sm:items-center gap-5 mb-5">
                  <div className="w-24 h-24 sm:w-28 sm:h-28 rounded-2xl overflow-hidden border border-[#EAD8C7] shadow-sm shrink-0">
                    <img
                      src={LEADERSHIP_TEAM[0].image}
                      alt={LEADERSHIP_TEAM[0].name}
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <div>
                    <span className="inline-block px-2.5 py-0.5 rounded-full bg-[#C58A3D]/15 text-[#C58A3D] text-[10px] font-bold uppercase tracking-wider mb-1">
                      Chief Executive Officer
                    </span>
                    <h3 className="font-serif text-xl sm:text-2xl font-semibold text-[#29180F]">
                      {LEADERSHIP_TEAM[0].name}
                    </h3>
                    <div className="flex items-center gap-1.5 text-xs font-bold text-[#29180F] mt-1">
                      <GraduationCap className="w-4 h-4 text-[#C58A3D]" />
                      <span>B.Tech, NIT Trichy 2025</span>
                    </div>
                    <div className="text-xs text-[#29180F]/75 font-medium mt-0.5">
                      {LEADERSHIP_TEAM[0].institution}
                    </div>
                  </div>
                </div>

                <div className="space-y-2 text-xs text-[#29180F]/75 leading-relaxed pt-2 border-t border-[#EAD8C7]/60">
                  <p>
                    MD Juned directs the technical vision, core architecture, and proprietary automation engines at Tahanabi Tech Agency. Holding a <strong>B.Tech from NIT Trichy (Class of 2025)</strong>—consistently ranked as India&apos;s #1 National Institute of Technology—he brings elite mathematical and systems-level engineering rigor to every web platform and autonomous AI deployment.
                  </p>
                  <p className="font-medium text-[#29180F]">
                    Focus: Distributed cloud systems, low-latency microservices, and conversational AI concierge networks.
                  </p>
                </div>
              </div>

              <div className="mt-5 pt-4 border-t border-[#EAD8C7]/60 flex items-center justify-between text-xs">
                <span className="font-mono text-[#C58A3D] font-bold text-[11px]">100% Verified Technical Pedigree</span>
                <span className="text-[#25D366] font-semibold flex items-center gap-1">
                  <ShieldCheck className="w-3.5 h-3.5" />
                  <span>NIT Trichy 2025 Verified</span>
                </span>
              </div>
            </div>

            {/* Founder: Satpal Kumar */}
            <div className="bg-[#FFFDF9] rounded-3xl p-6 sm:p-7 border border-[#EAD8C7] shadow-md hover:border-[#C58A3D] transition-all duration-300 flex flex-col justify-between">
              <div>
                <div className="flex flex-col sm:flex-row sm:items-center gap-5 mb-5">
                  <div className="w-24 h-24 sm:w-28 sm:h-28 rounded-2xl overflow-hidden border border-[#EAD8C7] shadow-sm shrink-0">
                    <img
                      src={LEADERSHIP_TEAM[1].image}
                      alt={LEADERSHIP_TEAM[1].name}
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <div>
                    <span className="inline-block px-2.5 py-0.5 rounded-full bg-[#29180F] text-[#FFF8F0] text-[10px] font-bold uppercase tracking-wider mb-1">
                      Founder &amp; Head of Product
                    </span>
                    <h3 className="font-serif text-xl sm:text-2xl font-semibold text-[#29180F]">
                      {LEADERSHIP_TEAM[1].name}
                    </h3>
                    <div className="flex items-center gap-1.5 text-xs font-bold text-[#29180F] mt-1">
                      <GraduationCap className="w-4 h-4 text-[#C58A3D]" />
                      <span>BCA, R.K. College, Madhubani</span>
                    </div>
                    <div className="text-xs text-[#29180F]/75 font-medium mt-0.5">
                      {LEADERSHIP_TEAM[1].institution}
                    </div>
                  </div>
                </div>

                <div className="space-y-2 text-xs text-[#29180F]/75 leading-relaxed pt-2 border-t border-[#EAD8C7]/60">
                  <p>
                    Satpal Kumar leads product strategy, international client relations, and commercial delivery. Holding a <strong>BCA from R.K. College, Madhubani</strong>, he has spent years resolving enterprise bottlenecks and engineering high-converting commercial funnels and digital solutions.
                  </p>
                  <p className="font-medium text-[#29180F]">
                    Focus: Omnichannel commercial funnels, client satisfaction, and rapid international project turnaround.
                  </p>
                </div>
              </div>

              <div className="mt-5 pt-4 border-t border-[#EAD8C7]/60 flex items-center justify-between text-xs">
                <span className="font-mono text-[#C58A3D] font-bold text-[11px]">100% Verified Technical Pedigree</span>
                <span className="text-[#25D366] font-semibold flex items-center gap-1">
                  <ShieldCheck className="w-3.5 h-3.5" />
                  <span>R.K. College Verified</span>
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* SECTION: CYBERSECURITY SPECIALIST DIVISION (2 ENGINEERS) */}
        <div className="mb-16 bg-[#FFFDF9] rounded-3xl p-6 sm:p-8 lg:p-10 border border-[#EAD8C7] shadow-lg">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
            {/* Left: Security Details */}
            <div className="lg:col-span-7 space-y-4">
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#25D366]/15 text-[#25D366] text-xs font-semibold border border-[#25D366]/30">
                <Lock className="w-3.5 h-3.5" />
                <span>Two Dedicated In-House Cybersecurity Specialists</span>
              </div>

              <h2 className="font-serif text-2xl sm:text-3xl font-semibold text-[#29180F]">
                Institutional-Grade Data Security &amp; Zero-Trust
              </h2>

              <p className="text-xs sm:text-sm text-[#29180F]/75 leading-relaxed">
                Unlike agencies that outsource or neglect security, Tahanabi Tech Agency maintains <strong>two full-time, in-house security specialist engineers</strong>. Every client build undergoes exhaustive vulnerability audits, automated penetration testing, and cryptographic verification prior to public deployment.
              </p>

              {/* Security Checklist */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
                {SECURITY_SPECIALISTS.checks.map((check, idx) => (
                  <div key={idx} className="flex items-start gap-2.5 p-3 rounded-xl bg-[#FFF8F0] border border-[#EAD8C7]">
                    <CheckCircle2 className="w-4 h-4 text-[#25D366] shrink-0 mt-0.5" />
                    <span className="text-xs font-medium text-[#29180F]/85 leading-snug">
                      {check}
                    </span>
                  </div>
                ))}
              </div>
            </div>

            {/* Right: Security Lab Image */}
            <div className="lg:col-span-5">
              <div className="relative rounded-2xl overflow-hidden border border-[#EAD8C7] shadow-md bg-[#29180F]">
                <img
                  src={SECURITY_SPECIALISTS.image}
                  alt="Tahanabi Cybersecurity Command Center"
                  className="w-full h-64 sm:h-72 object-cover opacity-95"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#29180F] via-transparent to-transparent" />
                <div className="absolute bottom-4 left-4 right-4 text-white text-xs">
                  <div className="flex items-center gap-2 mb-1">
                    <span className="w-2 h-2 rounded-full bg-[#25D366] animate-pulse" />
                    <span className="font-semibold text-xs">In-House Security Operations</span>
                  </div>
                  <span className="text-white/80 text-[11px]">
                    Continuous penetration testing, encrypted database mirrors &amp; DDoS shielding.
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* DEDICATED SECTION: VERIFIED TRUST */}
        <section id="verified-trust" className="mb-16 scroll-mt-24">
          <div className="bg-gradient-to-b from-[#FFFDF9] via-[#FDF5EB] to-[#FFFDF9] rounded-3xl p-6 sm:p-10 border-2 border-[#C58A3D]/40 shadow-xl">
            {/* Header */}
            <div className="text-center max-w-3xl mx-auto mb-10 space-y-3">
              <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-[#25D366]/15 text-[#1b7e3d] text-xs font-bold border border-[#25D366]/30 shadow-2xs">
                <ShieldCheck className="w-4 h-4 text-[#25D366]" />
                <span className="tracking-wide">100% VERIFIED TECHNICAL PEDIGREE</span>
              </div>
              <h2 className="font-serif text-3xl sm:text-4xl font-semibold text-[#29180F]">
                Verified Trust &amp; Academic Credentials
              </h2>
              <p className="text-xs sm:text-sm text-[#29180F]/80 max-w-2xl mx-auto leading-relaxed">
                Tahanabi Tech Agency operates on absolute institutional transparency. We openly publish our leadership&apos;s verified academic qualifications, engineering degrees, and real physical studio location coordinates on Google Maps.
              </p>
            </div>

            {/* Academic Pedigree Cards: MD Juned & Satpal Kumar */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-10">
              {/* MD Juned Academic Credential Card */}
              <div className="bg-[#FFFDF9] rounded-2xl p-6 border border-[#EAD8C7] shadow-sm hover:border-[#C58A3D] transition-all">
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 rounded-xl bg-[#C58A3D]/15 text-[#C58A3D] flex items-center justify-center shrink-0 border border-[#C58A3D]/30">
                    <GraduationCap className="w-6 h-6" />
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center justify-between flex-wrap gap-2">
                      <span className="text-[11px] font-bold uppercase tracking-wider text-[#C58A3D]">
                        Chief Executive Officer
                      </span>
                      <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-[#25D366] bg-[#25D366]/10 px-2 py-0.5 rounded-md border border-[#25D366]/20">
                        <CheckCircle2 className="w-3 h-3" />
                        <span>100% Verified</span>
                      </span>
                    </div>
                    <h3 className="font-serif text-xl font-bold text-[#29180F] mt-1">
                      MD Juned
                    </h3>
                    <div className="mt-2 p-3 rounded-xl bg-[#FFF8F0] border border-[#EAD8C7]/80">
                      <div className="text-xs font-bold text-[#29180F] flex items-center gap-1.5">
                        <GraduationCap className="w-4 h-4 text-[#C58A3D]" />
                        <span>B.Tech, NIT Trichy 2025</span>
                      </div>
                      <div className="text-[11px] text-[#29180F]/75 mt-0.5">
                        National Institute of Technology, Tiruchirappalli (NIRF #1 NIT in India)
                      </div>
                    </div>
                    <p className="mt-3 text-xs text-[#29180F]/75 leading-relaxed">
                      Specialized in distributed computing, low-latency microservices, and autonomous LLM architectures with mathematical engineering rigor.
                    </p>
                  </div>
                </div>
              </div>

              {/* Satpal Kumar Academic Credential Card */}
              <div className="bg-[#FFFDF9] rounded-2xl p-6 border border-[#EAD8C7] shadow-sm hover:border-[#C58A3D] transition-all">
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 rounded-xl bg-[#29180F]/10 text-[#29180F] flex items-center justify-center shrink-0 border border-[#29180F]/20">
                    <GraduationCap className="w-6 h-6 text-[#C58A3D]" />
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center justify-between flex-wrap gap-2">
                      <span className="text-[11px] font-bold uppercase tracking-wider text-[#29180F]">
                        Founder &amp; Head of Product
                      </span>
                      <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-[#25D366] bg-[#25D366]/10 px-2 py-0.5 rounded-md border border-[#25D366]/20">
                        <CheckCircle2 className="w-3 h-3" />
                        <span>100% Verified</span>
                      </span>
                    </div>
                    <h3 className="font-serif text-xl font-bold text-[#29180F] mt-1">
                      Satpal Kumar
                    </h3>
                    <div className="mt-2 p-3 rounded-xl bg-[#FFF8F0] border border-[#EAD8C7]/80">
                      <div className="text-xs font-bold text-[#29180F] flex items-center gap-1.5">
                        <GraduationCap className="w-4 h-4 text-[#C58A3D]" />
                        <span>BCA, R.K. College, Madhubani</span>
                      </div>
                      <div className="text-[11px] text-[#29180F]/75 mt-0.5">
                        Ram Krishna College, Madhubani (L.N. Mithila University)
                      </div>
                    </div>
                    <p className="mt-3 text-xs text-[#29180F]/75 leading-relaxed">
                      Specialized in commercial product management, high-conversion web architectures, enterprise automation, and international delivery.
                    </p>
                  </div>
                </div>
              </div>
            </div>

            {/* Verified Studio Location & Embedded Google Maps Link */}
            <div className="bg-[#FFFDF9] rounded-2xl p-6 sm:p-7 border border-[#C58A3D]/50 shadow-sm space-y-6">
              <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6">
                <div className="space-y-3 flex-1">
                  <div className="flex flex-wrap items-center gap-2">
                    <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#C58A3D]/15 text-[#C58A3D] text-xs font-bold border border-[#C58A3D]/30">
                      <MapPin className="w-3.5 h-3.5 text-[#C58A3D]" />
                      <span>Verified Physical Office Location</span>
                    </span>
                    <span className="text-[11px] text-[#25D366] font-semibold flex items-center gap-1 bg-[#25D366]/10 px-2.5 py-1 rounded-full border border-[#25D366]/20">
                      <CheckCircle2 className="w-3.5 h-3.5" />
                      <span>Publicly Audited Presence</span>
                    </span>
                  </div>

                  <h3 className="font-serif text-2xl font-semibold text-[#29180F]">
                    Verified Studio Coordinates &amp; Official Google Maps Location
                  </h3>

                  <p className="text-xs sm:text-sm text-[#29180F]/80 leading-relaxed">
                    Verify our operational studio pin directly on Google Maps. We maintain an authentic physical presence, enabling seamless international client meetings, local audits, and 100% legal &amp; institutional accountability.
                  </p>

                  <div className="flex flex-wrap items-center gap-3 pt-1 text-xs font-mono text-[#29180F]">
                    <span className="bg-[#FFF8F0] px-3 py-1.5 rounded-lg border border-[#EAD8C7] font-semibold">
                      Latitude: 26.44282&deg; N
                    </span>
                    <span className="bg-[#FFF8F0] px-3 py-1.5 rounded-lg border border-[#EAD8C7] font-semibold">
                      Longitude: 85.90200&deg; E
                    </span>
                    <span className="bg-[#FFF8F0] px-3 py-1.5 rounded-lg border border-[#EAD8C7] text-[#C58A3D] font-bold">
                      15z High-Resolution Pin
                    </span>
                  </div>

                  <div className="pt-2">
                    <span className="text-[11px] font-semibold text-[#29180F]/70 block mb-1">
                      Official Clickable Location Link:
                    </span>
                    <a
                      href={GOOGLE_MAPS_LOCATION_URL}
                      target="_blank"
                      rel="noreferrer"
                      className="group font-mono text-xs text-[#C58A3D] hover:text-[#29180F] underline font-bold break-all inline-flex items-center gap-1.5 transition-colors"
                      title="Open Official Office Location on Google Maps"
                    >
                      <span>{GOOGLE_MAPS_LOCATION_URL}</span>
                      <ExternalLink className="w-3.5 h-3.5 shrink-0 group-hover:translate-x-0.5 transition-transform" />
                    </a>
                  </div>
                </div>

                {/* Right Call To Actions for Maps & Contact */}
                <div className="flex flex-col sm:flex-row lg:flex-col gap-3 shrink-0 lg:w-64">
                  <a
                    href={GOOGLE_MAPS_LOCATION_URL}
                    target="_blank"
                    rel="noreferrer"
                    className="inline-flex items-center justify-center gap-2 px-6 py-3.5 rounded-xl bg-[#29180F] text-[#FFF8F0] hover:bg-[#1F120B] text-xs font-semibold shadow-sm hover:shadow transition-all text-center"
                    title="Click to open official office location in Google Maps"
                  >
                    <MapPin className="w-4 h-4 text-[#C58A3D]" />
                    <span>Open Official Map Pin</span>
                    <ExternalLink className="w-3.5 h-3.5 text-[#C58A3D]" />
                  </a>

                  <button
                    onClick={() => navigate('/contact')}
                    className="inline-flex items-center justify-center gap-2 px-6 py-3.5 rounded-xl bg-[#FFF8F0] hover:bg-[#F4E7DA] text-[#29180F] text-xs font-semibold border border-[#EAD8C7] transition-all cursor-pointer text-center"
                  >
                    <ShieldCheck className="w-4 h-4 text-[#25D366]" />
                    <span>Contact Leadership</span>
                  </button>
                </div>
              </div>

              {/* Clickable Embedded Map Preview Container */}
              <div className="relative rounded-2xl overflow-hidden border border-[#EAD8C7] shadow-sm bg-[#F4E7DA]">
                {/* Embedded interactive Google Map iframe */}
                <iframe
                  title="Tahanabi Tech Agency Official Office Location on Google Maps"
                  src="https://maps.google.com/maps?q=26.44282,85.9019995&hl=en&z=15&output=embed"
                  className="w-full h-64 sm:h-80 border-0"
                  loading="lazy"
                  referrerPolicy="no-referrer-when-downgrade"
                />

                {/* Interactive Clickable Overlay Bar */}
                <div className="p-3 bg-[#FFFDF9]/95 border-t border-[#EAD8C7] flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
                  <div className="flex items-center gap-2 text-[#29180F]">
                    <span className="w-2.5 h-2.5 rounded-full bg-[#25D366] animate-pulse" />
                    <span className="font-semibold">Official Office Pin &middot; 26.44282&deg; N, 85.90200&deg; E</span>
                  </div>

                  <a
                    href={GOOGLE_MAPS_LOCATION_URL}
                    target="_blank"
                    rel="noreferrer"
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#29180F] text-[#FFF8F0] hover:bg-[#1F120B] font-semibold text-[11px] shadow-xs transition-colors self-start sm:self-auto"
                  >
                    <span>Click to open location in Google Maps app</span>
                    <ExternalLink className="w-3 h-3 text-[#C58A3D]" />
                  </a>
                </div>
              </div>
            </div>

            {/* Trust Guarantee Metrics */}
            <div className="mt-8 pt-6 border-t border-[#EAD8C7] grid grid-cols-2 sm:grid-cols-4 gap-4 text-center">
              <div>
                <div className="font-serif text-xl sm:text-2xl font-bold text-[#29180F]">100%</div>
                <div className="text-[11px] text-[#29180F]/70 uppercase tracking-wide font-medium mt-0.5">
                  Verified Pedigree
                </div>
              </div>
              <div>
                <div className="font-serif text-xl sm:text-2xl font-bold text-[#C58A3D]">NIT Trichy</div>
                <div className="text-[11px] text-[#29180F]/70 uppercase tracking-wide font-medium mt-0.5">
                  CEO Engineering Core
                </div>
              </div>
              <div>
                <div className="font-serif text-xl sm:text-2xl font-bold text-[#29180F]">R.K. College</div>
                <div className="text-[11px] text-[#29180F]/70 uppercase tracking-wide font-medium mt-0.5">
                  Founder Product Lead
                </div>
              </div>
              <div>
                <div className="font-serif text-xl sm:text-2xl font-bold text-[#25D366]">2 Engineers</div>
                <div className="text-[11px] text-[#29180F]/70 uppercase tracking-wide font-medium mt-0.5">
                  In-House Security
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* BOTTOM SECTION: FOUR COMPACT FEATURE CARDS */}
        <div className="pt-6 border-t border-[#EAD8C7]">
          <div className="text-center max-w-xl mx-auto mb-8">
            <span className="text-xs uppercase tracking-widest text-[#C58A3D] font-semibold block mb-1">
              Core Pillars
            </span>
            <h2 className="font-serif text-xl sm:text-2xl font-semibold text-[#29180F]">
              Foundations of Our Client Engagements
            </h2>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {/* Feature 1 */}
            <div className="bg-[#FFFDF9] rounded-2xl p-6 border border-[#EAD8C7] shadow-xs hover:border-[#C58A3D] transition-colors flex flex-col justify-between">
              <div>
                <div className="w-10 h-10 rounded-xl bg-[#F4E7DA] text-[#C58A3D] flex items-center justify-center mb-3">
                  <Globe className="w-5 h-5" />
                </div>
                <h3 className="font-serif text-base font-semibold text-[#29180F]">
                  International business orientation
                </h3>
                <p className="mt-2 text-xs text-[#29180F]/70 leading-relaxed">
                  Tailored specifically for global operations, multi-currency commerce, and international business cultures across the Middle East, Europe, and the US.
                </p>
              </div>
              <div className="mt-4 pt-3 border-t border-[#EAD8C7]/50 text-[11px] text-[#C58A3D] font-medium">
                Worldwide standard
              </div>
            </div>

            {/* Feature 2 */}
            <div className="bg-[#FFFDF9] rounded-2xl p-6 border border-[#EAD8C7] shadow-xs hover:border-[#C58A3D] transition-colors flex flex-col justify-between">
              <div>
                <div className="w-10 h-10 rounded-xl bg-[#F4E7DA] text-[#C58A3D] flex items-center justify-center mb-3">
                  <Cpu className="w-5 h-5" />
                </div>
                <h3 className="font-serif text-base font-semibold text-[#29180F]">
                  Technology-focused solutions
                </h3>
                <p className="mt-2 text-xs text-[#29180F]/70 leading-relaxed">
                  Engineered with modern full-stack architectures, NIT Trichy system standards, high-performance edge APIs, and autonomous AI agents.
                </p>
              </div>
              <div className="mt-4 pt-3 border-t border-[#EAD8C7]/50 text-[11px] text-[#C58A3D] font-medium">
                NIT Trichy Pedigree
              </div>
            </div>

            {/* Feature 3 */}
            <div className="bg-[#FFFDF9] rounded-2xl p-6 border border-[#EAD8C7] shadow-xs hover:border-[#C58A3D] transition-colors flex flex-col justify-between">
              <div>
                <div className="w-10 h-10 rounded-xl bg-[#F4E7DA] text-[#C58A3D] flex items-center justify-center mb-3">
                  <TrendingUp className="w-5 h-5" />
                </div>
                <h3 className="font-serif text-base font-semibold text-[#29180F]">
                  Business-oriented development
                </h3>
                <p className="mt-2 text-xs text-[#29180F]/70 leading-relaxed">
                  Every product is focused on tangible business conversion, customer satisfaction, and operational efficiency with verified milestone delivery.
                </p>
              </div>
              <div className="mt-4 pt-3 border-t border-[#EAD8C7]/50 text-[11px] text-[#C58A3D] font-medium">
                ROI driven
              </div>
            </div>

            {/* Feature 4 */}
            <div className="bg-[#FFFDF9] rounded-2xl p-6 border border-[#EAD8C7] shadow-xs hover:border-[#C58A3D] transition-colors flex flex-col justify-between">
              <div>
                <div className="w-10 h-10 rounded-xl bg-[#F4E7DA] text-[#C58A3D] flex items-center justify-center mb-3">
                  <Clock className="w-5 h-5" />
                </div>
                <h3 className="font-serif text-base font-semibold text-[#29180F]">
                  Ongoing support
                </h3>
                <p className="mt-2 text-xs text-[#29180F]/70 leading-relaxed">
                  Proactive server optimization, weekly security scanning by our 2 dedicated in-house engineers, and SLA-backed engineering.
                </p>
              </div>
              <div className="mt-4 pt-3 border-t border-[#EAD8C7]/50 text-[11px] text-[#C58A3D] font-medium">
                SLA &amp; Security Audited
              </div>
            </div>
          </div>
        </div>

        {/* Reusable Nested Accordion FAQ Section */}
        <div className="mt-16">
          <AccordionFAQ
            title="About Tahanabi &amp; Credential FAQ"
            subtitle="Explore our verified institutional pedigree, founders' academic credentials, registered physical studio, and zero-outsourcing policy with nested detail."
            badge="Institutional Transparency &amp; Trust"
            items={ABOUT_FAQS}
            defaultOpenId="a-faq-1"
          />
        </div>

        {/* Live Client Reviews & Industry Commentary */}
        <div className="mt-16">
          <ClientFeedbackSection
            title="Verified Client Reviews &amp; Industry Commentary"
            subtitle="Transparent reviews from business executives and founders who collaborated with Tahanabi."
          />
        </div>
      </div>
    </div>
  );
};
