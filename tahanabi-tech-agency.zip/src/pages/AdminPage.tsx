import React, { useState, useEffect } from 'react';
import { useNavigation } from '../context/NavigationContext';
import { BrandLogo } from '../components/BrandLogo';
import {
  LayoutDashboard,
  FileText,
  Briefcase,
  Layers,
  Image as ImageIcon,
  Settings,
  Lock,
  Unlock,
  ExternalLink,
  Save,
  CheckCircle2,
  Trash2,
  Mail,
  Phone,
  RefreshCw,
  LogOut,
  Menu,
  X,
  Plus,
  MessageCircle,
  ShieldCheck,
  Check,
  Search,
  Filter,
  Reply,
  ShieldAlert,
  Key,
  UserCheck,
  History,
  Smartphone,
  Copy,
  AlertTriangle,
  KeyRound,
  UserPlus,
  Users,
  UserX,
} from 'lucide-react';
import {
  INITIAL_AGENCY_CONFIG,
  INDUSTRY_WORKS,
  SERVICES_LIST,
} from '../data/agencyData';
import { ContactInquiry, IndustryWork, ServiceItem, AgencyConfig } from '../types';
import { useInquiries } from '../context/InquiryContext';

type AdminTab =
  | 'dashboard'
  | 'inquiries'
  | 'pages'
  | 'work'
  | 'services'
  | 'content'
  | 'media'
  | 'comments'
  | 'settings'
  | 'audit';

export const AdminPage: React.FC = () => {
  const { navigate } = useNavigation();

  // Authentication & RBAC User Profile
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(() => {
    return sessionStorage.getItem('tahanabi_admin_auth') === 'true';
  });
  const [currentUser, setCurrentUser] = useState<{
    id: string;
    username: string;
    name: string;
    role: string;
    twoFactorEnabled?: boolean;
  } | null>(() => {
    try {
      const stored = sessionStorage.getItem('tahanabi_admin_user');
      return stored ? JSON.parse(stored) : null;
    } catch {
      return null;
    }
  });
  const [usernameInput, setUsernameInput] = useState('');
  const [passwordInput, setPasswordInput] = useState('');
  const [twoFactorInput, setTwoFactorInput] = useState('');
  const [requires2FA, setRequires2FA] = useState(false);
  const [authError, setAuthError] = useState('');
  const [isSubmittingLogin, setIsSubmittingLogin] = useState(false);

  // Security Management States (Change Password & 2FA)
  const [showPasswordModal, setShowPasswordModal] = useState(false);
  const [oldPasswordInput, setOldPasswordInput] = useState('');
  const [newPasswordInput, setNewPasswordInput] = useState('');
  const [confirmPasswordInput, setConfirmPasswordInput] = useState('');
  const [passwordChangeError, setPasswordChangeError] = useState('');
  const [passwordChangeSuccess, setPasswordChangeSuccess] = useState('');
  const [isSubmittingPasswordChange, setIsSubmittingPasswordChange] = useState(false);

  const [showTwoFactorModal, setShowTwoFactorModal] = useState(false);
  const [twoFactorSecretData, setTwoFactorSecretData] = useState<{ secret: string; otpauthUrl: string } | null>(null);
  const [twoFactorVerifyCode, setTwoFactorVerifyCode] = useState('');
  const [twoFactorSetupError, setTwoFactorSetupError] = useState('');
  const [twoFactorSetupSuccess, setTwoFactorSetupSuccess] = useState('');
  const [copiedSecret, setCopiedSecret] = useState(false);

  // Audit Logs State
  const [auditLogs, setAuditLogs] = useState<any[]>([]);
  const [auditFilter, setAuditFilter] = useState<'all' | 'login' | 'status' | 'delete' | 'denied'>('all');
  const [isLoadingAudit, setIsLoadingAudit] = useState(false);
  const [rotateSuccess, setRotateSuccess] = useState('');

  // Admin Team & Accounts State (RBAC Management)
  const [adminUsers, setAdminUsers] = useState<any[]>([]);
  const [isLoadingUsers, setIsLoadingUsers] = useState(false);
  const [showAddUserModal, setShowAddUserModal] = useState(false);
  const [newUsernameInput, setNewUsernameInput] = useState('');
  const [newFullNameInput, setNewFullNameInput] = useState('');
  const [newRoleInput, setNewRoleInput] = useState<'SUPER_ADMIN' | 'ADMIN' | 'MANAGER' | 'STAFF' | 'READ_ONLY'>('ADMIN');
  const [newUserPasswordInput, setNewUserPasswordInput] = useState('');
  const [addUserError, setAddUserError] = useState('');
  const [addUserSuccess, setAddUserSuccess] = useState('');
  const [isSubmittingAddUser, setIsSubmittingAddUser] = useState(false);

  // Active Tab
  const [activeTab, setActiveTab] = useState<AdminTab>('dashboard');
  const [mobileSidebarOpen, setMobileSidebarOpen] = useState(false);

  // Agency data states (live editable in admin)
  const [agencyConfig, setAgencyConfig] = useState<AgencyConfig>(() => {
    try {
      const stored = localStorage.getItem('tahanabi_config');
      return stored ? JSON.parse(stored) : INITIAL_AGENCY_CONFIG;
    } catch {
      return INITIAL_AGENCY_CONFIG;
    }
  });

  const [works, setWorks] = useState<IndustryWork[]>(() => {
    try {
      const stored = localStorage.getItem('tahanabi_works');
      return stored ? JSON.parse(stored) : INDUSTRY_WORKS;
    } catch {
      return INDUSTRY_WORKS;
    }
  });

  const [services, setServices] = useState<ServiceItem[]>(() => {
    try {
      const stored = localStorage.getItem('tahanabi_services');
      return stored ? JSON.parse(stored) : SERVICES_LIST;
    } catch {
      return SERVICES_LIST;
    }
  });

  // Central State Context: Client Inquiries
  const {
    inquiries,
    isLoading: isLoadingInquiries,
    markAsVerified,
    markAsReplied,
    updateStatus,
    deleteInquiry,
    fetchInquiries,
    metrics: inquiryMetrics,
  } = useInquiries();

  const [inquiryFilter, setInquiryFilter] = useState<'all' | 'verified' | 'replied' | 'pending'>('all');
  const [inquirySearch, setInquirySearch] = useState('');

  const [comments, setComments] = useState<any[]>([]);
  const [isLoadingComments, setIsLoadingComments] = useState(false);
  const isSyncing = isLoadingInquiries || isLoadingComments;
  const [saveSuccess, setSaveSuccess] = useState(false);

  // Load backend data on mount & auth
  const fetchAuditLogs = async () => {
    const token = sessionStorage.getItem('tahanabi_admin_token');
    if (!token) return;
    setIsLoadingAudit(true);
    try {
      const res = await fetch('/api/admin/audit-logs', {
        headers: { Authorization: `Bearer ${token}` },
      });
      const data = await res.json();
      if (data.success && Array.isArray(data.data)) {
        setAuditLogs(data.data);
      }
    } catch (err) {
      console.warn('Failed to load audit logs:', err);
    } finally {
      setIsLoadingAudit(false);
    }
  };

  const fetchAdminUsers = async () => {
    const token = sessionStorage.getItem('tahanabi_admin_token');
    if (!token) return;
    setIsLoadingUsers(true);
    try {
      const res = await fetch('/api/admin/users', {
        headers: { Authorization: `Bearer ${token}` },
      });
      const data = await res.json();
      if (data.success && Array.isArray(data.data)) {
        setAdminUsers(data.data);
      }
    } catch (err) {
      console.warn('Failed to fetch admin users:', err);
    } finally {
      setIsLoadingUsers(false);
    }
  };

  const handleAddUser = async (e: React.FormEvent) => {
    e.preventDefault();
    setAddUserError('');
    setAddUserSuccess('');
    const token = sessionStorage.getItem('tahanabi_admin_token');
    if (!token) return;

    setIsSubmittingAddUser(true);
    try {
      const res = await fetch('/api/admin/users', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          username: newUsernameInput.trim().toLowerCase(),
          name: newFullNameInput.trim() || newUsernameInput.trim(),
          role: newRoleInput,
          password: newUserPasswordInput,
        }),
      });
      const data = await res.json();
      if (res.ok && data.success) {
        setAddUserSuccess(data.message || 'New administrator successfully added to the vault!');
        setNewUsernameInput('');
        setNewFullNameInput('');
        setNewUserPasswordInput('');
        fetchAdminUsers();
        fetchAuditLogs();
        setTimeout(() => {
          setShowAddUserModal(false);
          setAddUserSuccess('');
        }, 2000);
      } else {
        setAddUserError(data.error || 'Failed to create administrator account.');
      }
    } catch {
      setAddUserError('Network communication error creating administrator account.');
    } finally {
      setIsSubmittingAddUser(false);
    }
  };

  const handleDeleteUser = async (userId: string, targetUsername: string) => {
    if (!confirm(`Are you sure you want to permanently delete administrator account "${targetUsername}"? This will terminate all active sessions.`)) {
      return;
    }
    const token = sessionStorage.getItem('tahanabi_admin_token');
    if (!token) return;

    try {
      const res = await fetch(`/api/admin/users/${userId}`, {
        method: 'DELETE',
        headers: { Authorization: `Bearer ${token}` },
      });
      const data = await res.json();
      if (res.ok && data.success) {
        fetchAdminUsers();
        fetchAuditLogs();
      } else {
        alert(data.error || 'Failed to delete administrator account.');
      }
    } catch {
      alert('Error communicating with security gateway.');
    }
  };

  const fetchBackendData = async () => {
    setIsLoadingComments(true);
    await fetchInquiries();
    await fetchAuditLogs();
    await fetchAdminUsers();
    try {
      const cmtRes = await fetch('/api/comments');
      const cmtData = await cmtRes.json();
      if (cmtData.success && Array.isArray(cmtData.data)) {
        setComments(cmtData.data);
      }
    } catch (err) {
      console.warn('Fallback to local comments', err);
    } finally {
      setIsLoadingComments(false);
    }
  };

  useEffect(() => {
    if (isAuthenticated) {
      fetchBackendData();
    }
  }, [isAuthenticated]);

  // 15-minute physical idle auto-lockout protection
  useEffect(() => {
    if (!isAuthenticated) return;
    let timeoutId: any;
    const resetTimer = () => {
      clearTimeout(timeoutId);
      timeoutId = setTimeout(() => {
        handleLogout();
        setAuthError('Session automatically locked due to 15 minutes of inactivity for your protection.');
      }, 15 * 60 * 1000);
    };

    const events = ['mousedown', 'keydown', 'scroll', 'touchstart'];
    events.forEach((evt) => window.addEventListener(evt, resetTimer, { passive: true }));
    resetTimer();

    return () => {
      clearTimeout(timeoutId);
      events.forEach((evt) => window.removeEventListener(evt, resetTimer));
    };
  }, [isAuthenticated]);

  // Filtered inquiries list
  const filteredInquiries = inquiries.filter((inq) => {
    if (inquiryFilter === 'verified' && inq.status !== 'verified') return false;
    if (inquiryFilter === 'replied' && inq.status !== 'replied') return false;
    if (inquiryFilter === 'pending' && inq.status !== 'new' && inq.status !== 'in_progress') return false;

    if (inquirySearch.trim()) {
      const q = inquirySearch.toLowerCase();
      const matchName = inq.name.toLowerCase().includes(q);
      const matchEmail = inq.email.toLowerCase().includes(q);
      const matchPhone = inq.phone.toLowerCase().includes(q);
      const matchInterest = inq.interest.toLowerCase().includes(q);
      const matchMsg = inq.message.toLowerCase().includes(q);
      return matchName || matchEmail || matchPhone || matchInterest || matchMsg;
    }

    return true;
  });

  // Save handler for Agency Config
  const handleSaveConfig = (e: React.FormEvent) => {
    e.preventDefault();
    localStorage.setItem('tahanabi_config', JSON.stringify(agencyConfig));
    setSaveSuccess(true);
    setTimeout(() => setSaveSuccess(false), 3000);
  };

  // Auth handler (Server-verified PBKDF2 with optional 2FA)
  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!passwordInput.trim()) return;
    setIsSubmittingLogin(true);
    setAuthError('');

    try {
      const res = await fetch('/api/admin/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          username: usernameInput.trim() || undefined,
          password: passwordInput.trim(),
          twoFactorCode: twoFactorInput.trim() || undefined,
        }),
      });
      const data = await res.json();
      if (res.ok && data.success) {
        setIsAuthenticated(true);
        sessionStorage.setItem('tahanabi_admin_auth', 'true');
        sessionStorage.setItem('tahanabi_admin_token', data.token);
        sessionStorage.setItem('tahanabi_admin_user', JSON.stringify(data.user));
        setCurrentUser(data.user);
        setPasswordInput('');
        setUsernameInput('');
        setTwoFactorInput('');
        setRequires2FA(false);
        fetchBackendData();
      } else if (data.requires2FA) {
        setRequires2FA(true);
        setAuthError(data.error || 'Please enter your 6-digit Authenticator code.');
      } else {
        setAuthError(data.error || 'Authentication denied. Invalid credentials provided.');
      }
    } catch {
      setAuthError('Error communicating with security authentication gateway.');
    } finally {
      setIsSubmittingLogin(false);
    }
  };

  const handleLogout = async () => {
    const token = sessionStorage.getItem('tahanabi_admin_token');
    if (token) {
      try {
        await fetch('/api/admin/logout', {
          method: 'POST',
          headers: { Authorization: `Bearer ${token}` },
        });
      } catch {
        // Ignored
      }
    }
    sessionStorage.removeItem('tahanabi_admin_auth');
    sessionStorage.removeItem('tahanabi_admin_token');
    sessionStorage.removeItem('tahanabi_admin_user');
    setIsAuthenticated(false);
    setCurrentUser(null);
    setRequires2FA(false);
  };

  // Secure Password Change Handler (Phase 1 & 7)
  const handleChangePassword = async (e: React.FormEvent) => {
    e.preventDefault();
    setPasswordChangeError('');
    setPasswordChangeSuccess('');

    if (newPasswordInput !== confirmPasswordInput) {
      setPasswordChangeError('New passwords do not match. Please re-enter.');
      return;
    }

    const token = sessionStorage.getItem('tahanabi_admin_token');
    if (!token) return;

    setIsSubmittingPasswordChange(true);
    try {
      const res = await fetch('/api/admin/change-password', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          currentPassword: oldPasswordInput,
          newPassword: newPasswordInput,
        }),
      });
      const data = await res.json();
      if (res.ok && data.success) {
        setPasswordChangeSuccess(data.message || 'Password successfully encrypted and updated!');
        if (data.newToken) {
          sessionStorage.setItem('tahanabi_admin_token', data.newToken);
        }
        setOldPasswordInput('');
        setNewPasswordInput('');
        setConfirmPasswordInput('');
        setTimeout(() => {
          setShowPasswordModal(false);
          setPasswordChangeSuccess('');
        }, 2200);
      } else {
        setPasswordChangeError(data.error || 'Failed to update password.');
      }
    } catch {
      setPasswordChangeError('Connection error updating security credentials.');
    } finally {
      setIsSubmittingPasswordChange(false);
    }
  };

  // Two-Factor Authentication Setup Handler (RFC 6238 TOTP)
  const startTwoFactorSetup = async () => {
    const token = sessionStorage.getItem('tahanabi_admin_token');
    if (!token) return;
    setTwoFactorSetupError('');
    setTwoFactorSetupSuccess('');
    try {
      const res = await fetch('/api/admin/2fa/setup', {
        method: 'POST',
        headers: { Authorization: `Bearer ${token}` },
      });
      const data = await res.json();
      if (res.ok && data.success) {
        setTwoFactorSecretData(data);
        setShowTwoFactorModal(true);
      }
    } catch (err) {
      console.warn('2FA setup init failed', err);
    }
  };

  const verifyAndEnableTwoFactor = async (e: React.FormEvent) => {
    e.preventDefault();
    const token = sessionStorage.getItem('tahanabi_admin_token');
    if (!token || !twoFactorSecretData) return;

    setTwoFactorSetupError('');
    try {
      const res = await fetch('/api/admin/2fa/enable', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          secret: twoFactorSecretData.secret,
          code: twoFactorVerifyCode.trim(),
        }),
      });
      const data = await res.json();
      if (res.ok && data.success) {
        setTwoFactorSetupSuccess('Two-Factor Authentication is now actively protecting your account!');
        setCurrentUser((prev) => (prev ? { ...prev, twoFactorEnabled: true } : null));
        setTwoFactorVerifyCode('');
        setTimeout(() => {
          setShowTwoFactorModal(false);
          setTwoFactorSetupSuccess('');
        }, 2500);
      } else {
        setTwoFactorSetupError(data.error || 'Invalid verification code. Please check your authenticator app.');
      }
    } catch {
      setTwoFactorSetupError('Network error confirming 2FA.');
    }
  };

  const updateInquiryStatus = async (id: string, currentStatus: string) => {
    const nextStatus =
      currentStatus === 'new'
        ? 'verified'
        : currentStatus === 'verified'
        ? 'replied'
        : currentStatus === 'replied'
        ? 'completed'
        : 'new';

    await updateStatus(id, nextStatus as any);
  };

  const deleteComment = async (id: string) => {
    const token = sessionStorage.getItem('tahanabi_admin_token');
    try {
      const res = await fetch(`/api/comments/${id}`, {
        method: 'DELETE',
        headers: token ? { Authorization: `Bearer ${token}` } : {},
      });
      if (res.ok) {
        setComments((prev) => prev.filter((c) => c.id !== id));
      } else {
        const json = await res.json();
        alert(json.error || 'Access denied: Requires ADMIN role to delete comments.');
      }
    } catch {
      setComments((prev) => prev.filter((c) => c.id !== id));
    }
  };

  const handleRotateAuditLogs = async () => {
    const token = sessionStorage.getItem('tahanabi_admin_token');
    if (!token) return;
    try {
      const res = await fetch('/api/admin/audit-logs/rotate', {
        method: 'POST',
        headers: { Authorization: `Bearer ${token}` },
      });
      const data = await res.json();
      if (res.ok && data.success) {
        setRotateSuccess(data.message);
        setAuditLogs([]);
        setTimeout(() => setRotateSuccess(''), 4000);
      } else {
        alert(data.error || 'Failed to rotate audit logs.');
      }
    } catch (err) {
      console.warn('Log rotate error:', err);
    }
  };

  const renderInquiriesDashboard = (isDedicated = false) => (
    <div className="bg-[#FFFDF9] rounded-2xl p-6 sm:p-7 border border-[#EAD8C7] shadow-sm space-y-6">
      {/* Header & KPI Summary Cards */}
      <div>
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-[#EAD8C7]/70">
          <div>
            <div className="flex items-center gap-2">
              <ShieldCheck className="w-5 h-5 text-[#25D366]" />
              <h3 className="font-serif text-lg font-semibold text-[#29180F]">
                Verified Inquiries Command Dashboard
              </h3>
            </div>
            <p className="text-xs text-[#29180F]/70 mt-0.5">
              Central state context sync &middot; Mark inquiries as &lsquo;Verified&rsquo; or &lsquo;Replied&rsquo; with instant status indicators.
            </p>
          </div>

          <div className="flex items-center gap-2">
            <span className="text-xs font-semibold text-[#C58A3D] bg-[#F4E7DA] px-3 py-1 rounded-full border border-[#EAD8C7]">
              {inquiryMetrics.total} Total Inquiries
            </span>
          </div>
        </div>

        {/* 4 Live KPI Metric Cards */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-4">
          <div className="bg-[#FFF8F0] p-3 rounded-xl border border-[#EAD8C7]">
            <div className="text-[11px] text-[#29180F]/70 font-medium">Total Volume</div>
            <div className="font-serif text-xl font-bold text-[#29180F] mt-0.5">
              {inquiryMetrics.total}
            </div>
            <div className="text-[10px] text-[#29180F]/60 mt-0.5">All incoming channels</div>
          </div>

          <div className="bg-[#25D366]/10 p-3 rounded-xl border border-[#25D366]/30">
            <div className="text-[11px] text-[#1b7e3d] font-semibold flex items-center gap-1">
              <ShieldCheck className="w-3.5 h-3.5" />
              <span>100% Verified</span>
            </div>
            <div className="font-serif text-xl font-bold text-[#1b7e3d] mt-0.5">
              {inquiryMetrics.verified}
            </div>
            <div className="text-[10px] text-[#1b7e3d]/80 mt-0.5">Verified authenticity</div>
          </div>

          <div className="bg-blue-50 p-3 rounded-xl border border-blue-200">
            <div className="text-[11px] text-blue-800 font-semibold flex items-center gap-1">
              <Check className="w-3.5 h-3.5" />
              <span>Replied</span>
            </div>
            <div className="font-serif text-xl font-bold text-blue-800 mt-0.5">
              {inquiryMetrics.replied}
            </div>
            <div className="text-[10px] text-blue-700/80 mt-0.5">Followed up</div>
          </div>

          <div className="bg-amber-50 p-3 rounded-xl border border-amber-200">
            <div className="text-[11px] text-amber-900 font-semibold flex items-center gap-1">
              <span className="w-2 h-2 rounded-full bg-amber-500 animate-pulse" />
              <span>Pending Review</span>
            </div>
            <div className="font-serif text-xl font-bold text-amber-900 mt-0.5">
              {inquiryMetrics.pending}
            </div>
            <div className="text-[10px] text-amber-800/80 mt-0.5">Action required</div>
          </div>
        </div>
      </div>

      {/* Filter Tabs & Search Controls */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pt-2">
        {/* Filter pills */}
        <div className="flex flex-wrap items-center gap-1.5 text-xs">
          <button
            type="button"
            onClick={() => setInquiryFilter('all')}
            className={`px-3 py-1.5 rounded-lg font-medium transition-colors cursor-pointer ${
              inquiryFilter === 'all'
                ? 'bg-[#29180F] text-[#FFF8F0]'
                : 'bg-[#F4E7DA] text-[#29180F] hover:bg-[#EAD8C7]'
            }`}
          >
            All ({inquiryMetrics.total})
          </button>

          <button
            type="button"
            onClick={() => setInquiryFilter('verified')}
            className={`px-3 py-1.5 rounded-lg font-medium transition-colors cursor-pointer flex items-center gap-1 ${
              inquiryFilter === 'verified'
                ? 'bg-[#25D366] text-[#1A1009] font-bold'
                : 'bg-[#25D366]/15 text-[#1b7e3d] hover:bg-[#25D366]/25'
            }`}
          >
            <ShieldCheck className="w-3.5 h-3.5" />
            <span>Verified ({inquiryMetrics.verified})</span>
          </button>

          <button
            type="button"
            onClick={() => setInquiryFilter('replied')}
            className={`px-3 py-1.5 rounded-lg font-medium transition-colors cursor-pointer flex items-center gap-1 ${
              inquiryFilter === 'replied'
                ? 'bg-blue-600 text-white font-bold'
                : 'bg-blue-100 text-blue-900 hover:bg-blue-200'
            }`}
          >
            <Check className="w-3.5 h-3.5" />
            <span>Replied ({inquiryMetrics.replied})</span>
          </button>

          <button
            type="button"
            onClick={() => setInquiryFilter('pending')}
            className={`px-3 py-1.5 rounded-lg font-medium transition-colors cursor-pointer flex items-center gap-1 ${
              inquiryFilter === 'pending'
                ? 'bg-amber-600 text-white font-bold'
                : 'bg-amber-100 text-amber-900 hover:bg-amber-200'
            }`}
          >
            <span>Pending ({inquiryMetrics.pending})</span>
          </button>
        </div>

        {/* Search input */}
        <div className="relative sm:w-64">
          <Search className="w-3.5 h-3.5 text-[#29180F]/50 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={inquirySearch}
            onChange={(e) => setInquirySearch(e.target.value)}
            placeholder="Search by client, interest..."
            className="w-full pl-8 pr-3 py-1.5 rounded-lg border border-[#EAD8C7] bg-[#FFF8F0] text-xs text-[#29180F] placeholder-[#29180F]/40 focus:outline-hidden focus:border-[#C58A3D]"
          />
        </div>
      </div>

      {/* Inquiries Table */}
      <div className="overflow-x-auto rounded-xl border border-[#EAD8C7]/80">
        <table className="w-full text-left text-xs">
          <thead>
            <tr className="bg-[#F4E7DA]/60 border-b border-[#EAD8C7] text-[#29180F]/80">
              <th className="py-2.5 px-3 font-semibold">Status Indicator</th>
              <th className="py-2.5 px-3 font-semibold">Client Name</th>
              <th className="py-2.5 px-3 font-semibold">Requirement Topic</th>
              <th className="py-2.5 px-3 font-semibold">Message Body</th>
              <th className="py-2.5 px-3 font-semibold">Contact Info</th>
              <th className="py-2.5 px-3 font-semibold">Received</th>
              <th className="py-2.5 px-3 font-semibold text-right">Verification &amp; Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-[#EAD8C7]/50 bg-[#FFFDF9]">
            {filteredInquiries.length === 0 ? (
              <tr>
                <td colSpan={7} className="py-8 text-center text-xs text-[#29180F]/60">
                  No inquiries found matching &ldquo;{inquiryFilter}&rdquo; filter.
                </td>
              </tr>
            ) : (
              filteredInquiries.map((inq) => {
                const cleanPhone = inq.phone.replace(/[^0-9]/g, '');

                return (
                  <tr key={inq.id} className="hover:bg-[#F4E7DA]/30 transition-colors">
                    {/* Visual Status Indicator */}
                    <td className="py-3 px-3 whitespace-nowrap">
                      {inq.status === 'verified' ? (
                        <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[11px] font-bold bg-[#25D366]/15 text-[#1b7e3d] border border-[#25D366]/30 shadow-2xs">
                          <ShieldCheck className="w-3.5 h-3.5 text-[#25D366]" />
                          <span>100% Verified</span>
                          {inq.verifiedAt && (
                            <span className="text-[10px] opacity-75 font-mono">({inq.verifiedAt})</span>
                          )}
                        </span>
                      ) : inq.status === 'replied' ? (
                        <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[11px] font-bold bg-blue-100 text-blue-800 border border-blue-200">
                          <Check className="w-3.5 h-3.5 text-blue-600" />
                          <span>Replied</span>
                          {inq.repliedAt && (
                            <span className="text-[10px] opacity-75 font-mono">({inq.repliedAt})</span>
                          )}
                        </span>
                      ) : inq.status === 'new' ? (
                        <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[11px] font-bold bg-amber-100 text-amber-900 border border-amber-300">
                          <span className="w-2 h-2 rounded-full bg-amber-500 animate-pulse" />
                          <span>Action Needed</span>
                        </span>
                      ) : inq.status === 'in_progress' ? (
                        <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[11px] font-bold bg-purple-100 text-purple-900 border border-purple-300">
                          <span>In Progress</span>
                        </span>
                      ) : (
                        <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[11px] font-bold bg-stone-100 text-stone-800 border border-stone-200">
                          <span>Archived</span>
                        </span>
                      )}
                    </td>

                    {/* Client Name */}
                    <td className="py-3 px-3 font-semibold text-[#29180F] whitespace-nowrap">
                      {inq.name}
                    </td>

                    {/* Interest Topic */}
                    <td className="py-3 px-3 whitespace-nowrap">
                      <span className="px-2.5 py-0.5 rounded-full bg-[#F4E7DA] text-[#C58A3D] font-semibold text-[10px]">
                        {inq.interest}
                      </span>
                    </td>

                    {/* Message Body */}
                    <td className="py-3 px-3 text-[#29180F]/80 max-w-xs truncate" title={inq.message}>
                      {inq.message}
                    </td>

                    {/* Contact Info */}
                    <td className="py-3 px-3 text-[#29180F]/80 whitespace-nowrap">
                      <div className="font-medium">{inq.email}</div>
                      <div className="text-[10px] text-[#29180F]/60 font-mono">{inq.phone}</div>
                    </td>

                    {/* Received Time */}
                    <td className="py-3 px-3 text-[#29180F]/60 whitespace-nowrap text-[11px]">
                      {inq.timestamp}
                    </td>

                    {/* Actions: Mark Verified, Mark Replied, WhatsApp, Delete */}
                    <td className="py-3 px-3 text-right whitespace-nowrap">
                      <div className="inline-flex items-center gap-1.5">
                        {/* Mark Verified Action */}
                        <button
                          type="button"
                          onClick={() => markAsVerified(inq.id)}
                          className={`px-2 py-1 rounded-lg text-[10px] font-bold border transition-all cursor-pointer flex items-center gap-1 ${
                            inq.status === 'verified'
                              ? 'bg-[#25D366]/20 text-[#1b7e3d] border-[#25D366]/40'
                              : 'bg-[#FFF8F0] hover:bg-[#25D366]/15 text-[#29180F] border-[#EAD8C7]'
                          }`}
                          title="Mark inquiry as 100% Verified"
                        >
                          <ShieldCheck className="w-3 h-3 text-[#25D366]" />
                          <span>Verify</span>
                        </button>

                        {/* Mark Replied Action */}
                        <button
                          type="button"
                          onClick={() => markAsReplied(inq.id)}
                          className={`px-2 py-1 rounded-lg text-[10px] font-bold border transition-all cursor-pointer flex items-center gap-1 ${
                            inq.status === 'replied'
                              ? 'bg-blue-100 text-blue-800 border-blue-300'
                              : 'bg-[#FFF8F0] hover:bg-blue-50 text-[#29180F] border-[#EAD8C7]'
                          }`}
                          title="Mark inquiry as Replied"
                        >
                          <Check className="w-3 h-3 text-blue-600" />
                          <span>Replied</span>
                        </button>

                        {/* WhatsApp Link */}
                        {cleanPhone && (
                          <a
                            href={`https://wa.me/${cleanPhone}?text=${encodeURIComponent(
                              `Hello ${inq.name}, this is Tahanabi Tech Agency following up on your ${inq.interest} inquiry.`
                            )}`}
                            target="_blank"
                            rel="noreferrer"
                            className="p-1.5 rounded-lg bg-[#25D366]/15 text-[#25D366] hover:bg-[#25D366]/30 transition-colors"
                            title="Reply via WhatsApp"
                          >
                            <MessageCircle className="w-3.5 h-3.5" />
                          </a>
                        )}

                        {/* Delete */}
                        <button
                          type="button"
                          onClick={() => deleteInquiry(inq.id)}
                          className="p-1.5 rounded-lg text-[#29180F]/40 hover:text-rose-600 hover:bg-rose-50 transition-colors cursor-pointer"
                          title="Delete inquiry"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })
            )}
          </tbody>
        </table>
      </div>
    </div>
  );

  // If not logged in, render authentication gateway
  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-[#FFF8F0] flex items-center justify-center p-4">
        <div className="w-full max-w-md bg-[#FFFDF9] rounded-3xl p-8 border border-[#EAD8C7] shadow-xl text-center">
          <div className="flex justify-center mb-6">
            <BrandLogo isLightMode={true} />
          </div>

          <div className="w-12 h-12 rounded-2xl bg-[#29180F] text-[#C58A3D] flex items-center justify-center mx-auto mb-4">
            <Lock className="w-6 h-6" />
          </div>

          <h1 className="font-serif text-2xl font-semibold text-[#29180F] mb-1">
            Admin Authentication
          </h1>
          <p className="text-xs text-[#29180F]/70 mb-6">
            Restricted agency control panel. Zero-trust server verification.
          </p>

          <form onSubmit={handleLogin} className="space-y-4 text-left">
            <div>
              <label className="block text-[11px] font-semibold text-[#29180F]/80 uppercase tracking-wider mb-1.5">
                Administrator Username
              </label>
              <input
                type="text"
                required
                autoComplete="username"
                value={usernameInput}
                onChange={(e) => setUsernameInput(e.target.value)}
                placeholder="Enter administrator username..."
                className="w-full px-4 py-2.5 rounded-xl bg-[#FFF8F0] border border-[#EAD8C7] text-sm text-[#29180F] focus:outline-none focus:border-[#C58A3D]"
              />
            </div>

            <div>
              <label className="block text-[11px] font-semibold text-[#29180F]/80 uppercase tracking-wider mb-1.5">
                Password
              </label>
              <input
                type="password"
                required
                autoComplete="current-password"
                value={passwordInput}
                onChange={(e) => setPasswordInput(e.target.value)}
                placeholder="Enter password..."
                className="w-full px-4 py-2.5 rounded-xl bg-[#FFF8F0] border border-[#EAD8C7] text-sm text-[#29180F] focus:outline-none focus:border-[#C58A3D]"
              />
            </div>

            {requires2FA && (
              <div className="p-3.5 rounded-xl bg-blue-50/70 border border-blue-200 space-y-1.5">
                <label className="block text-[11px] font-semibold text-blue-900 uppercase tracking-wider flex items-center gap-1.5">
                  <Smartphone className="w-3.5 h-3.5 text-blue-600" />
                  <span>2FA Security Code (Authenticator App)</span>
                </label>
                <input
                  type="text"
                  maxLength={6}
                  autoFocus
                  required
                  value={twoFactorInput}
                  onChange={(e) => setTwoFactorInput(e.target.value.replace(/\D/g, ''))}
                  placeholder="000000"
                  className="w-full px-4 py-2 text-center tracking-widest font-mono text-base rounded-lg bg-white border border-blue-300 text-blue-950 focus:outline-none focus:border-blue-600"
                />
                <p className="text-[10px] text-blue-800">
                  Open your Google Authenticator or Authy app and enter the 6-digit rolling code.
                </p>
              </div>
            )}

            {authError && (
              <div className="p-3 rounded-xl bg-rose-50 border border-rose-200 text-rose-700 text-xs font-medium flex items-center gap-2">
                <ShieldAlert className="w-4 h-4 text-rose-600 shrink-0" />
                <span>{authError}</span>
              </div>
            )}

            <button
              type="submit"
              disabled={isSubmittingLogin}
              className="w-full py-3 rounded-xl bg-[#29180F] text-[#FFF8F0] hover:bg-[#1F120B] text-xs font-semibold flex items-center justify-center gap-2 transition-colors cursor-pointer disabled:opacity-70"
            >
              {isSubmittingLogin ? (
                <>
                  <RefreshCw className="w-4 h-4 text-[#C58A3D] animate-spin" />
                  <span>Verifying Credentials...</span>
                </>
              ) : (
                <>
                  <Unlock className="w-4 h-4 text-[#C58A3D]" />
                  <span>Authenticate &amp; Unlock</span>
                </>
              )}
            </button>
          </form>

          {/* Master Provisioned Access Credentials */}
          <div className="mt-4 p-3.5 rounded-2xl bg-[#FFF8F0] border border-[#EAD8C7] text-left text-xs text-[#29180F] space-y-2">
            <div className="flex items-center gap-1.5 font-semibold text-[#29180F]">
              <Key className="w-3.5 h-3.5 text-[#C58A3D]" />
              <span>Initial Master Credentials:</span>
            </div>
            <div className="grid grid-cols-2 gap-2 text-[11px] font-mono">
              <div className="bg-white p-2 rounded-lg border border-[#EAD8C7]">
                <div className="text-[10px] text-[#29180F]/60">Username</div>
                <div className="font-bold text-[#29180F]">superadmin</div>
              </div>
              <div className="bg-white p-2 rounded-lg border border-[#EAD8C7]">
                <div className="text-[10px] text-[#29180F]/60">Password</div>
                <div className="font-bold text-[#29180F]">tahanabi2026</div>
              </div>
            </div>
            <p className="text-[10px] text-[#29180F]/70 leading-relaxed">
              Once authenticated, go to <strong>Site Settings &rarr; Team &amp; Passwords</strong> to change your master password or create new administrator accounts.
            </p>
          </div>

          {/* Real-World Security Badges */}
          <div className="mt-4 p-3 rounded-xl bg-[#FFF8F0] border border-[#EAD8C7] text-[11px] text-[#29180F]/70 flex items-center justify-center gap-1.5">
            <ShieldCheck className="w-4 h-4 text-[#25D366] shrink-0" />
            <span>256-Bit Cryptographic Vault &middot; 2FA Protected &middot; Anti-Brute-Force</span>
          </div>

          <div className="mt-4">
            <button
              onClick={() => navigate('/')}
              className="text-xs text-[#29180F]/70 hover:underline"
            >
              &larr; Back to Public Website
            </button>
          </div>
        </div>
      </div>
    );
  }

  // Authenticated Admin Dashboard Layout
  return (
    <div className="min-h-screen bg-[#FFF8F0] flex flex-col md:flex-row">
      {/* MOBILE HEADER */}
      <div className="md:hidden bg-[#1A1009] text-[#FFF8F0] px-4 py-3 flex items-center justify-between border-b border-[#29180F]">
        <BrandLogo isLightMode={false} />
        <button
          onClick={() => setMobileSidebarOpen(!mobileSidebarOpen)}
          className="p-2 text-[#FFF8F0]"
        >
          {mobileSidebarOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
        </button>
      </div>

      {/* DARK BROWN / BLACK SIDEBAR */}
      <aside
        className={`w-64 bg-[#1A1009] text-[#FFF8F0] flex flex-col justify-between p-5 border-r border-[#29180F] z-40 shrink-0 ${
          mobileSidebarOpen ? 'block' : 'hidden md:flex'
        }`}
      >
        <div>
          {/* Logo */}
          <div className="pb-6 border-b border-white/10 mb-6">
            <BrandLogo isLightMode={false} />
          </div>

          {/* Sidebar Nav Items */}
          <nav className="space-y-1 text-xs">
            <button
              onClick={() => {
                setActiveTab('dashboard');
                setMobileSidebarOpen(false);
              }}
              className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl transition-colors cursor-pointer text-left ${
                activeTab === 'dashboard'
                  ? 'bg-[#C58A3D] text-[#1A1009] font-semibold'
                  : 'text-white/70 hover:text-white hover:bg-white/5'
              }`}
            >
              <LayoutDashboard className="w-4 h-4 shrink-0" />
              <span>Dashboard</span>
            </button>

            <button
              onClick={() => {
                setActiveTab('inquiries');
                setMobileSidebarOpen(false);
              }}
              className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl transition-colors cursor-pointer text-left ${
                activeTab === 'inquiries'
                  ? 'bg-[#C58A3D] text-[#1A1009] font-semibold'
                  : 'text-white/70 hover:text-white hover:bg-white/5'
              }`}
            >
              <div className="flex items-center gap-3">
                <ShieldCheck className="w-4 h-4 shrink-0 text-[#25D366]" />
                <span>Verified Inquiries</span>
              </div>
              <span className="px-1.5 py-0.5 rounded-md text-[10px] font-bold bg-[#25D366]/20 text-[#25D366]">
                {inquiryMetrics.verified}
              </span>
            </button>

            <button
              onClick={() => {
                setActiveTab('pages');
                setMobileSidebarOpen(false);
              }}
              className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl transition-colors cursor-pointer text-left ${
                activeTab === 'pages'
                  ? 'bg-[#C58A3D] text-[#1A1009] font-semibold'
                  : 'text-white/70 hover:text-white hover:bg-white/5'
              }`}
            >
              <FileText className="w-4 h-4 shrink-0" />
              <span>Pages</span>
            </button>

            <button
              onClick={() => {
                setActiveTab('work');
                setMobileSidebarOpen(false);
              }}
              className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl transition-colors cursor-pointer text-left ${
                activeTab === 'work'
                  ? 'bg-[#C58A3D] text-[#1A1009] font-semibold'
                  : 'text-white/70 hover:text-white hover:bg-white/5'
              }`}
            >
              <Briefcase className="w-4 h-4 shrink-0" />
              <span>Work / Portfolio</span>
            </button>

            <button
              onClick={() => {
                setActiveTab('services');
                setMobileSidebarOpen(false);
              }}
              className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl transition-colors cursor-pointer text-left ${
                activeTab === 'services'
                  ? 'bg-[#C58A3D] text-[#1A1009] font-semibold'
                  : 'text-white/70 hover:text-white hover:bg-white/5'
              }`}
            >
              <Layers className="w-4 h-4 shrink-0" />
              <span>Services</span>
            </button>

            <button
              onClick={() => {
                setActiveTab('media');
                setMobileSidebarOpen(false);
              }}
              className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl transition-colors cursor-pointer text-left ${
                activeTab === 'media'
                  ? 'bg-[#C58A3D] text-[#1A1009] font-semibold'
                  : 'text-white/70 hover:text-white hover:bg-white/5'
              }`}
            >
              <ImageIcon className="w-4 h-4 shrink-0" />
              <span>Media / Assets</span>
            </button>

            <button
              onClick={() => {
                setActiveTab('comments');
                setMobileSidebarOpen(false);
              }}
              className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl transition-colors cursor-pointer text-left ${
                activeTab === 'comments'
                  ? 'bg-[#C58A3D] text-[#1A1009] font-semibold'
                  : 'text-white/70 hover:text-white hover:bg-white/5'
              }`}
            >
              <span className="flex items-center gap-3">
                <Mail className="w-4 h-4 shrink-0" />
                <span>Client Reviews</span>
              </span>
              <span className="text-[10px] px-1.5 py-0.5 rounded-md bg-white/10 font-mono">
                {comments.length}
              </span>
            </button>

            <button
              onClick={() => {
                setActiveTab('settings');
                setMobileSidebarOpen(false);
              }}
              className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl transition-colors cursor-pointer text-left ${
                activeTab === 'settings'
                  ? 'bg-[#C58A3D] text-[#1A1009] font-semibold'
                  : 'text-white/70 hover:text-white hover:bg-white/5'
              }`}
            >
              <span className="flex items-center gap-3">
                <Settings className="w-4 h-4 shrink-0" />
                <span>Site Settings</span>
              </span>
              <span className="text-[10px] px-1.5 py-0.5 rounded-md bg-white/10 font-mono">
                {inquiries.length}
              </span>
            </button>

            <button
              onClick={() => {
                setActiveTab('audit');
                fetchAuditLogs();
                setMobileSidebarOpen(false);
              }}
              className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl transition-colors cursor-pointer text-left ${
                activeTab === 'audit'
                  ? 'bg-[#C58A3D] text-[#1A1009] font-semibold'
                  : 'text-white/70 hover:text-white hover:bg-white/5'
              }`}
            >
              <span className="flex items-center gap-3">
                <ShieldAlert className="w-4 h-4 shrink-0 text-amber-400" />
                <span>Security &amp; Audit</span>
              </span>
              <span className="text-[10px] px-1.5 py-0.5 rounded-md bg-amber-400/20 text-amber-300 font-mono">
                {auditLogs.length}
              </span>
            </button>
          </nav>
        </div>

        {/* Sidebar Footer */}
        <div className="pt-6 border-t border-white/10 space-y-2">
          <button
            onClick={() => navigate('/')}
            className="w-full flex items-center justify-between px-3 py-2 rounded-xl text-xs text-white/70 hover:text-white hover:bg-white/5 transition-colors cursor-pointer"
          >
            <span className="flex items-center gap-2">
              <ExternalLink className="w-3.5 h-3.5 text-[#C58A3D]" />
              <span>View Public Site</span>
            </span>
            <span className="text-[10px] text-white/40">/</span>
          </button>

          <button
            onClick={handleLogout}
            className="w-full flex items-center gap-2 px-3 py-2 rounded-xl text-xs text-rose-300 hover:text-rose-200 hover:bg-rose-950/40 transition-colors cursor-pointer"
          >
            <LogOut className="w-3.5 h-3.5" />
            <span>Sign Out Admin</span>
          </button>
        </div>
      </aside>

      {/* MAIN ADMIN CONTENT AREA */}
      <main className="flex-1 p-6 sm:p-8 lg:p-10 overflow-y-auto">
        {/* Top bar */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-6 mb-8 border-b border-[#EAD8C7] gap-4">
          <div>
            <div className="text-[11px] font-semibold uppercase tracking-wider text-[#C58A3D]">
              Tahanabi Agency Management Console &middot; Express API Linked
            </div>
            <h1 className="font-serif text-2xl sm:text-3xl font-semibold text-[#29180F]">
              {activeTab === 'dashboard' && 'Admin Dashboard'}
              {activeTab === 'inquiries' && 'Verified Inquiries'}
              {activeTab === 'pages' && 'Manage Pages'}
              {activeTab === 'work' && 'Manage Work / Portfolio'}
              {activeTab === 'services' && 'Manage Services'}
              {activeTab === 'content' && 'Update Content'}
              {activeTab === 'media' && 'Media & Assets'}
              {activeTab === 'comments' && 'Client Reviews & Public Commentary'}
              {activeTab === 'settings' && 'Site Settings & System Health'}
              {activeTab === 'audit' && 'Security Hardening & Continuous Audit Trail'}
            </h1>
          </div>

          <div className="flex flex-wrap items-center gap-2.5">
            {currentUser && (
              <div className="flex items-center gap-2 px-3 py-1.5 rounded-full bg-[#1A1009] text-[#FFF8F0] border border-[#29180F] text-xs">
                <UserCheck className="w-3.5 h-3.5 text-[#C58A3D]" />
                <span className="font-medium text-[#FFF8F0]">{currentUser.name.split(' ')[0]}</span>
                <span className="text-[10px] font-bold px-1.5 py-0.5 rounded-md bg-[#C58A3D] text-[#1A1009] uppercase tracking-wider">
                  {currentUser.role}
                </span>
              </div>
            )}

            <button
              onClick={fetchBackendData}
              disabled={isSyncing}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-[#EAD8C7] text-xs font-medium text-[#29180F] hover:bg-[#F4E7DA] transition-colors cursor-pointer"
              title="Refresh Inquiries & Comments from Server"
            >
              <RefreshCw className={`w-3.5 h-3.5 text-[#C58A3D] ${isSyncing ? 'animate-spin' : ''}`} />
              <span>{isSyncing ? 'Syncing...' : 'Sync Live'}</span>
            </button>

            <span className="px-3 py-1 rounded-full bg-[#25D366]/15 text-[#25D366] text-xs font-medium border border-[#25D366]/30 flex items-center gap-1.5">
              <span className="w-1.5 h-1.5 rounded-full bg-[#25D366] animate-pulse" />
              <span>Server Live (Port 3000)</span>
            </span>
            <button
              onClick={() => navigate('/')}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#29180F] text-[#FFF8F0] text-xs font-medium hover:bg-[#1F120B] transition-colors cursor-pointer"
            >
              <span>View Site</span>
              <ExternalLink className="w-3 h-3 text-[#C58A3D]" />
            </button>
          </div>
        </div>

        {/* TAB 1: MAIN DASHBOARD — DISPLAY SIX MANAGEMENT CARDS */}
        {activeTab === 'dashboard' && (
          <div className="space-y-8">
            {/* The Six Management Cards */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {/* Card 1: Manage Pages */}
              <div
                onClick={() => setActiveTab('pages')}
                className="group bg-[#FFFDF9] rounded-2xl p-6 border border-[#EAD8C7] hover:border-[#C58A3D] transition-all duration-300 hover:shadow-lg cursor-pointer flex flex-col justify-between"
              >
                <div>
                  <div className="w-12 h-12 rounded-xl bg-[#F4E7DA] text-[#C58A3D] flex items-center justify-center mb-4 group-hover:bg-[#C58A3D] group-hover:text-white transition-colors">
                    <FileText className="w-6 h-6" />
                  </div>
                  <h3 className="font-serif text-lg font-semibold text-[#29180F] group-hover:text-[#C58A3D] transition-colors">
                    1. Manage Pages
                  </h3>
                  <p className="mt-1.5 text-xs text-[#29180F]/70">
                    Control the strictly defined 7 core agency routes and verify SEO status.
                  </p>
                </div>
                <div className="mt-4 pt-3 border-t border-[#EAD8C7]/60 text-xs font-medium text-[#C58A3D] flex items-center justify-between">
                  <span>7 Pages Active</span>
                  <span>Configure &rarr;</span>
                </div>
              </div>

              {/* Card 2: Manage Work */}
              <div
                onClick={() => setActiveTab('work')}
                className="group bg-[#FFFDF9] rounded-2xl p-6 border border-[#EAD8C7] hover:border-[#C58A3D] transition-all duration-300 hover:shadow-lg cursor-pointer flex flex-col justify-between"
              >
                <div>
                  <div className="w-12 h-12 rounded-xl bg-[#F4E7DA] text-[#C58A3D] flex items-center justify-center mb-4 group-hover:bg-[#C58A3D] group-hover:text-white transition-colors">
                    <Briefcase className="w-6 h-6" />
                  </div>
                  <h3 className="font-serif text-lg font-semibold text-[#29180F] group-hover:text-[#C58A3D] transition-colors">
                    2. Manage Work
                  </h3>
                  <p className="mt-1.5 text-xs text-[#29180F]/70">
                    Configure the 6 industry cards and their direct Contact routing parameters.
                  </p>
                </div>
                <div className="mt-4 pt-3 border-t border-[#EAD8C7]/60 text-xs font-medium text-[#C58A3D] flex items-center justify-between">
                  <span>6 Industry Items</span>
                  <span>Configure &rarr;</span>
                </div>
              </div>

              {/* Card 3: Manage Services */}
              <div
                onClick={() => setActiveTab('services')}
                className="group bg-[#FFFDF9] rounded-2xl p-6 border border-[#EAD8C7] hover:border-[#C58A3D] transition-all duration-300 hover:shadow-lg cursor-pointer flex flex-col justify-between"
              >
                <div>
                  <div className="w-12 h-12 rounded-xl bg-[#F4E7DA] text-[#C58A3D] flex items-center justify-center mb-4 group-hover:bg-[#C58A3D] group-hover:text-white transition-colors">
                    <Layers className="w-6 h-6" />
                  </div>
                  <h3 className="font-serif text-lg font-semibold text-[#29180F] group-hover:text-[#C58A3D] transition-colors">
                    3. Manage Services
                  </h3>
                  <p className="mt-1.5 text-xs text-[#29180F]/70">
                    Update the 6 core capabilities, icon assignments, and AI concierge links.
                  </p>
                </div>
                <div className="mt-4 pt-3 border-t border-[#EAD8C7]/60 text-xs font-medium text-[#C58A3D] flex items-center justify-between">
                  <span>6 Services Active</span>
                  <span>Configure &rarr;</span>
                </div>
              </div>

              {/* Card 4: Update Content */}
              <div
                onClick={() => setActiveTab('content')}
                className="group bg-[#FFFDF9] rounded-2xl p-6 border border-[#EAD8C7] hover:border-[#C58A3D] transition-all duration-300 hover:shadow-lg cursor-pointer flex flex-col justify-between"
              >
                <div>
                  <div className="w-12 h-12 rounded-xl bg-[#F4E7DA] text-[#C58A3D] flex items-center justify-center mb-4 group-hover:bg-[#C58A3D] group-hover:text-white transition-colors">
                    <Save className="w-6 h-6" />
                  </div>
                  <h3 className="font-serif text-lg font-semibold text-[#29180F] group-hover:text-[#C58A3D] transition-colors">
                    4. Update Content
                  </h3>
                  <p className="mt-1.5 text-xs text-[#29180F]/70">
                    Modify headline text, agency value propositions, and official contact phone/email.
                  </p>
                </div>
                <div className="mt-4 pt-3 border-t border-[#EAD8C7]/60 text-xs font-medium text-[#C58A3D] flex items-center justify-between">
                  <span>Live Copy Editor</span>
                  <span>Edit &rarr;</span>
                </div>
              </div>

              {/* Card 5: Media & Assets */}
              <div
                onClick={() => setActiveTab('media')}
                className="group bg-[#FFFDF9] rounded-2xl p-6 border border-[#EAD8C7] hover:border-[#C58A3D] transition-all duration-300 hover:shadow-lg cursor-pointer flex flex-col justify-between"
              >
                <div>
                  <div className="w-12 h-12 rounded-xl bg-[#F4E7DA] text-[#C58A3D] flex items-center justify-center mb-4 group-hover:bg-[#C58A3D] group-hover:text-white transition-colors">
                    <ImageIcon className="w-6 h-6" />
                  </div>
                  <h3 className="font-serif text-lg font-semibold text-[#29180F] group-hover:text-[#C58A3D] transition-colors">
                    5. Media &amp; Assets
                  </h3>
                  <p className="mt-1.5 text-xs text-[#29180F]/70">
                    Inspect generated device mockups, studio photography, and AI robot assets.
                  </p>
                </div>
                <div className="mt-4 pt-3 border-t border-[#EAD8C7]/60 text-xs font-medium text-[#C58A3D] flex items-center justify-between">
                  <span>8 High-Res Assets</span>
                  <span>View &rarr;</span>
                </div>
              </div>

              {/* Card 6: Site Settings */}
              <div
                onClick={() => setActiveTab('inquiries')}
                className="group bg-[#FFFDF9] rounded-2xl p-6 border border-[#EAD8C7] hover:border-[#C58A3D] transition-all duration-300 hover:shadow-lg cursor-pointer flex flex-col justify-between"
              >
                <div>
                  <div className="w-12 h-12 rounded-xl bg-[#25D366]/15 text-[#25D366] flex items-center justify-center mb-4 group-hover:bg-[#25D366] group-hover:text-white transition-colors">
                    <ShieldCheck className="w-6 h-6" />
                  </div>
                  <h3 className="font-serif text-lg font-semibold text-[#29180F] group-hover:text-[#C58A3D] transition-colors">
                    6. Verified Inquiries
                  </h3>
                  <p className="mt-1.5 text-xs text-[#29180F]/70">
                    Review and mark inquiries as Verified or Replied with central state synchronization.
                  </p>
                </div>
                <div className="mt-4 pt-3 border-t border-[#EAD8C7]/60 text-xs font-medium text-[#C58A3D] flex items-center justify-between">
                  <span>{inquiryMetrics.total} Total ({inquiryMetrics.verified} Verified)</span>
                  <span>Manage Inquiries &rarr;</span>
                </div>
              </div>
            </div>

            {/* Render Verified Inquiries Dashboard */}
            {renderInquiriesDashboard(false)}
          </div>
        )}

        {/* TAB: DEDICATED VERIFIED INQUIRIES VIEW */}
        {activeTab === 'inquiries' && (
          <div className="space-y-6">
            {renderInquiriesDashboard(true)}
          </div>
        )}

        {/* TAB 2: MANAGE PAGES */}
        {activeTab === 'pages' && (
          <div className="bg-[#FFFDF9] rounded-2xl p-6 border border-[#EAD8C7] shadow-xs space-y-4">
            <div>
              <h3 className="font-serif text-lg font-semibold text-[#29180F]">
                Strict 7 Core Pages Architecture
              </h3>
              <p className="text-xs text-[#29180F]/70">
                All public navigation and operations remain strictly within these seven defined pages.
              </p>
            </div>

            <div className="divide-y divide-[#EAD8C7]/50">
              {[
                { name: 'Home', path: '/', status: 'Published', desc: 'Hero, Services Strip, Our Work, About Preview, Footer' },
                { name: 'Work / Portfolio', path: '/work', status: 'Published', desc: '6 industry cards with direct /contact interest routing' },
                { name: 'Services', path: '/services', status: 'Published', desc: '6 core services with AI concierge redirect' },
                { name: 'AI Automation', path: '/ai-automation', status: 'Published', desc: 'Robot visual and 5 intelligent automation solutions' },
                { name: 'About', path: '/about', status: 'Published', desc: 'Agency office visual and 4 compact feature cards' },
                { name: 'Contact', path: '/contact', status: 'Published', desc: 'WhatsApp, Phone dialer, Email, and dynamic topic prefill' },
                { name: 'Admin Panel', path: '/admin', status: 'Secured', desc: 'Private management console with 6 dashboard tools' },
              ].map((p, idx) => (
                <div key={p.path} className="py-3 flex items-center justify-between">
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="font-mono text-xs font-semibold text-[#C58A3D]">0{idx + 1}.</span>
                      <span className="text-sm font-semibold text-[#29180F]">{p.name}</span>
                      <span className="font-mono text-xs text-[#29180F]/50">({p.path})</span>
                    </div>
                    <p className="text-xs text-[#29180F]/60 mt-0.5">{p.desc}</p>
                  </div>
                  <div className="flex items-center gap-3">
                    <span className="px-2 py-0.5 rounded-full bg-[#25D366]/15 text-[#25D366] text-[10px] font-semibold">
                      {p.status}
                    </span>
                    <button
                      onClick={() => navigate(p.path)}
                      className="p-1.5 rounded-lg border border-[#EAD8C7] hover:bg-[#F4E7DA] text-xs text-[#29180F] cursor-pointer"
                      title="Open Page"
                    >
                      <ExternalLink className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* TAB 3: MANAGE WORK */}
        {activeTab === 'work' && (
          <div className="bg-[#FFFDF9] rounded-2xl p-6 border border-[#EAD8C7] shadow-xs space-y-6">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="font-serif text-lg font-semibold text-[#29180F]">
                  Industry Work Portfolio
                </h3>
                <p className="text-xs text-[#29180F]/70">
                  Every card is configured to navigate directly to /contact?interest=slug.
                </p>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {works.map((w) => (
                <div key={w.id} className="p-4 rounded-xl border border-[#EAD8C7] bg-[#FFF8F0]/40 flex flex-col justify-between">
                  <div>
                    <div className="relative aspect-video rounded-lg overflow-hidden mb-2 bg-[#F4E7DA]">
                      <img src={w.image} alt={w.title} className="w-full h-full object-cover" />
                    </div>
                    <h4 className="font-serif font-semibold text-sm text-[#29180F]">{w.title}</h4>
                    <p className="text-xs text-[#29180F]/70 mt-1 line-clamp-2">{w.subtitle}</p>
                  </div>
                  <div className="mt-3 pt-2 border-t border-[#EAD8C7]/60 flex items-center justify-between text-[11px]">
                    <span className="font-mono text-[#C58A3D]">?interest={w.slug}</span>
                    <button
                      onClick={() => navigate(`/contact?interest=${w.slug}`)}
                      className="text-[#29180F] hover:underline"
                    >
                      Test Routing &rarr;
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* TAB 4: MANAGE SERVICES */}
        {activeTab === 'services' && (
          <div className="bg-[#FFFDF9] rounded-2xl p-6 border border-[#EAD8C7] shadow-xs space-y-4">
            <div>
              <h3 className="font-serif text-lg font-semibold text-[#29180F]">
                Services Configuration
              </h3>
              <p className="text-xs text-[#29180F]/70">
                Core services offered to international clients.
              </p>
            </div>

            <div className="divide-y divide-[#EAD8C7]/50">
              {services.map((s) => (
                <div key={s.id} className="py-3 flex items-center justify-between">
                  <div>
                    <div className="font-serif text-sm font-semibold text-[#29180F]">{s.title}</div>
                    <p className="text-xs text-[#29180F]/70 mt-0.5">{s.description}</p>
                  </div>
                  <div className="text-right text-xs">
                    <span className="px-2 py-0.5 rounded-full bg-[#F4E7DA] text-[#C58A3D] font-medium text-[10px]">
                      {s.isAiConcierge ? 'Opens /ai-automation' : `Opens /contact?service=${s.slug}`}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* TAB 5: UPDATE CONTENT */}
        {activeTab === 'content' && (
          <form onSubmit={handleSaveConfig} className="bg-[#FFFDF9] rounded-2xl p-6 border border-[#EAD8C7] shadow-xs space-y-4 max-w-2xl">
            <div>
              <h3 className="font-serif text-lg font-semibold text-[#29180F]">
                Update Agency Content &amp; Contact Details
              </h3>
              <p className="text-xs text-[#29180F]/70">
                Changes will reflect live on the website and direct communication links.
              </p>
            </div>

            {saveSuccess && (
              <div className="p-3 rounded-xl bg-emerald-50 border border-emerald-200 text-xs text-emerald-800 flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                <span>Agency configuration updated and stored successfully!</span>
              </div>
            )}

            <div>
              <label className="block text-xs font-semibold text-[#29180F] mb-1">
                Main Hero Headline
              </label>
              <input
                type="text"
                value={agencyConfig.headline}
                onChange={(e) => setAgencyConfig({ ...agencyConfig, headline: e.target.value })}
                className="w-full text-xs px-3 py-2 rounded-lg bg-[#FFF8F0] border border-[#EAD8C7] focus:border-[#C58A3D] focus:outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-[#29180F] mb-1">
                Hero Tagline / Description
              </label>
              <textarea
                rows={2}
                value={agencyConfig.tagline}
                onChange={(e) => setAgencyConfig({ ...agencyConfig, tagline: e.target.value })}
                className="w-full text-xs px-3 py-2 rounded-lg bg-[#FFF8F0] border border-[#EAD8C7] focus:border-[#C58A3D] focus:outline-none"
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-semibold text-[#29180F] mb-1">
                  Official Phone / Call Link
                </label>
                <input
                  type="text"
                  value={agencyConfig.phone}
                  onChange={(e) => setAgencyConfig({ ...agencyConfig, phone: e.target.value })}
                  className="w-full text-xs px-3 py-2 rounded-lg bg-[#FFF8F0] border border-[#EAD8C7] focus:border-[#C58A3D] focus:outline-none font-mono"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-[#29180F] mb-1">
                  Official Email
                </label>
                <input
                  type="email"
                  value={agencyConfig.email}
                  onChange={(e) => setAgencyConfig({ ...agencyConfig, email: e.target.value })}
                  className="w-full text-xs px-3 py-2 rounded-lg bg-[#FFF8F0] border border-[#EAD8C7] focus:border-[#C58A3D] focus:outline-none"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-[#29180F] mb-1">
                About Statement
              </label>
              <textarea
                rows={3}
                value={agencyConfig.aboutText}
                onChange={(e) => setAgencyConfig({ ...agencyConfig, aboutText: e.target.value })}
                className="w-full text-xs px-3 py-2 rounded-lg bg-[#FFF8F0] border border-[#EAD8C7] focus:border-[#C58A3D] focus:outline-none"
              />
            </div>

            <button
              type="submit"
              className="px-5 py-2.5 rounded-xl bg-[#29180F] text-[#FFF8F0] hover:bg-[#1F120B] text-xs font-semibold flex items-center gap-2 transition-colors cursor-pointer"
            >
              <Save className="w-4 h-4 text-[#C58A3D]" />
              <span>Save Changes</span>
            </button>
          </form>
        )}

        {/* TAB 6: MEDIA & ASSETS */}
        {activeTab === 'media' && (
          <div className="bg-[#FFFDF9] rounded-2xl p-6 border border-[#EAD8C7] shadow-xs space-y-4">
            <div>
              <h3 className="font-serif text-lg font-semibold text-[#29180F]">
                Generated High-Fidelity Studio Assets
              </h3>
              <p className="text-xs text-[#29180F]/70">
                All imagery rendered with warm ivory, soft beige, and rich chocolate tones.
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              {[
                { title: 'Hero Laptop Mockup', path: '/src/assets/images/hero_device_mockup_1794281440967.jpg', aspect: '16:9' },
                { title: 'Agency Studio Office', path: '/src/assets/images/office_agency_aesthetic_1794281442498.jpg', aspect: '16:9' },
                { title: 'Jewellery E-commerce', path: '/src/assets/images/industry_jewellery_1794281441984.jpg', aspect: '4:3' },
                { title: 'Car Service & Fleet', path: '/src/assets/images/industry_car_fleet_1794281443328.jpg', aspect: '4:3' },
                { title: 'Retail & Fashion', path: '/src/assets/images/industry_retail_fashion_1794281443639.jpg', aspect: '4:3' },
                { title: 'Real Estate & Property', path: '/src/assets/images/industry_real_estate_1794281465970.jpg', aspect: '4:3' },
                { title: 'Healthcare & Wellness', path: '/src/assets/images/industry_healthcare_1794281466136.jpg', aspect: '4:3' },
                { title: 'AI Concierge Robot', path: '/src/assets/images/ai_concierge_robot_1794281443822.jpg', aspect: '4:3' },
              ].map((img) => (
                <div key={img.path} className="rounded-xl border border-[#EAD8C7] overflow-hidden bg-[#FFF8F0]">
                  <div className="aspect-video bg-[#F4E7DA] overflow-hidden">
                    <img src={img.path} alt={img.title} className="w-full h-full object-cover" />
                  </div>
                  <div className="p-3 text-xs">
                    <div className="font-semibold text-[#29180F]">{img.title}</div>
                    <div className="text-[10px] text-[#29180F]/60 font-mono mt-0.5">Ratio: {img.aspect}</div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* TAB: CLIENT REVIEWS & PUBLIC COMMENTARY */}
        {activeTab === 'comments' && (
          <div className="bg-[#FFFDF9] rounded-2xl p-6 border border-[#EAD8C7] shadow-xs space-y-6">
            <div className="flex items-center justify-between pb-4 border-b border-[#EAD8C7]">
              <div>
                <h3 className="font-serif text-lg font-semibold text-[#29180F]">
                  Client Reviews &amp; Public Commentary
                </h3>
                <p className="text-xs text-[#29180F]/70">
                  Manage live reviews submitted by clients from the public website.
                </p>
              </div>
              <span className="text-xs font-semibold text-[#C58A3D] font-mono">
                {comments.length} Live Reviews
              </span>
            </div>

            {comments.length === 0 ? (
              <div className="py-12 text-center text-xs text-[#29180F]/60">
                No client comments recorded yet.
              </div>
            ) : (
              <div className="space-y-4">
                {comments.map((comment) => (
                  <div
                    key={comment.id}
                    className="p-4 rounded-xl border border-[#EAD8C7] bg-[#FFF8F0]/60 flex flex-col sm:flex-row sm:items-center justify-between gap-4"
                  >
                    <div className="space-y-1">
                      <div className="flex items-center gap-2">
                        <span className="font-serif text-sm font-semibold text-[#29180F]">
                          {comment.name}
                        </span>
                        <span className="text-xs text-[#29180F]/60">&middot; {comment.role}</span>
                        <span className="text-[10px] px-2 py-0.5 rounded-full bg-[#F4E7DA] text-[#C58A3D] font-medium">
                          {comment.serviceUsed}
                        </span>
                      </div>
                      <p className="text-xs text-[#29180F]/80 leading-relaxed italic">
                        &ldquo;{comment.content}&rdquo;
                      </p>
                      <div className="flex items-center gap-2 text-[10px] text-[#29180F]/50 font-mono">
                        <span>Rating: {comment.rating}/5 Stars</span>
                        <span>&middot;</span>
                        <span>{comment.timestamp}</span>
                      </div>
                    </div>

                    <button
                      onClick={() => deleteComment(comment.id)}
                      className="p-2 rounded-lg text-[#29180F]/50 hover:text-rose-600 hover:bg-rose-50 transition-colors shrink-0 cursor-pointer self-start sm:self-center"
                      title="Moderate and remove comment"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* TAB 7: SETTINGS & INQUIRIES */}
        {activeTab === 'settings' && (
          <div className="bg-[#FFFDF9] rounded-2xl p-6 border border-[#EAD8C7] shadow-xs space-y-6">
            <div>
              <h3 className="font-serif text-lg font-semibold text-[#29180F]">
                Site Settings &amp; Technical Health
              </h3>
              <p className="text-xs text-[#29180F]/70">
                Production parameters and active communication conduits.
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
              <div className="p-4 rounded-xl border border-[#EAD8C7] bg-[#FFF8F0]/50 space-y-2">
                <span className="font-semibold text-[#29180F] block">WhatsApp API Status</span>
                <p className="text-[#29180F]/70">Target Endpoint: https://wa.me/919128596443</p>
                <span className="inline-block px-2 py-0.5 rounded-full bg-[#25D366]/20 text-[#25D366] text-[10px] font-semibold">
                  Verified Active
                </span>
              </div>

              <div className="p-4 rounded-xl border border-[#EAD8C7] bg-[#FFF8F0]/50 space-y-2">
                <span className="font-semibold text-[#29180F] block">Direct Telephony Conduit</span>
                <p className="text-[#29180F]/70">Target Protocol: tel:+919128596443</p>
                <span className="inline-block px-2 py-0.5 rounded-full bg-[#25D366]/20 text-[#25D366] text-[10px] font-semibold">
                  Verified Active
                </span>
              </div>
            </div>

            {/* Real-World Production Security Management */}
            <div className="p-5 rounded-xl border border-[#EAD8C7] bg-[#FFF8F0] space-y-4">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-[#EAD8C7]/70">
                <div>
                  <div className="flex items-center gap-2">
                    <KeyRound className="w-4 h-4 text-[#C58A3D]" />
                    <h4 className="font-serif text-sm font-semibold text-[#29180F]">
                      Administrator Password &amp; Multi-Factor Vault
                    </h4>
                  </div>
                  <p className="text-[11px] text-[#29180F]/70 mt-0.5">
                    Harden your real-world deployment. Update your salted password and pair your Google Authenticator or Authy app.
                  </p>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => {
                      setShowPasswordModal(true);
                      setPasswordChangeError('');
                      setPasswordChangeSuccess('');
                    }}
                    className="px-3 py-1.5 rounded-lg bg-[#29180F] text-[#FFF8F0] hover:bg-[#1F120B] text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer"
                  >
                    <Key className="w-3.5 h-3.5 text-[#C58A3D]" />
                    <span>Change Password</span>
                  </button>

                  <button
                    type="button"
                    onClick={startTwoFactorSetup}
                    className="px-3 py-1.5 rounded-lg border border-[#EAD8C7] bg-white text-[#29180F] hover:bg-[#F4E7DA] text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer"
                  >
                    <Smartphone className="w-3.5 h-3.5 text-blue-600" />
                    <span>{currentUser?.twoFactorEnabled ? 'Manage 2FA' : 'Enable 2FA (RFC 6238)'}</span>
                  </button>
                </div>
              </div>

              {/* Status Row */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
                <div className="bg-white p-3 rounded-lg border border-[#EAD8C7]">
                  <span className="text-[10px] text-[#29180F]/60 uppercase font-semibold">Active Account</span>
                  <div className="font-semibold text-[#29180F] mt-0.5">{currentUser?.username || 'admin'}</div>
                  <span className="text-[10px] text-[#C58A3D] font-mono">Role: {currentUser?.role}</span>
                </div>

                <div className="bg-white p-3 rounded-lg border border-[#EAD8C7]">
                  <span className="text-[10px] text-[#29180F]/60 uppercase font-semibold">Encryption Standard</span>
                  <div className="font-semibold text-[#29180F] mt-0.5">PBKDF2-HMAC-SHA256</div>
                  <span className="text-[10px] text-emerald-700 font-mono">100k rounds + unique 32B salt</span>
                </div>

                <div className="bg-white p-3 rounded-lg border border-[#EAD8C7]">
                  <span className="text-[10px] text-[#29180F]/60 uppercase font-semibold">Two-Factor Status</span>
                  <div className="mt-0.5">
                    {currentUser?.twoFactorEnabled ? (
                      <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-800 border border-emerald-200">
                        <ShieldCheck className="w-3 h-3 text-emerald-600" />
                        <span>Active (Authenticator)</span>
                      </span>
                    ) : (
                      <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-100 text-amber-900 border border-amber-200">
                        <AlertTriangle className="w-3 h-3 text-amber-600" />
                        <span>Not Enabled (Recommended)</span>
                      </span>
                    )}
                  </div>
                  <span className="text-[10px] text-[#29180F]/60">Google Authenticator / Authy</span>
                </div>
              </div>
            </div>

            {/* Administrator Team & Account Vault (Add New Users & Passwords) */}
            <div className="p-5 rounded-xl border border-[#EAD8C7] bg-[#FFF8F0] space-y-4">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-[#EAD8C7]/70">
                <div>
                  <div className="flex items-center gap-2">
                    <Users className="w-4 h-4 text-[#C58A3D]" />
                    <h4 className="font-serif text-sm font-semibold text-[#29180F]">
                      Administrator Team &amp; Accounts Management (RBAC)
                    </h4>
                  </div>
                  <p className="text-[11px] text-[#29180F]/70 mt-0.5">
                    Create custom administrator usernames, assign granular role permissions, and control team access.
                  </p>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => {
                      setShowAddUserModal(true);
                      setAddUserError('');
                      setAddUserSuccess('');
                    }}
                    className="px-3 py-1.5 rounded-lg bg-[#29180F] text-[#FFF8F0] hover:bg-[#1F120B] text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer"
                  >
                    <UserPlus className="w-3.5 h-3.5 text-[#C58A3D]" />
                    <span>+ Add New Administrator</span>
                  </button>

                  <button
                    type="button"
                    onClick={fetchAdminUsers}
                    disabled={isLoadingUsers}
                    className="px-2.5 py-1.5 rounded-lg border border-[#EAD8C7] bg-white text-[#29180F] hover:bg-[#F4E7DA] text-xs transition-colors cursor-pointer"
                    title="Refresh administrators list"
                  >
                    <RefreshCw className={`w-3.5 h-3.5 text-[#C58A3D] ${isLoadingUsers ? 'animate-spin' : ''}`} />
                  </button>
                </div>
              </div>

              {/* Administrators Table */}
              <div className="overflow-x-auto rounded-xl border border-[#EAD8C7]/80 bg-white">
                <table className="w-full text-left text-xs">
                  <thead>
                    <tr className="bg-[#F4E7DA]/60 border-b border-[#EAD8C7] text-[#29180F]/80">
                      <th className="py-2.5 px-3 font-semibold">Username</th>
                      <th className="py-2.5 px-3 font-semibold">Full Name</th>
                      <th className="py-2.5 px-3 font-semibold">Assigned Role</th>
                      <th className="py-2.5 px-3 font-semibold">2FA Protection</th>
                      <th className="py-2.5 px-3 font-semibold">Last Modified</th>
                      <th className="py-2.5 px-3 font-semibold text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-[#EAD8C7]/50">
                    {adminUsers.map((user) => {
                      const isSelf = user.id === currentUser?.id || user.username === currentUser?.username;
                      const isRoot = user.username === 'superadmin';

                      return (
                        <tr key={user.id} className="hover:bg-[#F4E7DA]/30 transition-colors">
                          <td className="py-2.5 px-3 whitespace-nowrap font-mono font-semibold text-[#29180F]">
                            {user.username}
                          </td>
                          <td className="py-2.5 px-3 whitespace-nowrap text-[#29180F]/80">
                            {user.name}
                          </td>
                          <td className="py-2.5 px-3 whitespace-nowrap">
                            <span className={`inline-block px-2 py-0.5 rounded-full text-[10px] font-bold ${
                              user.role === 'SUPER_ADMIN'
                                ? 'bg-[#29180F] text-[#FFF8F0]'
                                : user.role === 'ADMIN'
                                ? 'bg-[#C58A3D]/20 text-[#29180F] border border-[#C58A3D]/40'
                                : user.role === 'MANAGER'
                                ? 'bg-blue-100 text-blue-900 border border-blue-200'
                                : 'bg-stone-100 text-stone-800 border border-stone-200'
                            }`}>
                              {user.role}
                            </span>
                          </td>
                          <td className="py-2.5 px-3 whitespace-nowrap">
                            {user.twoFactorEnabled ? (
                              <span className="inline-flex items-center gap-1 text-[10px] font-semibold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-full border border-emerald-200">
                                <ShieldCheck className="w-3 h-3 text-emerald-600" />
                                <span>2FA Enabled</span>
                              </span>
                            ) : (
                              <span className="text-[10px] text-[#29180F]/50">
                                Password only
                              </span>
                            )}
                          </td>
                          <td className="py-2.5 px-3 whitespace-nowrap text-[11px] font-mono text-[#29180F]/60">
                            {user.updatedAt ? user.updatedAt.substring(0, 10) : 'Active'}
                          </td>
                          <td className="py-2.5 px-3 whitespace-nowrap text-right">
                            {isRoot ? (
                              <span className="text-[10px] text-[#29180F]/40 italic font-mono">
                                [Root Protected]
                              </span>
                            ) : isSelf ? (
                              <span className="text-[10px] text-[#C58A3D] font-mono font-medium">
                                (Active Session)
                              </span>
                            ) : currentUser?.role === 'SUPER_ADMIN' ? (
                              <button
                                type="button"
                                onClick={() => handleDeleteUser(user.id, user.username)}
                                className="p-1 rounded-md text-rose-600 hover:bg-rose-50 transition-colors cursor-pointer"
                                title="Revoke and delete administrator access"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            ) : (
                              <span className="text-[10px] text-[#29180F]/40">
                                &mdash;
                              </span>
                            )}
                          </td>
                        </tr>
                      );
                    })}
                    {adminUsers.length === 0 && (
                      <tr>
                        <td colSpan={6} className="py-6 text-center text-xs text-[#29180F]/60">
                          {isLoadingUsers ? 'Loading team accounts...' : 'No additional administrator accounts configured.'}
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>
            </div>

            <div className="pt-4 border-t border-[#EAD8C7]/60">
              <button
                onClick={() => {
                  localStorage.removeItem('tahanabi_config');
                  localStorage.removeItem('tahanabi_works');
                  localStorage.removeItem('tahanabi_services');
                  alert('Default agency presets restored.');
                  window.location.reload();
                }}
                className="px-4 py-2 rounded-lg border border-[#EAD8C7] text-xs font-medium text-[#29180F] hover:bg-[#F4E7DA] transition-colors cursor-pointer"
              >
                Reset to Default Presets
              </button>
            </div>
          </div>
        )}

        {/* TAB 8: SECURITY AUDIT TRAIL & DEFENSE CONTROLS */}
        {activeTab === 'audit' && (
          <div className="space-y-6">
            {/* Security Architecture Posture Cards */}
            <div className="bg-[#FFFDF9] rounded-2xl p-6 border border-[#EAD8C7] shadow-xs space-y-4">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-[#EAD8C7]">
                <div>
                  <div className="flex items-center gap-2">
                    <ShieldCheck className="w-5 h-5 text-[#25D366]" />
                    <h3 className="font-serif text-lg font-semibold text-[#29180F]">
                      Enterprise Defense &amp; Security Controls
                    </h3>
                  </div>
                  <p className="text-xs text-[#29180F]/70 mt-1">
                    Continuous server-side audit logging, cryptographically salted PBKDF2 authentication, and multi-tier RBAC.
                  </p>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={fetchAuditLogs}
                    disabled={isLoadingAudit}
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-[#EAD8C7] text-xs font-medium text-[#29180F] hover:bg-[#F4E7DA] transition-colors cursor-pointer"
                  >
                    <RefreshCw className={`w-3.5 h-3.5 text-[#C58A3D] ${isLoadingAudit ? 'animate-spin' : ''}`} />
                    <span>Refresh Logs</span>
                  </button>

                  {currentUser?.role === 'SUPER_ADMIN' && (
                    <button
                      onClick={handleRotateAuditLogs}
                      className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#29180F] text-[#FFF8F0] text-xs font-medium hover:bg-[#1F120B] transition-colors cursor-pointer"
                      title="Archive current log entries to disk and reset active log buffer"
                    >
                      <History className="w-3.5 h-3.5 text-[#C58A3D]" />
                      <span>Rotate &amp; Archive</span>
                    </button>
                  )}
                </div>
              </div>

              {rotateSuccess && (
                <div className="p-3 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs font-medium flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                  <span>{rotateSuccess}</span>
                </div>
              )}

              {/* 4 Defense Posture Indicator Tiles */}
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 pt-2">
                <div className="bg-[#FFF8F0] p-3.5 rounded-xl border border-[#EAD8C7]">
                  <div className="flex items-center justify-between text-[#29180F]/70 text-[11px] font-semibold">
                    <span>Password Security</span>
                    <Key className="w-3.5 h-3.5 text-[#C58A3D]" />
                  </div>
                  <div className="text-sm font-bold text-[#29180F] mt-1 font-mono">PBKDF2-HMAC-SHA256</div>
                  <div className="text-[10px] text-[#29180F]/60 mt-0.5">100,000 rounds + constant-time cmp</div>
                </div>

                <div className="bg-[#FFF8F0] p-3.5 rounded-xl border border-[#EAD8C7]">
                  <div className="flex items-center justify-between text-[#29180F]/70 text-[11px] font-semibold">
                    <span>Session Entropy</span>
                    <Lock className="w-3.5 h-3.5 text-[#25D366]" />
                  </div>
                  <div className="text-sm font-bold text-[#29180F] mt-1 font-mono">256-Bit Cryptographic</div>
                  <div className="text-[10px] text-[#29180F]/60 mt-0.5">30-min sliding idle expiration</div>
                </div>

                <div className="bg-[#FFF8F0] p-3.5 rounded-xl border border-[#EAD8C7]">
                  <div className="flex items-center justify-between text-[#29180F]/70 text-[11px] font-semibold">
                    <span>Brute-Force Guard</span>
                    <ShieldAlert className="w-3.5 h-3.5 text-amber-600" />
                  </div>
                  <div className="text-sm font-bold text-[#29180F] mt-1 font-mono">Sliding Rate Throttling</div>
                  <div className="text-[10px] text-[#29180F]/60 mt-0.5">5-attempt lockout per 15 min window</div>
                </div>

                <div className="bg-[#FFF8F0] p-3.5 rounded-xl border border-[#EAD8C7]">
                  <div className="flex items-center justify-between text-[#29180F]/70 text-[11px] font-semibold">
                    <span>RBAC Server Enforced</span>
                    <UserCheck className="w-3.5 h-3.5 text-blue-600" />
                  </div>
                  <div className="text-sm font-bold text-[#29180F] mt-1 font-mono">5 Independent Roles</div>
                  <div className="text-[10px] text-[#29180F]/60 mt-0.5">SUPER_ADMIN &rarr; READ_ONLY</div>
                </div>
              </div>
            </div>

            {/* Live Audit Log Stream */}
            <div className="bg-[#FFFDF9] rounded-2xl p-6 border border-[#EAD8C7] shadow-xs space-y-4">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div className="flex items-center gap-2">
                  <History className="w-4 h-4 text-[#C58A3D]" />
                  <h4 className="font-serif text-base font-semibold text-[#29180F]">
                    Audit Trail Records ({auditLogs.length} total events)
                  </h4>
                </div>

                {/* Filter Pills */}
                <div className="flex flex-wrap items-center gap-1.5 text-xs">
                  {(['all', 'login', 'status', 'delete', 'denied'] as const).map((filter) => (
                    <button
                      key={filter}
                      type="button"
                      onClick={() => setAuditFilter(filter)}
                      className={`px-2.5 py-1 rounded-lg capitalize transition-colors cursor-pointer ${
                        auditFilter === filter
                          ? 'bg-[#29180F] text-[#FFF8F0] font-semibold'
                          : 'bg-[#F4E7DA] text-[#29180F] hover:bg-[#EAD8C7]'
                      }`}
                    >
                      {filter}
                    </button>
                  ))}
                </div>
              </div>

              {/* Logs Table */}
              <div className="overflow-x-auto rounded-xl border border-[#EAD8C7]/80">
                <table className="w-full text-left text-xs">
                  <thead>
                    <tr className="bg-[#F4E7DA]/60 border-b border-[#EAD8C7] text-[#29180F]/80">
                      <th className="py-2.5 px-3 font-semibold">Timestamp</th>
                      <th className="py-2.5 px-3 font-semibold">Event Type</th>
                      <th className="py-2.5 px-3 font-semibold">Actor &amp; Role</th>
                      <th className="py-2.5 px-3 font-semibold">Masked IP</th>
                      <th className="py-2.5 px-3 font-semibold">Endpoint</th>
                      <th className="py-2.5 px-3 font-semibold">Details</th>
                      <th className="py-2.5 px-3 font-semibold text-right">Outcome</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-[#EAD8C7]/50 bg-[#FFFDF9]">
                    {auditLogs
                      .filter((entry) => {
                        if (auditFilter === 'login') return entry.eventType.includes('AUTH');
                        if (auditFilter === 'status') return entry.eventType.includes('STATUS');
                        if (auditFilter === 'delete') return entry.eventType.includes('DELETED');
                        if (auditFilter === 'denied') return entry.outcome === 'DENIED';
                        return true;
                      })
                      .map((entry) => (
                        <tr key={entry.id} className="hover:bg-[#F4E7DA]/30 transition-colors">
                          <td className="py-2.5 px-3 whitespace-nowrap text-[11px] text-[#29180F]/60 font-mono">
                            {entry.timestamp ? entry.timestamp.replace('T', ' ').substring(0, 19) : ''}
                          </td>
                          <td className="py-2.5 px-3 whitespace-nowrap">
                            <span className="font-mono text-[10px] font-semibold px-2 py-0.5 rounded-md bg-[#F4E7DA] text-[#29180F]">
                              {entry.eventType}
                            </span>
                          </td>
                          <td className="py-2.5 px-3 whitespace-nowrap">
                            <div className="font-medium text-[#29180F]">{entry.actor}</div>
                            <span className="text-[9px] font-bold px-1.5 py-0.2 rounded-sm bg-[#29180F]/10 text-[#C58A3D] uppercase">
                              {entry.role}
                            </span>
                          </td>
                          <td className="py-2.5 px-3 whitespace-nowrap text-[10px] font-mono text-[#29180F]/50">
                            {entry.ipHash}
                          </td>
                          <td className="py-2.5 px-3 whitespace-nowrap text-[11px] font-mono text-[#29180F]/70">
                            {entry.endpoint}
                          </td>
                          <td className="py-2.5 px-3 text-[#29180F]/80 max-w-xs truncate" title={entry.details}>
                            {entry.details}
                          </td>
                          <td className="py-2.5 px-3 whitespace-nowrap text-right">
                            {entry.outcome === 'SUCCESS' ? (
                              <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-800 border border-emerald-200">
                                SUCCESS
                              </span>
                            ) : entry.outcome === 'DENIED' ? (
                              <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-rose-100 text-rose-800 border border-rose-200">
                                DENIED
                              </span>
                            ) : (
                              <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-100 text-amber-900 border border-amber-200">
                                {entry.outcome}
                              </span>
                            )}
                          </td>
                        </tr>
                      ))}
                    {auditLogs.length === 0 && (
                      <tr>
                        <td colSpan={7} className="py-8 text-center text-xs text-[#29180F]/60">
                          No audit records found. Privileged operations and authentications will stream here in real-time.
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}
      </main>

      {/* MODAL 1: CHANGE PASSWORD */}
      {showPasswordModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
          <div className="w-full max-w-md bg-[#FFFDF9] rounded-2xl p-6 border border-[#EAD8C7] shadow-2xl space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-[#EAD8C7]">
              <div className="flex items-center gap-2">
                <KeyRound className="w-5 h-5 text-[#C58A3D]" />
                <h3 className="font-serif text-base font-semibold text-[#29180F]">
                  Update Master Password
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setShowPasswordModal(false)}
                className="p-1 rounded-lg text-[#29180F]/50 hover:text-[#29180F] hover:bg-[#F4E7DA]"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleChangePassword} className="space-y-3.5 text-xs">
              <div>
                <label className="block font-semibold text-[#29180F] mb-1">Current Password</label>
                <input
                  type="password"
                  required
                  value={oldPasswordInput}
                  onChange={(e) => setOldPasswordInput(e.target.value)}
                  placeholder="Enter current password..."
                  className="w-full px-3 py-2 rounded-lg bg-[#FFF8F0] border border-[#EAD8C7] focus:outline-none focus:border-[#C58A3D]"
                />
              </div>

              <div>
                <label className="block font-semibold text-[#29180F] mb-1">New Strong Password</label>
                <input
                  type="password"
                  required
                  value={newPasswordInput}
                  onChange={(e) => setNewPasswordInput(e.target.value)}
                  placeholder="Minimum 10 chars, uppercase, lowercase, number, symbol..."
                  className="w-full px-3 py-2 rounded-lg bg-[#FFF8F0] border border-[#EAD8C7] focus:outline-none focus:border-[#C58A3D]"
                />
              </div>

              <div>
                <label className="block font-semibold text-[#29180F] mb-1">Confirm New Password</label>
                <input
                  type="password"
                  required
                  value={confirmPasswordInput}
                  onChange={(e) => setConfirmPasswordInput(e.target.value)}
                  placeholder="Re-enter new password..."
                  className="w-full px-3 py-2 rounded-lg bg-[#FFF8F0] border border-[#EAD8C7] focus:outline-none focus:border-[#C58A3D]"
                />
              </div>

              {/* Password Policy checklist */}
              <div className="p-3 rounded-lg bg-[#FFF8F0] border border-[#EAD8C7] text-[11px] space-y-1 text-[#29180F]/70">
                <span className="font-semibold block text-[#29180F]">Cryptographic Password Policy:</span>
                <div className="grid grid-cols-2 gap-1">
                  <span className={newPasswordInput.length >= 10 ? 'text-emerald-700 font-semibold' : ''}>
                    &bull; 10+ characters
                  </span>
                  <span className={/[a-z]/.test(newPasswordInput) ? 'text-emerald-700 font-semibold' : ''}>
                    &bull; 1 Lowercase letter
                  </span>
                  <span className={/[A-Z]/.test(newPasswordInput) ? 'text-emerald-700 font-semibold' : ''}>
                    &bull; 1 Uppercase letter
                  </span>
                  <span className={/[0-9]/.test(newPasswordInput) ? 'text-emerald-700 font-semibold' : ''}>
                    &bull; 1 Number
                  </span>
                  <span className={/[!@#$%^&*()_+\-=[\]{};':"\\|,.<>/?]/.test(newPasswordInput) ? 'text-emerald-700 font-semibold' : ''}>
                    &bull; 1 Special character
                  </span>
                </div>
              </div>

              {passwordChangeError && (
                <div className="p-2.5 rounded-lg bg-rose-50 border border-rose-200 text-rose-700 text-xs font-medium flex items-center gap-1.5">
                  <ShieldAlert className="w-4 h-4 text-rose-600 shrink-0" />
                  <span>{passwordChangeError}</span>
                </div>
              )}

              {passwordChangeSuccess && (
                <div className="p-2.5 rounded-lg bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs font-medium flex items-center gap-1.5">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                  <span>{passwordChangeSuccess}</span>
                </div>
              )}

              <div className="flex items-center justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowPasswordModal(false)}
                  className="px-3 py-2 rounded-lg border border-[#EAD8C7] text-xs font-medium text-[#29180F] hover:bg-[#F4E7DA]"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isSubmittingPasswordChange}
                  className="px-4 py-2 rounded-lg bg-[#29180F] text-[#FFF8F0] hover:bg-[#1F120B] text-xs font-semibold flex items-center gap-1.5 disabled:opacity-60 cursor-pointer"
                >
                  {isSubmittingPasswordChange ? (
                    <>
                      <RefreshCw className="w-3.5 h-3.5 animate-spin text-[#C58A3D]" />
                      <span>Encrypting...</span>
                    </>
                  ) : (
                    <span>Update &amp; Encrypt Password</span>
                  )}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL 2: TWO-FACTOR AUTHENTICATION (2FA) SETUP */}
      {showTwoFactorModal && twoFactorSecretData && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
          <div className="w-full max-w-md bg-[#FFFDF9] rounded-2xl p-6 border border-[#EAD8C7] shadow-2xl space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-[#EAD8C7]">
              <div className="flex items-center gap-2">
                <Smartphone className="w-5 h-5 text-blue-600" />
                <h3 className="font-serif text-base font-semibold text-[#29180F]">
                  Setup Two-Factor Authenticator (2FA)
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setShowTwoFactorModal(false)}
                className="p-1 rounded-lg text-[#29180F]/50 hover:text-[#29180F] hover:bg-[#F4E7DA]"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-3.5 text-xs">
              <p className="text-[#29180F]/70">
                1. Open your <strong>Google Authenticator</strong>, <strong>Authy</strong>, or <strong>Microsoft Authenticator</strong> app on your mobile device.
              </p>

              <div>
                <label className="block font-semibold text-[#29180F] mb-1">
                  2. Add account manually using this Base32 Secret Key:
                </label>
                <div className="flex items-center gap-2 p-2.5 rounded-lg bg-[#FFF8F0] border border-[#EAD8C7] font-mono font-bold text-sm tracking-wider text-[#29180F] select-all">
                  <span className="flex-1 break-all">{twoFactorSecretData.secret}</span>
                  <button
                    type="button"
                    onClick={() => {
                      navigator.clipboard.writeText(twoFactorSecretData.secret);
                      setCopiedSecret(true);
                      setTimeout(() => setCopiedSecret(false), 2000);
                    }}
                    className="p-1.5 rounded-md hover:bg-[#EAD8C7] text-[#29180F] transition-colors shrink-0"
                    title="Copy Secret Key"
                  >
                    {copiedSecret ? <Check className="w-4 h-4 text-emerald-600" /> : <Copy className="w-4 h-4 text-[#C58A3D]" />}
                  </button>
                </div>
              </div>

              <form onSubmit={verifyAndEnableTwoFactor} className="space-y-3 pt-1">
                <div>
                  <label className="block font-semibold text-[#29180F] mb-1">
                    3. Enter the 6-digit verification code from your app:
                  </label>
                  <input
                    type="text"
                    maxLength={6}
                    required
                    value={twoFactorVerifyCode}
                    onChange={(e) => setTwoFactorVerifyCode(e.target.value.replace(/\D/g, ''))}
                    placeholder="000000"
                    className="w-full px-4 py-2.5 text-center font-mono text-lg tracking-widest rounded-lg bg-[#FFF8F0] border border-[#EAD8C7] focus:outline-none focus:border-blue-600 text-[#29180F]"
                  />
                </div>

                {twoFactorSetupError && (
                  <div className="p-2.5 rounded-lg bg-rose-50 border border-rose-200 text-rose-700 text-xs font-medium flex items-center gap-1.5">
                    <ShieldAlert className="w-4 h-4 text-rose-600 shrink-0" />
                    <span>{twoFactorSetupError}</span>
                  </div>
                )}

                {twoFactorSetupSuccess && (
                  <div className="p-2.5 rounded-lg bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs font-medium flex items-center gap-1.5">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                    <span>{twoFactorSetupSuccess}</span>
                  </div>
                )}

                <div className="flex items-center justify-end gap-2 pt-2">
                  <button
                    type="button"
                    onClick={() => setShowTwoFactorModal(false)}
                    className="px-3 py-2 rounded-lg border border-[#EAD8C7] text-xs font-medium text-[#29180F] hover:bg-[#F4E7DA]"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="px-4 py-2 rounded-lg bg-blue-600 text-white hover:bg-blue-700 text-xs font-semibold flex items-center gap-1.5 cursor-pointer"
                  >
                    <ShieldCheck className="w-3.5 h-3.5" />
                    <span>Activate 2FA Protection</span>
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      )}

      {/* MODAL 3: CREATE NEW ADMINISTRATOR USER (RBAC) */}
      {showAddUserModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
          <div className="w-full max-w-md bg-[#FFFDF9] rounded-2xl p-6 border border-[#EAD8C7] shadow-2xl space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-[#EAD8C7]">
              <div className="flex items-center gap-2">
                <UserPlus className="w-5 h-5 text-[#C58A3D]" />
                <h3 className="font-serif text-base font-semibold text-[#29180F]">
                  Add New Administrator Account
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setShowAddUserModal(false)}
                className="p-1 rounded-lg text-[#29180F]/50 hover:text-[#29180F] hover:bg-[#F4E7DA]"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleAddUser} className="space-y-3.5 text-xs">
              <div>
                <label className="block font-semibold text-[#29180F] mb-1">
                  Administrator Username <span className="text-rose-600">*</span>
                </label>
                <input
                  type="text"
                  required
                  value={newUsernameInput}
                  onChange={(e) => setNewUsernameInput(e.target.value.toLowerCase().replace(/[^a-z0-9_-]/g, ''))}
                  placeholder="e.g. juned_admin, satpal_tech..."
                  className="w-full px-3 py-2 rounded-lg bg-[#FFF8F0] border border-[#EAD8C7] focus:outline-none focus:border-[#C58A3D] font-mono text-xs"
                />
                <span className="text-[10px] text-[#29180F]/60 mt-0.5 block">
                  3-30 characters, lowercase letters, numbers, hyphens or underscores only.
                </span>
              </div>

              <div>
                <label className="block font-semibold text-[#29180F] mb-1">
                  Full Name / Display Name
                </label>
                <input
                  type="text"
                  value={newFullNameInput}
                  onChange={(e) => setNewFullNameInput(e.target.value)}
                  placeholder="e.g. MD Juned, Satpal Kumar..."
                  className="w-full px-3 py-2 rounded-lg bg-[#FFF8F0] border border-[#EAD8C7] focus:outline-none focus:border-[#C58A3D]"
                />
              </div>

              <div>
                <label className="block font-semibold text-[#29180F] mb-1">
                  Role &amp; Permissions Level <span className="text-rose-600">*</span>
                </label>
                <select
                  value={newRoleInput}
                  onChange={(e) => setNewRoleInput(e.target.value as any)}
                  className="w-full px-3 py-2 rounded-lg bg-[#FFF8F0] border border-[#EAD8C7] focus:outline-none focus:border-[#C58A3D] text-xs"
                >
                  <option value="ADMIN">ADMIN &mdash; Full administrative operations</option>
                  <option value="SUPER_ADMIN">SUPER_ADMIN &mdash; Full root access and team control</option>
                  <option value="MANAGER">MANAGER &mdash; Inquiries and customer management</option>
                  <option value="STAFF">STAFF &mdash; Assigned tasks and inquiries view</option>
                  <option value="READ_ONLY">READ_ONLY &mdash; View-only administrative access</option>
                </select>
              </div>

              <div>
                <label className="block font-semibold text-[#29180F] mb-1">
                  Initial Password <span className="text-rose-600">*</span>
                </label>
                <input
                  type="password"
                  required
                  value={newUserPasswordInput}
                  onChange={(e) => setNewUserPasswordInput(e.target.value)}
                  placeholder="Create high-entropy password..."
                  className="w-full px-3 py-2 rounded-lg bg-[#FFF8F0] border border-[#EAD8C7] focus:outline-none focus:border-[#C58A3D]"
                />
              </div>

              {/* Password Policy checklist */}
              <div className="p-3 rounded-lg bg-[#FFF8F0] border border-[#EAD8C7] text-[11px] space-y-1 text-[#29180F]/70">
                <span className="font-semibold block text-[#29180F]">Password Policy Requirements:</span>
                <div className="grid grid-cols-2 gap-1">
                  <span className={newUserPasswordInput.length >= 10 ? 'text-emerald-700 font-semibold' : ''}>
                    &bull; 10+ characters
                  </span>
                  <span className={/[a-z]/.test(newUserPasswordInput) ? 'text-emerald-700 font-semibold' : ''}>
                    &bull; 1 Lowercase letter
                  </span>
                  <span className={/[A-Z]/.test(newUserPasswordInput) ? 'text-emerald-700 font-semibold' : ''}>
                    &bull; 1 Uppercase letter
                  </span>
                  <span className={/[0-9]/.test(newUserPasswordInput) ? 'text-emerald-700 font-semibold' : ''}>
                    &bull; 1 Number
                  </span>
                  <span className={/[!@#$%^&*()_+\-=[\]{};':"\\|,.<>/?]/.test(newUserPasswordInput) ? 'text-emerald-700 font-semibold' : ''}>
                    &bull; 1 Special character
                  </span>
                </div>
              </div>

              {addUserError && (
                <div className="p-2.5 rounded-lg bg-rose-50 border border-rose-200 text-rose-700 text-xs font-medium flex items-center gap-1.5">
                  <ShieldAlert className="w-4 h-4 text-rose-600 shrink-0" />
                  <span>{addUserError}</span>
                </div>
              )}

              {addUserSuccess && (
                <div className="p-2.5 rounded-lg bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs font-medium flex items-center gap-1.5">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                  <span>{addUserSuccess}</span>
                </div>
              )}

              <div className="flex items-center justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowAddUserModal(false)}
                  className="px-3 py-2 rounded-lg border border-[#EAD8C7] text-xs font-medium text-[#29180F] hover:bg-[#F4E7DA]"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isSubmittingAddUser}
                  className="px-4 py-2 rounded-lg bg-[#29180F] text-[#FFF8F0] hover:bg-[#1F120B] text-xs font-semibold flex items-center gap-1.5 disabled:opacity-60 cursor-pointer"
                >
                  {isSubmittingAddUser ? (
                    <>
                      <RefreshCw className="w-3.5 h-3.5 animate-spin text-[#C58A3D]" />
                      <span>Creating Account...</span>
                    </>
                  ) : (
                    <>
                      <UserPlus className="w-3.5 h-3.5 text-[#C58A3D]" />
                      <span>Provision Administrator</span>
                    </>
                  )}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
