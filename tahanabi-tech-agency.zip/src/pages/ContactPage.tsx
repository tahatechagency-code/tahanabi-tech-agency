import React, { useState, useEffect } from 'react';
import { useNavigation } from '../context/NavigationContext';
import {
  MessageCircle,
  Phone,
  Mail,
  ArrowRight,
  CheckCircle,
  Sparkles,
  Send,
  Building,
} from 'lucide-react';
import { BrandLogo } from '../components/BrandLogo';

const SLUG_TO_LABEL: Record<string, string> = {
  'jewellery-ecommerce': 'Jewellery E-commerce',
  'car-service': 'Car Service & Fleet',
  'retail-fashion': 'Retail & Fashion',
  'real-estate': 'Real Estate & Property',
  healthcare: 'Healthcare & Wellness',
  other: 'More Industries / Custom Solution',
  'ai-automation': 'AI Automation & AI Concierge',
  'ecommerce-websites': 'E-commerce Websites',
  'custom-web-app': 'Custom Web & App Development',
  'crm-business-automation': 'CRM & Business Automation',
  'integration-workflow': 'Integration & Workflow',
  'support-maintenance': 'Support & Maintenance',
};

export const ContactPage: React.FC = () => {
  const { searchParams } = useNavigation();

  // Determine preselected requirement from search params (interest or service)
  const initialInterestKey = searchParams.interest || searchParams.service || '';
  const initialLabel = SLUG_TO_LABEL[initialInterestKey] || '';

  const [selectedTopic, setSelectedTopic] = useState<string>(initialLabel || 'General Consultation');
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [message, setMessage] = useState('');
  const [submitted, setSubmitted] = useState(false);

  useEffect(() => {
    const key = searchParams.interest || searchParams.service;
    if (key && SLUG_TO_LABEL[key]) {
      setSelectedTopic(SLUG_TO_LABEL[key]);
    }
  }, [searchParams]);

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');

  const handleQuickFormSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || (!email.trim() && !phone.trim())) {
      setErrorMessage('Please provide your name and at least an email or phone number.');
      return;
    }

    setIsSubmitting(true);
    setErrorMessage('');

    try {
      const response = await fetch('/api/inquiries', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          name: name.trim(),
          email: email.trim() || 'Not provided',
          phone: phone.trim() || 'Not provided',
          interest: selectedTopic,
          message: message.trim() || `Inquiring for ${selectedTopic}`,
        }),
      });

      const resData = await response.json();

      if (resData.success) {
        setSubmitted(true);
      } else {
        setErrorMessage(resData.error || 'Failed to dispatch message to server.');
      }
    } catch (err) {
      // Local fallback in case of offline/network issues
      console.warn('Backend transmission offline, using local cache', err);
      const newInquiry = {
        id: `inq-${Date.now()}`,
        name,
        email: email || 'Not provided',
        phone: phone || 'Not provided',
        interest: selectedTopic,
        message: message || `Inquiring for ${selectedTopic}`,
        timestamp: 'Just now',
        status: 'new' as const,
      };
      try {
        const stored = localStorage.getItem('tahanabi_inquiries');
        const list = stored ? JSON.parse(stored) : [];
        list.unshift(newInquiry);
        localStorage.setItem('tahanabi_inquiries', JSON.stringify(list));
      } catch {}
      setSubmitted(true);
    } finally {
      setIsSubmitting(false);
    }
  };

  // Build pre-filled WhatsApp link with topic and user details if any
  const encodedWaText = encodeURIComponent(
    `Hello Tahanabi Tech Agency, I am interested in: ${selectedTopic}.${
      name ? ` My name is ${name}.` : ''
    }`
  );
  const waUrl = `https://wa.me/919128596443?text=${encodedWaText}`;

  // Build pre-filled email mailto link
  const emailSubject = encodeURIComponent(`Project Requirement: ${selectedTopic} — Tahanabi Tech Agency`);
  const emailBody = encodeURIComponent(
    `Hello Tahanabi Tech Agency,\n\nI would like to inquire about: ${selectedTopic}.\n\nName: ${
      name || ''
    }\nPhone: ${phone || ''}\nEmail: ${email || ''}\n\nProject details:\n${message || ''}`
  );
  const mailtoUrl = `mailto:tahanabitechagency@gmail.com?subject=${emailSubject}&body=${emailBody}`;

  return (
    <div className="w-full py-12 sm:py-16 bg-[#FFF8F0] min-h-[75vh]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center max-w-2xl mx-auto mb-10 space-y-2">
          <div className="text-xs uppercase tracking-widest text-[#C58A3D] font-semibold">
            Direct Communication
          </div>
          <h1 className="font-serif text-3xl sm:text-4xl font-semibold text-[#29180F]">
            Contact Us
          </h1>
          <p className="text-sm text-[#29180F]/70">
            Have a project, idea or business requirement? Get in touch with our team.
          </p>
        </div>

        {/* Selected Requirement Banner if arrived from a card */}
        {selectedTopic && (
          <div className="max-w-3xl mx-auto mb-8 bg-[#F4E7DA] rounded-2xl p-4 border border-[#C58A3D]/40 shadow-xs flex items-center justify-between flex-wrap gap-3">
            <div className="flex items-center gap-3">
              <span className="p-2 rounded-xl bg-[#C58A3D] text-white">
                <Sparkles className="w-4 h-4" />
              </span>
              <div>
                <span className="text-[11px] font-semibold uppercase tracking-wider text-[#C58A3D] block">
                  Selected Requirement
                </span>
                <span className="font-serif text-base font-semibold text-[#29180F]">
                  {selectedTopic}
                </span>
              </div>
            </div>
            <div className="text-xs text-[#29180F]/70">
              Our team will review your {selectedTopic} requirements directly.
            </div>
          </div>
        )}

        {/* Two-Column Layout */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-start max-w-5xl mx-auto">
          {/* Left Column: 3 Compact Contact Options */}
          <div className="lg:col-span-6 space-y-4">
            <div className="text-xs font-semibold uppercase tracking-wider text-[#29180F]/60 mb-1">
              Select Contact Method
            </div>

            {/* Option 1 — Chat on WhatsApp */}
            <a
              href={waUrl}
              target="_blank"
              rel="noreferrer"
              className="group block bg-[#FFFDF9] hover:bg-[#FBF4EA] rounded-2xl p-5 border border-[#EAD8C7] hover:border-[#25D366] transition-all duration-200 hover:shadow-md cursor-pointer"
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-4">
                  {/* Official WhatsApp green icon */}
                  <div className="w-12 h-12 rounded-xl bg-[#25D366]/15 border border-[#25D366]/30 flex items-center justify-center text-[#25D366] group-hover:scale-105 transition-transform shrink-0">
                    <MessageCircle className="w-6 h-6 fill-current text-[#25D366]" />
                  </div>
                  <div className="text-left">
                    <div className="flex items-center gap-2">
                      <h3 className="font-serif text-base font-semibold text-[#29180F] group-hover:text-[#25D366] transition-colors">
                        Chat on WhatsApp
                      </h3>
                      <span className="text-[10px] px-2 py-0.5 rounded-full bg-[#25D366]/15 text-[#25D366] font-medium">
                        Instant
                      </span>
                    </div>
                    <p className="text-xs text-[#29180F]/70 mt-0.5">
                      Get a quick response from our team.
                    </p>
                    <span className="text-xs font-medium text-[#29180F]/90 mt-1 block font-mono">
                      +91 91285 96443
                    </span>
                  </div>
                </div>
                <div className="p-2 rounded-full bg-[#F4E7DA] text-[#29180F] group-hover:bg-[#25D366] group-hover:text-white transition-colors shrink-0">
                  <ArrowRight className="w-4 h-4" />
                </div>
              </div>
            </a>

            {/* Option 2 — Call Us */}
            <a
              href="tel:+919128596443"
              className="group block bg-[#FFFDF9] hover:bg-[#FBF4EA] rounded-2xl p-5 border border-[#EAD8C7] hover:border-[#C58A3D] transition-all duration-200 hover:shadow-md cursor-pointer"
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-4">
                  {/* Golden phone icon */}
                  <div className="w-12 h-12 rounded-xl bg-[#F4E7DA] border border-[#EAD8C7] flex items-center justify-center text-[#C58A3D] group-hover:scale-105 transition-transform shrink-0">
                    <Phone className="w-6 h-6" />
                  </div>
                  <div className="text-left">
                    <div className="flex items-center gap-2">
                      <h3 className="font-serif text-base font-semibold text-[#29180F] group-hover:text-[#C58A3D] transition-colors">
                        Call Us
                      </h3>
                      <span className="text-[10px] px-2 py-0.5 rounded-full bg-[#F4E7DA] text-[#C58A3D] font-medium">
                        Direct
                      </span>
                    </div>
                    <p className="text-xs text-[#29180F]/70 mt-0.5">
                      Speak directly with our team.
                    </p>
                    <span className="text-xs font-medium text-[#29180F]/90 mt-1 block font-mono">
                      +91 91285 96443
                    </span>
                  </div>
                </div>
                <div className="p-2 rounded-full bg-[#F4E7DA] text-[#29180F] group-hover:bg-[#C58A3D] group-hover:text-white transition-colors shrink-0">
                  <ArrowRight className="w-4 h-4" />
                </div>
              </div>
            </a>

            {/* Option 3 — Send a Message */}
            <a
              href={mailtoUrl}
              className="group block bg-[#FFFDF9] hover:bg-[#FBF4EA] rounded-2xl p-5 border border-[#EAD8C7] hover:border-[#C58A3D] transition-all duration-200 hover:shadow-md cursor-pointer"
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-4">
                  {/* Email icon */}
                  <div className="w-12 h-12 rounded-xl bg-[#F4E7DA] border border-[#EAD8C7] flex items-center justify-center text-[#C58A3D] group-hover:scale-105 transition-transform shrink-0">
                    <Mail className="w-6 h-6" />
                  </div>
                  <div className="text-left">
                    <div className="flex items-center gap-2">
                      <h3 className="font-serif text-base font-semibold text-[#29180F] group-hover:text-[#C58A3D] transition-colors">
                        Send a Message
                      </h3>
                      <span className="text-[10px] px-2 py-0.5 rounded-full bg-[#F4E7DA] text-[#29180F]/70 font-medium">
                        Official Email
                      </span>
                    </div>
                    <p className="text-xs text-[#29180F]/70 mt-0.5">
                      Share your requirement with us.
                    </p>
                    <span className="text-xs font-medium text-[#29180F]/90 mt-1 block">
                      tahanabitechagency@gmail.com
                    </span>
                  </div>
                </div>
                <div className="p-2 rounded-full bg-[#F4E7DA] text-[#29180F] group-hover:bg-[#C58A3D] group-hover:text-white transition-colors shrink-0">
                  <ArrowRight className="w-4 h-4" />
                </div>
              </div>
            </a>

            {/* In-app Requirement Form */}
            <div className="bg-[#FFFDF9] rounded-2xl p-5 border border-[#EAD8C7] shadow-xs mt-6">
              <div className="flex items-center justify-between mb-3 pb-2 border-b border-[#EAD8C7]/60">
                <span className="text-xs font-semibold text-[#29180F]">
                  Quick Requirement Dispatch
                </span>
                <span className="text-[11px] text-[#C58A3D]">Direct routing</span>
              </div>

              {submitted ? (
                <div className="py-6 text-center space-y-3">
                  <div className="w-12 h-12 rounded-full bg-[#25D366]/20 text-[#25D366] flex items-center justify-center mx-auto">
                    <CheckCircle className="w-6 h-6" />
                  </div>
                  <h4 className="font-serif text-lg font-semibold text-[#29180F]">
                    Requirement Transmitted to Admin!
                  </h4>
                  <p className="text-xs text-[#29180F]/75 max-w-sm mx-auto leading-relaxed">
                    Thank you, <span className="font-semibold text-[#29180F]">{name}</span>. Your {selectedTopic} inquiry has been logged directly into our engineering operations queue.
                  </p>

                  <div className="flex flex-col sm:flex-row items-center justify-center gap-2 pt-2">
                    <a
                      href={waUrl}
                      target="_blank"
                      rel="noreferrer"
                      className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-[#25D366] text-white hover:bg-[#20bd5a] text-xs font-semibold shadow-xs transition-colors"
                    >
                      <MessageCircle className="w-3.5 h-3.5" />
                      <span>Chat on WhatsApp Directly</span>
                    </a>

                    <a
                      href={mailtoUrl}
                      className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl border border-[#EAD8C7] hover:bg-[#F4E7DA] text-xs font-medium text-[#29180F] transition-colors"
                    >
                      <Mail className="w-3.5 h-3.5 text-[#C58A3D]" />
                      <span>Send Email Backup</span>
                    </a>
                  </div>

                  <div className="pt-2">
                    <button
                      onClick={() => {
                        setSubmitted(false);
                        setName('');
                        setEmail('');
                        setPhone('');
                        setMessage('');
                      }}
                      className="text-xs text-[#C58A3D] underline cursor-pointer hover:text-[#29180F]"
                    >
                      Send another inquiry
                    </button>
                  </div>
                </div>
              ) : (
                <form onSubmit={handleQuickFormSubmit} className="space-y-3">
                  {errorMessage && (
                    <div className="p-2.5 rounded-lg bg-rose-50 border border-rose-200 text-xs text-rose-700">
                      {errorMessage}
                    </div>
                  )}

                  <div>
                    <label className="block text-[11px] font-medium text-[#29180F]/80 mb-1">
                      Your Name *
                    </label>
                    <input
                      type="text"
                      required
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      placeholder="e.g. Alexander Vance"
                      className="w-full text-xs px-3 py-2 rounded-lg bg-[#FFF8F0] border border-[#EAD8C7] focus:border-[#C58A3D] focus:outline-none text-[#29180F]"
                    />
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="block text-[11px] font-medium text-[#29180F]/80 mb-1">
                        Email Address
                      </label>
                      <input
                        type="email"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        placeholder="client@company.com"
                        className="w-full text-xs px-3 py-2 rounded-lg bg-[#FFF8F0] border border-[#EAD8C7] focus:border-[#C58A3D] focus:outline-none text-[#29180F]"
                      />
                    </div>
                    <div>
                      <label className="block text-[11px] font-medium text-[#29180F]/80 mb-1">
                        Phone / WhatsApp
                      </label>
                      <input
                        type="tel"
                        value={phone}
                        onChange={(e) => setPhone(e.target.value)}
                        placeholder="+91 91285..."
                        className="w-full text-xs px-3 py-2 rounded-lg bg-[#FFF8F0] border border-[#EAD8C7] focus:border-[#C58A3D] focus:outline-none text-[#29180F]"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-[11px] font-medium text-[#29180F]/80 mb-1">
                      Project Notes (Optional)
                    </label>
                    <textarea
                      rows={2}
                      value={message}
                      onChange={(e) => setMessage(e.target.value)}
                      placeholder="Brief description of requirements, timeline, or scope..."
                      className="w-full text-xs px-3 py-2 rounded-lg bg-[#FFF8F0] border border-[#EAD8C7] focus:border-[#C58A3D] focus:outline-none text-[#29180F]"
                    />
                  </div>

                  <button
                    type="submit"
                    disabled={isSubmitting}
                    className="w-full py-2.5 rounded-lg bg-[#29180F] text-[#FFF8F0] hover:bg-[#1F120B] text-xs font-semibold flex items-center justify-center gap-2 transition-colors cursor-pointer disabled:opacity-50"
                  >
                    <Send className="w-3.5 h-3.5 text-[#C58A3D]" />
                    <span>{isSubmitting ? 'Transmitting to Admin...' : 'Submit Requirement to Tahanabi'}</span>
                  </button>
                </form>
              )}
            </div>
          </div>

          {/* Right Column: Tahanabi Branding, Office Image, and Details */}
          <div className="lg:col-span-6 space-y-6">
            <div className="bg-[#FFFDF9] rounded-3xl p-6 sm:p-7 border border-[#EAD8C7] shadow-lg">
              {/* Brand lockup */}
              <div className="mb-6">
                <BrandLogo isLightMode={true} />
              </div>

              {/* Office Image */}
              <div className="relative rounded-2xl overflow-hidden border border-[#EAD8C7] shadow-sm mb-6 aspect-[16/10]">
                <img
                  src="/src/assets/images/office_agency_aesthetic_1794281442498.jpg"
                  alt="Tahanabi Tech Agency Studio"
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#29180F]/60 via-transparent to-transparent" />
                <div className="absolute bottom-3 left-4 text-white text-xs">
                  <span className="font-serif font-semibold block">Tahanabi Tech Studio</span>
                  <span className="text-white/80 text-[11px]">International Technology Deployment</span>
                </div>
              </div>

              {/* Contact Information block */}
              <div className="space-y-4 pt-2 border-t border-[#EAD8C7]/60">
                <div className="text-xs font-semibold uppercase tracking-wider text-[#C58A3D]">
                  Verified Agency Coordinates
                </div>

                <div className="space-y-3 text-xs text-[#29180F]">
                  <div className="flex items-start gap-3">
                    <Phone className="w-4 h-4 text-[#C58A3D] shrink-0 mt-0.5" />
                    <div>
                      <div className="font-medium text-[#29180F]/60 text-[11px]">Direct Phone</div>
                      <a
                        href="tel:+919128596443"
                        className="font-mono font-semibold text-[#29180F] hover:text-[#C58A3D] transition-colors"
                      >
                        +91 91285 96443
                      </a>
                    </div>
                  </div>

                  <div className="flex items-start gap-3">
                    <Mail className="w-4 h-4 text-[#C58A3D] shrink-0 mt-0.5" />
                    <div>
                      <div className="font-medium text-[#29180F]/60 text-[11px]">Official Email</div>
                      <a
                        href="mailto:tahanabitechagency@gmail.com"
                        className="font-medium text-[#29180F] hover:text-[#C58A3D] transition-colors"
                      >
                        tahanabitechagency@gmail.com
                      </a>
                    </div>
                  </div>

                  <div className="flex items-start gap-3">
                    <MessageCircle className="w-4 h-4 text-[#25D366] shrink-0 mt-0.5" />
                    <div>
                      <div className="font-medium text-[#29180F]/60 text-[11px]">WhatsApp Business</div>
                      <a
                        href="https://wa.me/919128596443"
                        target="_blank"
                        rel="noreferrer"
                        className="font-mono font-semibold text-[#29180F] hover:text-[#25D366] transition-colors"
                      >
                        +91 91285 96443 (Online 24/7)
                      </a>
                    </div>
                  </div>

                  <div className="flex items-start gap-3">
                    <Building className="w-4 h-4 text-[#C58A3D] shrink-0 mt-0.5" />
                    <div>
                      <div className="font-medium text-[#29180F]/60 text-[11px]">Global Service</div>
                      <div className="text-[#29180F]">Worldwide Client Delivery &amp; SLA Support</div>
                    </div>
                  </div>

                  <div className="flex items-start gap-3 pt-2 border-t border-[#EAD8C7]/60">
                    <span className="p-1.5 rounded-lg bg-[#C58A3D]/15 text-[#C58A3D] shrink-0 mt-0.5">
                      <svg className="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                        <path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z" />
                        <circle cx="12" cy="10" r="3" />
                      </svg>
                    </span>
                    <div className="flex-1">
                      <div className="font-medium text-[#29180F]/60 text-[11px]">Verified Studio Location</div>
                      <div className="font-mono text-xs text-[#29180F] font-semibold">26.44282&deg; N, 85.90200&deg; E</div>
                      <a
                        href="https://www.google.com/maps/@26.44282,85.9019995,15z?entry=ttu&g_ep=EgoyMDI2MTEwNC4wIKXMDSoASAFQAw%3D%3D"
                        target="_blank"
                        rel="noreferrer"
                        className="inline-flex items-center gap-1 text-[11px] font-semibold text-[#C58A3D] hover:underline mt-1"
                      >
                        <span>Open in Google Maps</span>
                        <span>&rarr;</span>
                      </a>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
