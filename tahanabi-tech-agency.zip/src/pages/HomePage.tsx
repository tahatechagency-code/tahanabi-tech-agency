import React from 'react';
import { useNavigation } from '../context/NavigationContext';
import {
  ArrowRight,
  MessageCircle,
  Globe,
  ShieldCheck,
  Zap,
  Headphones,
  ShoppingBag,
  Sparkles,
  Code2,
  Workflow,
  Globe2,
  Building2,
  Cpu,
  TrendingUp,
  Clock,
  MapPin,
  ExternalLink,
  GraduationCap,
  Lock,
  CheckCircle2,
} from 'lucide-react';
import {
  INDUSTRY_WORKS,
  HOME_SERVICES_STRIP,
  SERVICES_LIST,
  LEADERSHIP_TEAM,
  SECURITY_SPECIALISTS,
  GOOGLE_MAPS_LOCATION_URL,
} from '../data/agencyData';
import { WorkCard } from '../components/WorkCard';
import { ServiceCard } from '../components/ServiceCard';
import { ClientFeedbackSection } from '../components/ClientFeedbackSection';

const STRIP_ICONS = [ShoppingBag, Sparkles, Code2, Workflow, Globe2];

export const HomePage: React.FC = () => {
  const { navigate } = useNavigation();

  return (
    <div className="w-full">
      {/* SECTION 1 — HERO */}
      <section className="relative overflow-hidden pt-8 pb-14 lg:py-16 bg-gradient-to-b from-[#FFF8F0] via-[#FFFDF9] to-[#FFF8F0]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-12 items-center">
            {/* Left Column */}
            <div className="lg:col-span-6 space-y-6 text-left">
              {/* Badge */}
              <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-[#F4E7DA] border border-[#EAD8C7] text-[#29180F] text-xs font-semibold tracking-wide">
                <span className="w-2 h-2 rounded-full bg-[#C58A3D]" />
                <span>AI &amp; Automation Specialists</span>
              </div>

              {/* Main Heading */}
              <h1 className="font-serif text-3xl sm:text-4xl lg:text-5xl font-semibold text-[#29180F] leading-[1.18] tracking-tight text-balance">
                Digital Products &amp; AI Automation for Global Businesses
              </h1>

              {/* Description */}
              <p className="text-sm sm:text-base text-[#29180F]/75 max-w-xl leading-relaxed">
                We build premium websites, e-commerce solutions and AI automation systems for
                businesses worldwide. Led by engineering talent from NIT Trichy and backed by two in-house cybersecurity specialists.
              </p>

              {/* Buttons */}
              <div className="flex flex-wrap items-center gap-3 pt-2">
                <button
                  onClick={() => navigate('/contact')}
                  className="inline-flex items-center gap-2 px-6 py-3 rounded-xl bg-[#29180F] text-[#FFF8F0] hover:bg-[#1F120B] transition-all text-sm font-semibold shadow-md hover:shadow-lg active:scale-98 cursor-pointer"
                >
                  <span>Contact Us</span>
                  <ArrowRight className="w-4 h-4 text-[#C58A3D]" />
                </button>

                <a
                  href="https://wa.me/919128596443"
                  target="_blank"
                  rel="noreferrer"
                  className="inline-flex items-center gap-2 px-5 py-3 rounded-xl bg-[#25D366] text-white hover:bg-[#20bd5a] transition-all text-sm font-semibold shadow-sm hover:shadow active:scale-98"
                >
                  <MessageCircle className="w-4 h-4" />
                  <span>WhatsApp</span>
                </a>
              </div>

              {/* Four small features below buttons */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-4 border-t border-[#EAD8C7]/60">
                <div className="flex items-center gap-2 text-xs font-medium text-[#29180F]/80">
                  <Globe className="w-4 h-4 text-[#C58A3D] shrink-0" />
                  <span>International Service</span>
                </div>
                <div className="flex items-center gap-2 text-xs font-medium text-[#29180F]/80">
                  <ShieldCheck className="w-4 h-4 text-[#C58A3D] shrink-0" />
                  <span>Secure &amp; Reliable</span>
                </div>
                <div className="flex items-center gap-2 text-xs font-medium text-[#29180F]/80">
                  <Zap className="w-4 h-4 text-[#C58A3D] shrink-0" />
                  <span>Fast Delivery</span>
                </div>
                <div className="flex items-center gap-2 text-xs font-medium text-[#29180F]/80">
                  <Headphones className="w-4 h-4 text-[#C58A3D] shrink-0" />
                  <span>Ongoing Support</span>
                </div>
              </div>
            </div>

            {/* Right Column — Device Mockups */}
            <div className="lg:col-span-6">
              <div className="relative rounded-2xl p-2 sm:p-3 bg-gradient-to-br from-[#FBF4EA] via-[#F4E7DA] to-[#EAD8C7] border border-[#EAD8C7] shadow-xl shadow-[#C58A3D]/10">
                <div className="overflow-hidden rounded-xl bg-[#FFFDF9] border border-[#EAD8C7]/80">
                  <img
                    src="/src/assets/images/hero_device_mockup_1794281440967.jpg"
                    alt="Tahanabi Tech Agency Digital Products and AI Workstations"
                    referrerPolicy="no-referrer"
                    className="w-full h-auto object-cover transform hover:scale-102 transition-transform duration-700"
                  />
                </div>
                {/* Subtle golden ambient tag */}
                <div className="absolute -bottom-3 right-6 bg-[#29180F] text-[#FFF8F0] px-4 py-1.5 rounded-full text-[11px] font-medium shadow-md flex items-center gap-1.5 border border-[#C58A3D]/50">
                  <span className="w-1.5 h-1.5 rounded-full bg-[#C58A3D]" />
                  <span>NIT Trichy Engineering &middot; Dual Security Specialists</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* SECTION 2 — MAIN SERVICES STRIP */}
      <section className="border-y border-[#EAD8C7] bg-[#F4E7DA]/60 py-6">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-4">
            {HOME_SERVICES_STRIP.map((item, idx) => {
              const IconComp = STRIP_ICONS[idx] || Sparkles;
              return (
                <div
                  key={item.title}
                  onClick={() => {
                    if (idx === 1) {
                      navigate('/ai-automation');
                    } else {
                      navigate('/services');
                    }
                  }}
                  className="group bg-[#FFFDF9]/90 hover:bg-[#FFFDF9] p-3.5 rounded-xl border border-[#EAD8C7] hover:border-[#C58A3D] transition-all cursor-pointer shadow-xs hover:shadow-md flex flex-col justify-between"
                >
                  <div className="flex items-center gap-2 mb-1.5">
                    <span className="p-1.5 rounded-lg bg-[#F4E7DA] text-[#C58A3D] group-hover:bg-[#C58A3D] group-hover:text-white transition-colors shrink-0">
                      <IconComp className="w-3.5 h-3.5" />
                    </span>
                    <h2 className="font-serif text-xs font-semibold text-[#29180F] group-hover:text-[#C58A3D] transition-colors leading-tight">
                      {item.title}
                    </h2>
                  </div>
                  <p className="text-[11px] text-[#29180F]/65 leading-tight">
                    {item.desc}
                  </p>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* 100x PREMIUM SERVICES SECTION ON HOME PAGE */}
      <section className="py-14 sm:py-16 bg-[#FFFDF9] border-b border-[#EAD8C7]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col sm:flex-row sm:items-end justify-between mb-10 pb-4 border-b border-[#EAD8C7]">
            <div>
              <div className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md bg-[#F4E7DA] text-[#29180F] text-xs font-semibold mb-2 border border-[#EAD8C7]">
                <ShieldCheck className="w-3.5 h-3.5 text-[#25D366]" />
                <span>100x Production Grade &middot; Two In-House Security Auditors</span>
              </div>
              <h2 className="font-serif text-2xl sm:text-3xl font-semibold text-[#29180F]">
                Our Services
              </h2>
              <p className="text-xs sm:text-sm text-[#29180F]/70 mt-1 max-w-xl">
                End-to-end digital and AI automation solutions engineered for international growth, sub-second speeds, and zero-compromise security.
              </p>
            </div>
            <button
              onClick={() => navigate('/services')}
              className="mt-4 sm:mt-0 inline-flex items-center gap-1.5 text-xs font-semibold text-[#29180F] hover:text-[#C58A3D] transition-colors group cursor-pointer"
            >
              <span>View Full Services Specs</span>
              <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
            </button>
          </div>

          {/* 6 Premium Service Cards Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {SERVICES_LIST.map((service) => (
              <ServiceCard key={service.id} service={service} />
            ))}
          </div>
        </div>
      </section>

      {/* SECTION 3 — OUR WORK */}
      <section className="py-14 sm:py-16 bg-[#FFF8F0]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Header */}
          <div className="flex flex-col sm:flex-row sm:items-end justify-between mb-8 pb-4 border-b border-[#EAD8C7]">
            <div>
              <div className="text-xs uppercase tracking-widest text-[#C58A3D] font-semibold mb-1">
                Portfolio &amp; Solutions
              </div>
              <h2 className="font-serif text-2xl sm:text-3xl font-semibold text-[#29180F]">
                Our Work
              </h2>
              <p className="text-xs sm:text-sm text-[#29180F]/70 mt-1 max-w-xl">
                Explore real projects and solutions built for different industries. Click any industry to inquire directly.
              </p>
            </div>
            <button
              onClick={() => navigate('/work')}
              className="mt-4 sm:mt-0 inline-flex items-center gap-1.5 text-xs font-semibold text-[#29180F] hover:text-[#C58A3D] transition-colors group cursor-pointer"
            >
              <span>View Full Work Directory</span>
              <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
            </button>
          </div>

          {/* 6 Industry Cards Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {INDUSTRY_WORKS.map((work) => (
              <WorkCard key={work.id} work={work} />
            ))}
          </div>
        </div>
      </section>

      {/* SECTION 4 — ABOUT PREVIEW & INSTITUTIONAL TRUST LEADERSHIP */}
      <section className="py-14 sm:py-16 bg-[#F4E7DA]/40 border-t border-[#EAD8C7]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Top Overview */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-center mb-12">
            {/* Left Content */}
            <div className="lg:col-span-7 space-y-5 text-left">
              <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#FFFDF9] text-[#29180F] text-xs font-bold border border-[#EAD8C7] shadow-2xs">
                <ShieldCheck className="w-3.5 h-3.5 text-[#25D366]" />
                <span>100% Verified Technical Pedigree</span>
              </div>

              <h2 className="font-serif text-2xl sm:text-3xl lg:text-4xl font-semibold text-[#29180F] leading-snug">
                About Tahanabi Tech Agency
              </h2>

              <p className="text-sm sm:text-base text-[#29180F]/85 leading-relaxed font-serif italic">
                &ldquo;A global digital and AI automation agency helping businesses grow with technology,
                design, and intelligent automation.&rdquo;
              </p>

              <p className="text-xs sm:text-sm text-[#29180F]/75 leading-relaxed">
                Founded on an unyielding <strong>100% Verified Technical Pedigree</strong>: spearheaded by <strong>MD Juned (B.Tech, NIT Trichy 2025)</strong> and <strong>Satpal Kumar (BCA, R.K. College, Madhubani)</strong>, supported by two in-house cybersecurity engineers and verified studio operations.
              </p>

              {/* Verified Location Badge with Direct Google Maps Link */}
              <div className="p-4 rounded-xl bg-[#FFFDF9] border border-[#EAD8C7] flex flex-col sm:flex-row sm:items-center justify-between gap-3 shadow-xs">
                <div className="flex items-start gap-3">
                  <div className="w-9 h-9 rounded-lg bg-[#C58A3D]/15 text-[#C58A3D] flex items-center justify-center shrink-0 mt-0.5">
                    <MapPin className="w-4 h-4" />
                  </div>
                  <div>
                    <span className="text-[11px] font-semibold uppercase tracking-wider text-[#C58A3D] block">
                      Verified Registered Studio Location
                    </span>
                    <span className="font-mono text-xs text-[#29180F] font-semibold">
                      Lat: 26.44282&deg; N, Long: 85.90200&deg; E
                    </span>
                    <span className="block text-[11px] text-[#29180F]/65">
                      Open in Google Maps for verified coordinates and satellite view
                    </span>
                  </div>
                </div>

                <a
                  href={GOOGLE_MAPS_LOCATION_URL}
                  target="_blank"
                  rel="noreferrer"
                  className="inline-flex items-center gap-1.5 px-3 py-2 rounded-lg bg-[#29180F] text-[#FFF8F0] hover:bg-[#1F120B] text-xs font-semibold shrink-0 transition-colors"
                >
                  <span>Open Google Maps</span>
                  <ExternalLink className="w-3 h-3 text-[#C58A3D]" />
                </a>
              </div>
            </div>

            {/* Right Image: Agency Aesthetic */}
            <div className="lg:col-span-5">
              <div className="relative rounded-2xl overflow-hidden border border-[#EAD8C7] shadow-lg bg-[#FFFDF9]">
                <img
                  src="/src/assets/images/office_agency_aesthetic_1794281442498.jpg"
                  alt="Tahanabi Tech Agency Studio Office"
                  referrerPolicy="no-referrer"
                  className="w-full h-72 sm:h-80 object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#29180F]/70 via-transparent to-transparent" />
                <div className="absolute bottom-4 left-4 right-4 text-white text-xs">
                  <span className="font-serif font-semibold text-sm block">Global Technology Studio</span>
                  <span className="text-white/80 text-[11px]">
                    NIT Trichy Engineering Pedigree &middot; Worldwide Deployment
                  </span>
                </div>
              </div>
            </div>
          </div>

          {/* Leadership & 2 Security Specialists Grid */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-10">
            {/* CEO: Md Juned */}
            <div className="bg-[#FFFDF9] rounded-2xl p-5 border border-[#EAD8C7] shadow-xs hover:border-[#C58A3D] transition-colors flex flex-col justify-between">
              <div>
                <div className="flex items-center gap-3.5 mb-4">
                  <img
                    src={LEADERSHIP_TEAM[0].image}
                    alt={LEADERSHIP_TEAM[0].name}
                    className="w-16 h-16 rounded-xl object-cover border border-[#EAD8C7] shadow-xs"
                  />
                  <div>
                    <h3 className="font-serif text-lg font-semibold text-[#29180F]">
                      {LEADERSHIP_TEAM[0].name}
                    </h3>
                    <div className="text-xs font-semibold text-[#C58A3D]">CEO &amp; Technical Architect</div>
                    <div className="inline-flex items-center gap-1 text-[11px] text-[#29180F]/80 font-medium mt-0.5">
                      <GraduationCap className="w-3.5 h-3.5 text-[#C58A3D]" />
                      <span>{LEADERSHIP_TEAM[0].qualification}</span>
                    </div>
                  </div>
                </div>
                <div className="p-2 rounded-lg bg-[#F4E7DA]/50 text-[11px] font-semibold text-[#29180F] mb-2 border border-[#EAD8C7]/50">
                  {LEADERSHIP_TEAM[0].institution}
                </div>
                <p className="text-xs text-[#29180F]/70 leading-relaxed">
                  {LEADERSHIP_TEAM[0].bio}
                </p>
              </div>
              <div className="mt-4 pt-3 border-t border-[#EAD8C7]/50 text-[10px] uppercase font-semibold tracking-wider text-[#C58A3D]">
                NIT Trichy Top Tier Pedigree
              </div>
            </div>

            {/* Founder: Satpal Kumar */}
            <div className="bg-[#FFFDF9] rounded-2xl p-5 border border-[#EAD8C7] shadow-xs hover:border-[#C58A3D] transition-colors flex flex-col justify-between">
              <div>
                <div className="flex items-center gap-3.5 mb-4">
                  <img
                    src={LEADERSHIP_TEAM[1].image}
                    alt={LEADERSHIP_TEAM[1].name}
                    className="w-16 h-16 rounded-xl object-cover border border-[#EAD8C7] shadow-xs"
                  />
                  <div>
                    <h3 className="font-serif text-lg font-semibold text-[#29180F]">
                      {LEADERSHIP_TEAM[1].name}
                    </h3>
                    <div className="text-xs font-semibold text-[#C58A3D]">Founder &amp; Head of Product</div>
                    <div className="inline-flex items-center gap-1 text-[11px] text-[#29180F]/80 font-medium mt-0.5">
                      <GraduationCap className="w-3.5 h-3.5 text-[#C58A3D]" />
                      <span>{LEADERSHIP_TEAM[1].qualification}</span>
                    </div>
                  </div>
                </div>
                <div className="p-2 rounded-lg bg-[#F4E7DA]/50 text-[11px] font-semibold text-[#29180F] mb-2 border border-[#EAD8C7]/50">
                  {LEADERSHIP_TEAM[1].institution}
                </div>
                <p className="text-xs text-[#29180F]/70 leading-relaxed">
                  {LEADERSHIP_TEAM[1].bio}
                </p>
              </div>
              <div className="mt-4 pt-3 border-t border-[#EAD8C7]/50 text-[10px] uppercase font-semibold tracking-wider text-[#C58A3D]">
                R.K. College Madhubani Alumnus
              </div>
            </div>

            {/* Two Security Specialists */}
            <div className="bg-[#FFFDF9] rounded-2xl p-5 border border-[#EAD8C7] shadow-xs hover:border-[#25D366] transition-colors flex flex-col justify-between">
              <div>
                <div className="flex items-center gap-3.5 mb-4">
                  <div className="w-16 h-16 rounded-xl overflow-hidden bg-[#29180F] border border-[#EAD8C7] shadow-xs relative shrink-0">
                    <img
                      src={SECURITY_SPECIALISTS.image}
                      alt="Cybersecurity Lab"
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <div>
                    <div className="inline-flex items-center gap-1 text-[10px] px-2 py-0.5 rounded-full bg-[#25D366]/15 text-[#25D366] font-semibold mb-1">
                      <Lock className="w-3 h-3" />
                      <span>2 Security Engineers</span>
                    </div>
                    <h3 className="font-serif text-base font-semibold text-[#29180F] leading-snug">
                      Cybersecurity Division
                    </h3>
                    <div className="text-[11px] text-[#29180F]/70">Zero-Trust Cloud Architects</div>
                  </div>
                </div>
                <div className="p-2 rounded-lg bg-[#25D366]/10 text-[11px] font-semibold text-[#29180F] mb-2 border border-[#25D366]/20">
                  Dual Penetration &amp; Vulnerability Testing
                </div>
                <p className="text-xs text-[#29180F]/70 leading-relaxed">
                  {SECURITY_SPECIALISTS.description}
                </p>
              </div>
              <div className="mt-4 pt-3 border-t border-[#EAD8C7]/50 text-[10px] uppercase font-semibold tracking-wider text-[#25D366]">
                100% Security Audited Guarantee
              </div>
            </div>
          </div>

          {/* Live Verified Client Feedback & Reviews Section */}
          <div className="pt-12">
            <ClientFeedbackSection
              title="Verified Client Reviews &amp; Industry Commentary"
              subtitle="Direct feedback from enterprise and luxury brands deployed by Tahanabi's engineering team."
            />
          </div>

          {/* Small "Know More" link */}
          <div className="pt-8 text-center">
            <button
              onClick={() => navigate('/about')}
              className="inline-flex items-center gap-2 px-6 py-2.5 rounded-xl bg-[#29180F] text-[#FFF8F0] hover:bg-[#1F120B] text-xs font-semibold shadow-xs hover:shadow transition-all cursor-pointer"
            >
              <span>Read Full About &amp; Security Protocols</span>
              <ArrowRight className="w-3.5 h-3.5 text-[#C58A3D]" />
            </button>
          </div>
        </div>
      </section>
    </div>
  );
};
