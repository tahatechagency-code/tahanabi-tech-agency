import React from 'react';
import { SERVICES_LIST, SERVICES_FAQS } from '../data/agencyData';
import { ServiceCard } from '../components/ServiceCard';
import { AccordionFAQ } from '../components/AccordionFAQ';
import {
  ShieldCheck,
  Lock,
  Zap,
} from 'lucide-react';

export const ServicesPage: React.FC = () => {

  return (
    <div className="w-full py-12 sm:py-16 bg-[#FFF8F0] min-h-[75vh]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header with 100x Assurance */}
        <div className="text-center max-w-3xl mx-auto mb-12 space-y-3">
          <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-[#F4E7DA] text-[#29180F] text-xs font-semibold border border-[#EAD8C7]">
            <ShieldCheck className="w-4 h-4 text-[#25D366]" />
            <span>NIT Trichy Engineering Standards &middot; Two In-House Security Specialists</span>
          </div>

          <h1 className="font-serif text-3xl sm:text-4xl lg:text-5xl font-semibold text-[#29180F]">
            Our Services
          </h1>

          <p className="text-sm sm:text-base text-[#29180F]/75 max-w-2xl mx-auto leading-relaxed">
            End-to-end digital and AI automation solutions for growing businesses. Engineered with institutional rigor, sub-second latency, and verified zero-vulnerability security.
          </p>

          {/* Quick SLA highlights strip */}
          <div className="flex flex-wrap items-center justify-center gap-4 pt-3 text-xs text-[#29180F]/80">
            <span className="inline-flex items-center gap-1.5 bg-[#FFFDF9] px-3 py-1 rounded-full border border-[#EAD8C7]">
              <Lock className="w-3.5 h-3.5 text-[#C58A3D]" />
              <span>Full IP &amp; Code Ownership</span>
            </span>
            <span className="inline-flex items-center gap-1.5 bg-[#FFFDF9] px-3 py-1 rounded-full border border-[#EAD8C7]">
              <Zap className="w-3.5 h-3.5 text-[#C58A3D]" />
              <span>&lt;800ms Page Speed Benchmarks</span>
            </span>
            <span className="inline-flex items-center gap-1.5 bg-[#FFFDF9] px-3 py-1 rounded-full border border-[#EAD8C7]">
              <ShieldCheck className="w-3.5 h-3.5 text-[#25D366]" />
              <span>Dual Penetration Audited</span>
            </span>
          </div>
        </div>

        {/* Exactly 6 Deep 100x Premium Service Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8 mb-16">
          {SERVICES_LIST.map((service) => (
            <ServiceCard key={service.id} service={service} />
          ))}
        </div>


        {/* Reusable Nested Accordion FAQ Section */}
        <AccordionFAQ
          title="Services &amp; Delivery FAQ"
          subtitle="Explore questions regarding our sprint velocity, code handover, and nested technical details on security &amp; AI integrations."
          badge="Interactive Client FAQ"
          items={SERVICES_FAQS}
          defaultOpenId="s-faq-1"
        />
      </div>
    </div>
  );
};
