import React from 'react';
import { INDUSTRY_WORKS } from '../data/agencyData';
import { WorkCard } from '../components/WorkCard';

export const WorkPage: React.FC = () => {
  return (
    <div className="w-full py-12 sm:py-16 bg-[#FFF8F0] min-h-[75vh]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center max-w-2xl mx-auto mb-12 space-y-2">
          <div className="text-xs uppercase tracking-widest text-[#C58A3D] font-semibold">
            Industry Portfolio
          </div>
          <h1 className="font-serif text-3xl sm:text-4xl font-semibold text-[#29180F]">
            Our Work
          </h1>
          <p className="text-sm text-[#29180F]/70">
            Explore real projects and solutions we have built for different industries.
          </p>
        </div>

        {/* 6 Industry Cards Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8">
          {INDUSTRY_WORKS.map((work) => (
            <WorkCard key={work.id} work={work} />
          ))}
        </div>
      </div>
    </div>
  );
};
