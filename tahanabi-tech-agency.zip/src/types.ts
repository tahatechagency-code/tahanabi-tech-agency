export type AppRoute =
  | '/'
  | '/work'
  | '/services'
  | '/ai-automation'
  | '/about'
  | '/contact'
  | '/admin';

export interface IndustryWork {
  id: string;
  slug: string;
  title: string;
  subtitle: string;
  tag: string;
  image: string;
}

export interface ServiceItem {
  id: string;
  slug: string;
  title: string;
  description: string;
  iconName: string;
  isAiConcierge?: boolean;
  deliverables?: string[];
  techStack?: string[];
  timeline?: string;
  badge?: string;
}

export interface TeamMember {
  name: string;
  role: string;
  qualification: string;
  institution: string;
  bio: string;
  image: string;
  specialization: string;
}

export interface ContactInquiry {
  id: string;
  name: string;
  email: string;
  phone: string;
  interest: string;
  message: string;
  timestamp: string;
  status: 'new' | 'verified' | 'replied' | 'in_progress' | 'completed';
  verifiedAt?: string;
  repliedAt?: string;
}

export interface AgencyConfig {
  phone: string;
  email: string;
  whatsappNumber: string;
  headline: string;
  tagline: string;
  aboutText: string;
  mapsUrl?: string;
}

export interface ClientComment {
  id: string;
  name: string;
  role: string;
  content: string;
  rating: number;
  timestamp: string;
  serviceUsed: string;
}

