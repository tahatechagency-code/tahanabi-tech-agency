/**
 * Utility functions for generating and validating Schema.org FAQPage JSON-LD objects
 * compliant with Google's Search Central Structured Data Guidelines & AI Engine Crawlers (AEO/GEO).
 *
 * References:
 * - Google Search Central: https://developers.google.com/search/docs/appearance/structured-data/faqpage
 * - Schema.org FAQPage: https://schema.org/FAQPage
 */

export interface SubQuestionItem {
  id: string;
  question: string;
  answer: string;
  badge?: string;
}

export interface AccordionFaqItem {
  id: string;
  question: string;
  answer?: string;
  tag?: string;
  nestedQuestions?: SubQuestionItem[];
}

export interface GoogleFaqAnswer {
  '@type': 'Answer';
  '@id'?: string;
  text: string;
}

export interface GoogleFaqQuestion {
  '@type': 'Question';
  '@id': string;
  name: string;
  url: string;
  acceptedAnswer: GoogleFaqAnswer;
}

export interface GoogleFaqPageSchema {
  '@context': 'https://schema.org';
  '@type': 'FAQPage';
  '@id': string;
  name: string;
  description?: string;
  url?: string;
  inLanguage?: string;
  publisher?: {
    '@type': 'Organization';
    name: string;
    url: string;
  };
  mainEntity: GoogleFaqQuestion[];
}

export interface FaqValidationIssue {
  severity: 'error' | 'warning';
  field: string;
  message: string;
  itemId?: string;
}

export interface FaqValidationResult {
  isValid: boolean;
  errors: string[];
  warnings: string[];
  issues: FaqValidationIssue[];
  questionCount: number;
  topLevelCount: number;
  nestedCount: number;
}

export interface GenerateFaqSchemaOptions {
  items: AccordionFaqItem[];
  title?: string;
  description?: string;
  pageUrl?: string;
  origin?: string;
  language?: string;
  includeNested?: boolean;
}

/**
 * Sanitizes and cleans plain text or supported HTML for FAQ schema.
 * Google Search Central supports limited HTML tags: <h1>-<h6>, <br>, <ol>, <ul>, <li>, <a>, <p>, <b>, <strong>, <i>, <em>.
 * Prohibits raw <script> or style injections.
 */
export function sanitizeFaqText(text: string): string {
  if (!text) return '';
  return text
    .replace(/<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi, '')
    .trim();
}

/**
 * Automatically generates a Google-compliant Schema.org FAQPage JSON-LD object
 * from AccordionFAQ items, including all nested questions.
 */
export function generateFaqSchema(options: GenerateFaqSchemaOptions): GoogleFaqPageSchema {
  const {
    items,
    title = 'Frequently Asked Questions',
    description,
    pageUrl = typeof window !== 'undefined'
      ? `${window.location.origin}${window.location.pathname}`
      : 'https://tahanabi.agency',
    language = 'en',
    includeNested = true,
  } = options;

  const mainEntity: GoogleFaqQuestion[] = [];

  items.forEach((item) => {
    // Top-level Question & Answer
    if (item.answer && item.answer.trim().length > 0) {
      const qText = sanitizeFaqText(item.question);
      const aText = sanitizeFaqText(item.answer);
      const qId = `${pageUrl}#faq-${item.id}`;
      const aId = `${pageUrl}#answer-${item.id}`;

      mainEntity.push({
        '@type': 'Question',
        '@id': qId,
        name: qText,
        url: qId,
        acceptedAnswer: {
          '@type': 'Answer',
          '@id': aId,
          text: aText,
        },
      });
    }

    // Process nested drill-down sub-questions
    if (includeNested && item.nestedQuestions && item.nestedQuestions.length > 0) {
      item.nestedQuestions.forEach((sub) => {
        if (sub.answer && sub.answer.trim().length > 0) {
          const subQText = sanitizeFaqText(sub.question);
          const subAText = sanitizeFaqText(sub.answer);
          const subQId = `${pageUrl}#faq-sub-${sub.id}`;
          const subAId = `${pageUrl}#answer-sub-${sub.id}`;

          mainEntity.push({
            '@type': 'Question',
            '@id': subQId,
            name: subQText,
            url: subQId,
            acceptedAnswer: {
              '@type': 'Answer',
              '@id': subAId,
              text: subAText,
            },
          });
        }
      });
    }
  });

  const schema: GoogleFaqPageSchema = {
    '@context': 'https://schema.org',
    '@type': 'FAQPage',
    '@id': `${pageUrl}#faq-page`,
    name: sanitizeFaqText(title),
    url: pageUrl,
    inLanguage: language,
    publisher: {
      '@type': 'Organization',
      name: 'Tahanabi Tech Agency',
      url: 'https://tahanabi.agency',
    },
    mainEntity,
  };

  if (description && description.trim().length > 0) {
    schema.description = sanitizeFaqText(description);
  }

  return schema;
}

/**
 * Validates a JSON-LD FAQPage object against Google Search Central guidelines:
 * 1. Root @context must be 'https://schema.org' (or 'http://schema.org').
 * 2. Root @type must be 'FAQPage'.
 * 3. mainEntity must be an array of Question objects with length >= 1.
 * 4. Each Question must have @type === 'Question', non-empty name, and valid acceptedAnswer.
 * 5. Each acceptedAnswer must have @type === 'Answer' and non-empty text.
 * 6. Checks for duplicate question text and invalid characters.
 */
export function validateFaqSchema(schema: any): FaqValidationResult {
  const issues: FaqValidationIssue[] = [];
  const errors: string[] = [];
  const warnings: string[] = [];

  const addIssue = (severity: 'error' | 'warning', field: string, message: string, itemId?: string) => {
    issues.push({ severity, field, message, itemId });
    if (severity === 'error') {
      errors.push(`[${field}] ${message}`);
    } else {
      warnings.push(`[${field}] ${message}`);
    }
  };

  if (!schema || typeof schema !== 'object') {
    addIssue('error', 'root', 'FAQ Schema object is null, undefined, or not an object.');
    return {
      isValid: false,
      errors,
      warnings,
      issues,
      questionCount: 0,
      topLevelCount: 0,
      nestedCount: 0,
    };
  }

  // 1. Validate @context
  if (!schema['@context'] || (schema['@context'] !== 'https://schema.org' && schema['@context'] !== 'http://schema.org')) {
    addIssue('error', '@context', 'FAQ schema @context must be "https://schema.org".');
  }

  // 2. Validate @type
  if (schema['@type'] !== 'FAQPage') {
    addIssue('error', '@type', `FAQ schema @type must be "FAQPage", received "${schema['@type']}".`);
  }

  // 3. Validate name / title
  if (!schema.name || typeof schema.name !== 'string' || schema.name.trim().length === 0) {
    addIssue('warning', 'name', 'FAQ schema is missing a descriptive name/title.');
  }

  // 4. Validate mainEntity
  if (!Array.isArray(schema.mainEntity)) {
    addIssue('error', 'mainEntity', 'FAQ schema "mainEntity" must be an array of Question objects.');
    return {
      isValid: false,
      errors,
      warnings,
      issues,
      questionCount: 0,
      topLevelCount: 0,
      nestedCount: 0,
    };
  }

  if (schema.mainEntity.length === 0) {
    addIssue('error', 'mainEntity', 'FAQ schema "mainEntity" must contain at least one Question item.');
  }

  const seenQuestions = new Set<string>();
  const seenIds = new Set<string>();
  let topLevelCount = 0;
  let nestedCount = 0;

  schema.mainEntity.forEach((questionItem: any, index: number) => {
    const itemLabel = `mainEntity[${index}]`;

    // Question type
    if (questionItem['@type'] !== 'Question') {
      addIssue('error', `${itemLabel}.@type`, `Must be "Question", received "${questionItem['@type']}".`, questionItem['@id']);
    }

    // Question name
    if (!questionItem.name || typeof questionItem.name !== 'string' || questionItem.name.trim().length < 5) {
      addIssue('error', `${itemLabel}.name`, 'Question "name" must be a non-empty string of at least 5 characters.', questionItem['@id']);
    } else {
      const normalizedName = questionItem.name.trim().toLowerCase();
      if (seenQuestions.has(normalizedName)) {
        addIssue('warning', `${itemLabel}.name`, `Duplicate question text found: "${questionItem.name}". Google may ignore duplicate FAQs.`, questionItem['@id']);
      }
      seenQuestions.add(normalizedName);

      if (questionItem.name.length > 300) {
        addIssue('warning', `${itemLabel}.name`, `Question exceeds 300 characters (${questionItem.name.length} chars). Consider shortening for snippet eligibility.`, questionItem['@id']);
      }
    }

    // Question @id
    if (questionItem['@id']) {
      if (seenIds.has(questionItem['@id'])) {
        addIssue('error', `${itemLabel}.@id`, `Duplicate @id detected: "${questionItem['@id']}".`, questionItem['@id']);
      }
      seenIds.add(questionItem['@id']);

      if (questionItem['@id'].includes('-sub-')) {
        nestedCount++;
      } else {
        topLevelCount++;
      }
    } else {
      topLevelCount++;
      addIssue('warning', `${itemLabel}.@id`, 'Missing @id URI anchor on Question; recommended for Knowledge Graph linking.');
    }

    // acceptedAnswer validation
    const answer = questionItem.acceptedAnswer;
    if (!answer || typeof answer !== 'object') {
      addIssue('error', `${itemLabel}.acceptedAnswer`, 'Question must have an "acceptedAnswer" object.', questionItem['@id']);
    } else {
      if (answer['@type'] !== 'Answer') {
        addIssue('error', `${itemLabel}.acceptedAnswer.@type`, `acceptedAnswer.@type must be "Answer", received "${answer['@type']}".`, questionItem['@id']);
      }

      if (!answer.text || typeof answer.text !== 'string' || answer.text.trim().length < 5) {
        addIssue('error', `${itemLabel}.acceptedAnswer.text`, 'acceptedAnswer "text" must be a non-empty string with adequate explanation.', questionItem['@id']);
      } else {
        if (/<script/i.test(answer.text)) {
          addIssue('error', `${itemLabel}.acceptedAnswer.text`, 'Answer text contains illegal <script> tag prohibited by Google.', questionItem['@id']);
        }
      }
    }
  });

  return {
    isValid: errors.length === 0,
    errors,
    warnings,
    issues,
    questionCount: schema.mainEntity.length,
    topLevelCount,
    nestedCount,
  };
}

/**
 * Convenience helper: generates the complete Google-compliant JSON-LD schema object
 * and immediately runs the full validation suite, returning both the schema and diagnosis.
 */
export function generateAndValidateFaqSchema(options: GenerateFaqSchemaOptions): {
  schema: GoogleFaqPageSchema;
  validation: FaqValidationResult;
} {
  const schema = generateFaqSchema(options);
  const validation = validateFaqSchema(schema);
  return { schema, validation };
}
